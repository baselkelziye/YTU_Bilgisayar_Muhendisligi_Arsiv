basla:-tahmin(Karakter),
    write('Karakteriniz: '),
    write(Karakter),
    nl,
    undo.

laz_ziya	:- konsey_üyesi, baba, verify(gemici), verify(laz).
nizamettin_güvenç :- konsey_üyesi, bekar, verify(avukat).
kılıç :- konsey_üyesi, bekar, verify(tetikçi), verify(yüz_yara_izi).
testere_necmi :- konsey_üyesi, bekar, verify(tetikçi).
tuncay_kantarcı :- konsey_üyesi, bekar, verify(titiz).
iplikçi_nedim :- konsey_üyesi, bekar, verify(tefeci), verify(musevi).
hüsrev_ağa :- konsey_üyesi, baba, verify(ağa).
halo_dayı :- konsey_üyesi, bekar, verify(ağa).
samuel_vanunu :- konsey_üyesi, verify(evli), verify(tefeci), verify(musevi).
tombalacı :- konsey_üyesi, verify(evli), verify(kumarbaz).
mehmet_karahanlı :- baron, baba.
polat_alemdar :- baron, bekar, derin_devlet.

orhan :- verify(erkek), bekar, verify(sağ_kol), verify(laz).
seyfo_dayı :- verify(erkek), bekar, verify(sağ_kol), verify(maden_suyu_sever).
sehmus_kirve :- verify(erkek), bekar, verify(sağ_kol).

prof_doktor_abuzer_kömürcü :- baba, verify(hep_gözlük_takar), verify(kimyager).

pala :- verify(erkek), bekar, derin_devlet, verify(hep_gözlük_takar).
aslan_akbey :- verify(erkek), bekar, derin_devlet.
duran_emmi :- verify(erkek), bekar, verify(son_kabadayı).

abidin :- verify(erkek), verify(evli), verify(sağ_kol), verify(laz).
süleyman_çakır :- baba, verify(tetikçi).
şevko :- verify(erkek), bekar, verify(kumarbaz).

nesrin :- anne.
ester :- kadın, verify(evli), verify(musevi).
elif :- kadın, bekar, verify(avukat).

tahmin(mehmet_karahanlı):-mehmet_karahanlı, !.
tahmin(polat_alemdar):-polat_alemdar, !.
tahmin(laz_ziya):-laz_ziya, !.
tahmin(nizamettin_güvenç):-nizamettin_güvenç, !.
tahmin(kılıç):-kılıç, !.
tahmin(testere_necmi):-testere_necmi, !.
tahmin(tuncay_kantarcı):-tuncay_kantarcı, !.
tahmin(iplikçi_nedim):-iplikçi_nedim, !.
tahmin(hüsrev_ağa):-hüsrev_ağa, !.
tahmin(halo_dayı):-halo_dayı, !.
tahmin(samuel_vanunu):-samuel_vanunu, !.
tahmin(tombalacı):-tombalacı, !.

tahmin(pala):-pala, !.
tahmin(aslan_akbey):-aslan_akbey, !.
tahmin(duran_emmi):-duran_emmi, !.
tahmin(abidin):-abidin, !.

tahmin(orhan):-orhan, !.
tahmin(seyfo_dayı):-seyfo_dayı, !.
tahmin(sehmus_kirve):-sehmus_kirve, !.
tahmin(prof_doktor_abuzer_kömürcü):-prof_doktor_abuzer_kömürcü, !.

tahmin(süleyman_çakır):-süleyman_çakır, !.
tahmin(şevko):-şevko, !.

tahmin(nesrin):-nesrin, !.
tahmin(ester):-ester, !.
tahmin(elif):-elif, !.
tahmin(bulunamadı).

baron:-konsey_üyesi, verify(baronluk_yüzüğüne_sahiptir).
konsey_üyesi:-verify(erkek), verify(konsey_yeminini_etmiştir).

derin_devlet:-verify(kgt_üyesidir), !.
derin_devlet:-verify(jitem_üyesidir).

kadın:-not(verify(erkek)).
bekar:-not(verify(evli)).
dul:-bekar, verify(eşini_kaybetmiş).

baba:-verify(erkek), verify(evli), verify(çocuğu_var), !.
baba:-verify(erkek), dul, verify(çocuğu_var).

anne:-kadın, verify(evli), verify(çocuğu_var), !.
anne:-kadın, dul, verify(çocuğu_var).

verify(S):-
    (   evet(S) ->  true;
    (   hayır(S) ->   fail;
    	sor(S))).


sor(Ozellik):-write('Karakteriniz bu özelliğe sahip mi: '),
    			write(Ozellik),
    			write('?'),
    			read(Cevap),
    			nl,
    			(	(Cevap == evet;Cevap == e;Cevap == yes;Cevap == y) 
                	-> 
                	assert(evet(Ozellik));
                	assert(hayır(Ozellik)),fail).

:- dynamic evet/1,hayır/1.

undo :- retract(evet(_)),fail. 
undo :- retract(hayır(_)),fail.
undo.



maze1.txt büyük harita
maze.txt küçük harita
dosya ismini kodda değiştirerek geçiş yapabilirsiniz
//Bu program 9 tane say�sal analiz metodunu bilgisayar ortam�nda implement etmektedir.
//Powered by Furkan Sami AKYILDIZ

#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <windows.h>

void menu();
void fx_oku();
float fx_hesapla(float x);
float tureval(float x);
void grafik();
void bisection();
void regulafalse();
void newtonraphson();
void matrisinvers();
void gauss();
void seidel();
void trapez();
void simpson();

float xk,xk1,eps,a,b,c,d,e,f,A,B,C,D,E,F,x,sonuc,turev;

void menu(){
     char secim;
     printf("                            ANA EKRAN                            \n");
     printf("------------------------------------------------------------------------------\n\n");
     printf("(1'e basiniz)  GRAFIK                    yontemi ile kok bulma\n");
     printf("(2'ye basiniz) BI-SECTION                yontemi ile kok bulma\n");
     printf("(3'e basiniz)  REGULA FALSE              yontemi ile kok bulma\n");
     printf("(4'e basiniz)  NEWTON RAPHSON            yontemi ile kok bulma\n");
     printf("(5'e basiniz)  GAUSS-JORDAN ELEMINASYON  yontemi ile matrisin inversini bulma\n");
     printf("(6'ya basiniz) GAUSS ELEMINASYON         yontemi ile denklem takimi cozumu\n");
     printf("(7'ye basiniz) GAUSS SEIDEL              yontemi ile denklem takimi cozumu\n");
     printf("(8'e basiniz)  TRAPEZ                    yontemi ile integral alma\n");
     printf("(9'a basiniz)  SIMPSON                   yontemi ile integral alma\n\n\n");
     printf("(0'a basiniz)  CIKIS\n");
     printf("\nLutfen Seciminizi girin: ");
     secim = getche();
     system("cls");
     switch(secim){
        case '1':grafik();break;
        case '2':bisection();break;
        case '3':regulafalse();break;
        case '4':newtonraphson();break;
        case '5':matrisinvers();break;
        case '6':gauss();break;
        case '7':seidel();break;
        case '8':trapez();break;
        case '9':simpson();break;
        case '0':exit(0);break;
        default:printf("\n\nLutfen verilen sayilar arasindan secim yapiniz.\n\n");
        menu();
        break;
     }
}

void fx_oku(){
     printf("\n\nf(x) = a*x^5 + b*x^4 + c*x^3 + d*x^2 + e*x^1 + f*x^0\n\n");
     printf("a degerini girin: ");
     scanf("%f",&a);
     printf("\n");
     printf("b degerini girin: ");
     scanf("%f",&b);
     printf("\n");
     printf("c degerini girin: ");
     scanf("%f",&c);
     printf("\n");
     printf("d degerini girin: ");
     scanf("%f",&d);
     printf("\n");
     printf("e degerini girin: ");
     scanf("%f",&e);
     printf("\n");
     printf("f degerini girin: ");
     scanf("%f",&f);
     printf("\n\n");
}

float fx_hesapla(float x){
    
     A = a * (x*x*x*x*x);
     B = b * (x*x*x*x);
     C = c * (x*x*x);
     D = d * (x*x);
     E = e * (x);
     F = f;  
     sonuc = A + B + C + D + E + F;
     return sonuc;
}

float tureval(float x){
     turev = (fx_hesapla(x-0.001)-fx_hesapla(x))/(-0.001);
     return turev;
} 
      
void grafik(){
     float deltax;
     printf("\n<<<<<GRAFIK YONTEMI ILE KOK BULMA>>>>>\n");
     fx_oku();
     printf("x0 degerini girin: ");
     scanf("%f",&xk);
     printf("\nDelta x degerini girin: ");
     scanf("%f",&deltax);
     printf("\nEpsilon degerini girin: ");
     scanf("%f",&eps);
     xk1 = xk + deltax;
     while(fabs(xk1-xk) >= eps){
        if(fx_hesapla(xk)<0){
           while(fx_hesapla(xk)<0){
              xk = xk + deltax;            
           }
           xk1 = xk;
           xk = xk - deltax;
           deltax = deltax / 2;
        }
        else{
           while(fx_hesapla(xk)>0){
              xk = xk + deltax;
           }
           xk1 = xk;
           xk = xk - deltax;
           deltax = deltax / 2;
        }
     }
     printf("\nDenklemin koku: %.2f\n\n\n",xk);
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}

void bisection(){
     float m,n,q;
     int ctrl=0;
     printf("\n<<<<<BI-SECTION YONTEMI ILE KOK BULMA>>>>>\n");
     fx_oku();
     printf("Koku icerisine alan iki deger girin: ");
     scanf("%f%f",&m,&n);
     printf("Epsilon degerini girin: ");
     scanf("%f",&eps);
     q = (m+n) / 2;
     while(fabs(fx_hesapla(q))>=eps){
        if(fx_hesapla(m)*fx_hesapla(n)<0){
           q = (m+n) / 2;
           if(fx_hesapla(m)*fx_hesapla(q)>0){
              m = q;
           }
           else{
              n = q;
           }
        }
        else{
           if(fx_hesapla(m)*fx_hesapla(n)==0){
              if(fx_hesapla(m)==0){
                 m = q;
              }
              else{
                 n = q;
              }
           }
           else{
              ctrl=1;
              printf("\nGirilen degerler koku icerisine almamaktadir.\n\n\n");
              eps=fx_hesapla(q)+1;
           }
        }
     }
     if(ctrl==0){
        printf("\nDenklemin koku: %.2f\n\n\n",q);
     }
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}

void regulafalse(){
     float m,n,q;
     int ctrl=0;
     printf("\n<<<<<REGULA FALSE YONTEMI ILE KOK BULMA>>>>>\n");
     fx_oku();
     printf("Koku icerisine alan iki deger girin: ");
     scanf("%f%f",&m,&n);
     printf("Epsilon degerini girin: ");
     scanf("%f",&eps);
     q = (fx_hesapla(m)*n-m*fx_hesapla(n))/(fx_hesapla(m)-fx_hesapla(n));
     while(fabs(fx_hesapla(q))>=eps){
        if(fx_hesapla(m)*fx_hesapla(n)<0){
           q = (fx_hesapla(m)*n-m*fx_hesapla(n))/(fx_hesapla(m)-fx_hesapla(n));
           if(fx_hesapla(m)*fx_hesapla(q)>0){
              m = q;
           }
           else{
              n = q;
           }
        }
        else{
           if(fx_hesapla(m)*fx_hesapla(n)==0){
              if(fx_hesapla(m)==0){
                 m = q;
              }
              else{
                 n = q;
              }
           }
           else{
              ctrl=1;
              printf("\nGirilen degerler koku icerisine almamaktadir.");
              eps=fx_hesapla(q)+1;
           }
        }
     }
     if(ctrl==0){
        printf("\nDenklemin koku: %.2f\n\n\n",q);
     }
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}     

void newtonraphson(){
     printf("\n<<<<<NEWTON RAPHSON YONTEMI ILE KOK BULMA>>>>>\n");
     fx_oku();
     printf("x0 degerini girin: ");
     scanf("%f",&xk);
     printf("Epsilon degerini girin: ");
     scanf("%f",&eps);
     xk1=xk - (fx_hesapla(xk)/tureval(xk));
     while(fabs(xk1-xk) >= eps){
        xk = xk1;
        xk1 = xk - (fx_hesapla(xk)/tureval(xk));
     }
     printf("\nDenklemin koku: %.2f\n\n\n",xk);
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}

void matrisinvers(){
     int i,j;
     float A[4][4];
     float birim[3][3] = {{1,0,0},{0,1,0},{0,0,1}};
     printf("\n<<<<<GAUSS-JORDAN ELEMINASYON YONTEMI ILE MATRISIN INVERSINI BULMA>>>>>\n");
     printf("\n\nMatrisin:\n");
     for(i=1;i<4;i++){
        for(j=1;j<4;j++){
           printf("\n\t%d. satir %d. sutun elemanini girin: ",i,j);
           scanf("%f",&A[i][j]);
        }
     }
     printf("\nGirilen matris:\n");
     for(i=1;i<4;i++){
        printf("\n  |");
        for(j=1;j<4;j++){
           printf("%10.2f",A[i][j]);
        }
        printf("       |");
     }
      
     birim[0][0] /= A[1][1]; birim[0][1] /= A[1][1];birim[0][2] /= A[1][1];
     A[1][2]/=A[1][1]; A[1][3]/=A[1][1]; A[1][1]/=A[1][1];
     
     birim[1][0] -= A[2][1]*birim[0][0]; birim[1][1] -= A[2][1]*birim[0][1]; birim[1][2] -= A[2][1]*birim[0][2];
     A[2][2] -= A[2][1]*A[1][2]; A[2][3] -= A[2][1]*A[1][3]; A[2][1] -= A[2][1]*A[1][1];

     birim[2][0] -= A[3][1]*birim[0][0]; birim[2][1] -= A[3][1]*birim[0][1]; birim[2][2] -= A[3][1]*birim[0][2];
     A[3][2] -= A[3][1]*A[1][2]; A[3][3] -= A[3][1]*A[1][3]; A[3][1] -= A[3][1]*A[1][1];
     
     birim[1][0] /= A[2][2]; birim[1][1] /= A[2][2]; birim[1][2] /= A[2][2];
     A[2][1]/=A[2][2]; A[2][3]/=A[2][2]; A[2][2]/=A[2][2];

     birim[0][0] -= A[1][2]*birim[1][0]; birim[0][1] -= A[1][2]*birim[1][1]; birim[0][2] -= A[1][2]*birim[1][2];
     A[1][1] -= A[1][2]*A[2][1]; A[1][3] -= A[1][2]*A[2][3]; A[1][2] -= A[1][2]*A[2][2];

     birim[2][0] -= A[3][2]*birim[1][0]; birim[2][1] -= A[3][2]*birim[1][1]; birim[2][2] -= A[3][2]*birim[1][2];
     A[3][1] -= A[3][2]*A[2][1]; A[3][3] -= A[3][2]*A[2][3]; A[3][2] -= A[3][2]*A[2][2];

     birim[2][0] /= A[3][3]; birim[2][1] /= A[3][3]; birim[2][2] /= A[3][3];
     A[3][1]/=A[3][3]; A[3][2]/=A[3][3]; A[3][3]/=A[3][3]; 
     
     birim[0][0] -= A[1][3]*birim[2][0]; birim[0][1] -= A[1][3]*birim[2][1]; birim[0][2] -= A[1][3]*birim[2][2];
     A[1][1] -= A[1][3]*A[3][1]; A[1][2] -= A[1][3]*A[3][2]; A[1][3] -= A[1][3]*A[3][3];

     birim[1][0] -= A[2][3]*birim[2][0]; birim[1][1] -= A[2][3]*birim[2][1]; birim[1][2] -= A[2][3]*birim[2][2];
     A[2][1] -= A[2][3]*A[3][1]; A[2][2] -= A[2][3]*A[3][2]; A[2][3] -= A[2][3]*A[3][3];     
     
     printf("\n\nGirilen matrisin tersi:\n");
     for(i=0;i<3;i++){
        printf("\n  |");
        for(j=0;j<3;j++){
           printf("%10.2f",birim[i][j]);
        }
        printf("       |");
     }
     printf("\n\n\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}

void gauss(){
     float x1,x2,x3;
     float A[4][4];
     float X[4][2];
     
     printf("\nGAUSS ELEMINASYON YONTEMI ILE DENKLEM TAKIMI COZUMU\n");
     printf("\n\na1*x1 + b1*x2 + c1*x3 = d1\n");
     printf("a2*x1 + b2*x2 + c2*x3 = d2\n");
     printf("a3*x1 + b3*x2 + c3*x3 = d3\n");
     printf("\na1 degerini girin: ");
     scanf("%f",&A[1][1]);
     printf("b1 degerini girin: ");
     scanf("%f",&A[1][2]);
     printf("c1 degerini girin: ");
     scanf("%f",&A[1][3]);
     printf("d1 degerini girin: ");
     scanf("%f",&X[1][1]);
     printf("\na2 degerini girin: ");
     scanf("%f",&A[2][1]);
     printf("b2 degerini girin: ");
     scanf("%f",&A[2][2]);
     printf("c2 degerini girin: ");
     scanf("%f",&A[2][3]);
     printf("d2 degerini girin: ");
     scanf("%f",&X[2][1]);
     printf("\na3 degerini girin: ");
     scanf("%f",&A[3][1]);
     printf("b3 degerini girin: ");
     scanf("%f",&A[3][2]);
     printf("c3 degerini girin: ");
     scanf("%f",&A[3][3]);
     printf("d3 degerini girin: ");
     scanf("%f",&X[3][1]);
     
     X[1][1] /= A[1][1];
     A[1][2] /= A[1][1]; A[1][3] /=A [1][1]; A[1][1] /=A [1][1];
     
     X[2][1] /= A[2][1];
     A[2][2] /= A[2][1]; A[2][3] /=A [2][1]; A[2][1] /=A [2][1];
     
     X[2][1] -= X[1][1];
     A[2][1] -= A[1][1]; A[2][2] -= A[1][2]; A[2][3] -= A[1][3];
     
     X[3][1] /= A[3][1];
     A[3][2] /= A[3][1]; A[3][3] /=A [3][1]; A[3][1] /=A [3][1];
     
     X[3][1] -= X[1][1];
     A[3][1] -= A[1][1]; A[3][2] -= A[1][2]; A[3][3] -= A[1][3];
     
     X[2][1] /= A[2][2];
     A[2][1] /= A[2][2]; A[2][3] /=A [2][2]; A[2][2] /=A [2][2];
     
     X[3][1] /= A[3][2];
     A[3][1] /= A[3][2]; A[3][3] /=A [3][2]; A[3][2] /=A [3][2];
     
     X[3][1] -= X[2][1];
     A[3][1] -= A[2][1]; A[3][2] -= A[2][2]; A[3][3] -= A[2][3];
     
     x3 = X[3][1]/A[3][3];
     x2 = (X[2][1]-A[2][3]*x3) / A[2][2];
     x1 = (X[1][1]-A[1][3]*x3-A[1][2]*x2) / A[1][1];
     printf("\n\nx1 = %.2f\tx2 = %.2f\tx3 = %.2f\n\n\n",x1,x2,x3);
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}

void seidel(){
     float x1,x2,x3,a1,a2,a3,b1,b2,b3,c1,c2,c3,d1,d2,d3,max,xk2,xk3;
     float ctrl[6];
     int i;
     
     printf("\n<<<<<GAUSS SEIDEL YONTEMI ILE DENKLEM TAKIMI COZUMU>>>>>\n");
     printf("\n\na1*x1 + b1*x2 + c1*x3 = d1\n");
     printf("a2*x1 + b2*x2 + c2*x3 = d2\n");
     printf("a3*x1 + b3*x2 + c3*x3 = d3\n");
     printf("\na1 degerini girin: ");
     scanf("%f",&a1);
     printf("b1 degerini girin: ");
     scanf("%f",&b1);
     printf("c1 degerini girin: ");
     scanf("%f",&c1);
     printf("d1 degerini girin: ");
     scanf("%f",&d1);
     printf("\na2 degerini girin: ");
     scanf("%f",&a2);
     printf("b2 degerini girin: ");
     scanf("%f",&b2);
     printf("c2 degerini girin: ");
     scanf("%f",&c2);
     printf("d2 degerini girin: ");
     scanf("%f",&d2);
     printf("\na3 degerini girin: ");
     scanf("%f",&a3);
     printf("b3 degerini girin: ");
     scanf("%f",&b3);
     printf("c3 degerini girin: ");
     scanf("%f",&c3);
     printf("d3 degerini girin: ");
     scanf("%f",&d3);
     printf("\nEpsilon degerini girin: ");
     scanf("%f",&eps);
     ctrl[0] = a1*b2*c3;
     ctrl[1] = a1*b3*c2;
     ctrl[2] = a2*b1*c3;
     ctrl[3] = a2*b3*c1;
     ctrl[4] = a3*b1*c2;
     ctrl[5] = a3*b2*c1;
     max = ctrl[0];
     x1 = x2 = x3 = 1.0;
     for(i=0;i<6;i++){
        if(ctrl[i]>max){
           max = ctrl[i];
        }
     }
     do{
        if(max==ctrl[0]){
           xk1=x1; xk2=x2; xk3=x3;
           x1 = (d1-b1*x2-c1*x3)/a1;
           x2 = (d2-a2*x1-c2*x3)/b2;
           x3 = (d3-a3*x1-b3*x2)/c3;
        }
        else if(max==ctrl[1]){
           xk1=x1; xk2=x2; xk3=x3;
           x1 = (d1-b1*x2-c1*x3)/a1;
           x2 = (d3-a3*x1-c3*x3)/b3;
           x3 = (d2-a2*x1-b2*x2)/c2;
        }
        else if(max==ctrl[2]){
           xk1=x1; xk2=x2; xk3=x3;
           x1 = (d2-b2*x2-c2*x3)/a2;
           x2 = (d1-a1*x1-c1*x3)/b1;
           x3 = (d3-a3*x1-b3*x2)/c3;
        }
        else if(max==ctrl[3]){
           xk1=x1; xk2=x2; xk3=x3;
           x1 = (d2-b2*x2-c2*x3)/a2;
           x2 = (d3-a3*x1-c3*x3)/b3;
           x3 = (d1-a1*x1-b1*x2)/c1;
        }
        else if(max==ctrl[4]){
           xk1=x1; xk2=x2; xk3=x3;
           x1 = (d3-b3*x2-c3*x3)/a3;
           x2 = (d1-a1*x1-c1*x3)/b1;
           x3 = (d2-a2*x1-b2*x2)/c2;
        }
        else{
           xk1=x1; xk2=x2; xk3=x3;
           x1 = (d3-b3*x2-c3*x3)/a3;
           x2 = (d2-a2*x1-c2*x3)/b2;
           x3 = (d1-a1*x1-b1*x2)/c1;
        }
     }
     while(fabs(xk1-x1)>eps && fabs(xk2-x2)>eps && fabs(xk3-x3)>eps); 
     printf("\n\nx1 = %.2f\tx2 = %.2f\tx3 = %.2f\n\n\n",x1,x2,x3);
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}
  
void trapez(){
     float I=0.0,ust,alt,deltax,i,n;
     printf("\n<<<<<TRAPEZ YONTEMI ILE INTEGRAL ALMA>>>>>\n");
     fx_oku();
     printf("Integralin ust degerini girin: ");
     scanf("%f",&ust);
     printf("Integralin alt degerini girin: ");
     scanf("%f",&alt);
     printf("Araligin kaca bolunecegini belirten n degerini girin: ");
     scanf("%f",&n);
     deltax = (ust-alt)/n;
     for(i = alt+deltax;i<ust;i+=deltax){
        I += fx_hesapla(i);
     }
     I = I + (fx_hesapla(alt) + fx_hesapla(ust))/2;
     I = I * deltax;
     printf("\nIntegralin degeri: %.2f\n\n\n",I);
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}

void simpson(){
     float I=0.0,ust,alt,deltax,h,i,n;
     printf("\n<<<<<SIMPSON YONTEMI ILE INTEGRAL ALMA>>>>>\n");
     fx_oku();
     printf("Integralin ust degerini girin: ");
     scanf("%f",&ust);
     printf("Integralin alt degerini girin: ");
     scanf("%f",&alt);
     printf("Araligin kaca bolunecegini belirten n degerini girin (Cift sayi olmali): ");
     scanf("%f",&n);
     h = (ust-alt)/2;
     deltax = (ust-alt)/n;
     for(i = alt+deltax;i<ust;i+=deltax*2){
        I += 4* fx_hesapla(i);
        printf("\t%f",I);
     }
     for(i = alt+2*deltax;i<ust;i+=deltax*2){
        I += 2* fx_hesapla(i);
        printf("\n\t%f",I);
     }
     I = I + fx_hesapla(alt) + fx_hesapla(ust);
     I = I * (deltax/3);
     printf("\nIntegralin degeri: %.2f\n\n\n",I);
     printf("\tMenuye donmek icin bir tusa basin...\n\n");
     getch();
     system("cls");
     menu();
}
main(){
     printf("\n\t0112572 SAYISAL ANALIZ DERSI DONEM PROJESI");
     printf("\n\n\n\t                            Oguzhan Simsek");
     printf("\n\t                                  08011033");
     printf("\n\n\n\nPrograma giris yapmak icin bir tusa basin...");
     getch();
     system("cls"); 
     menu();  
     return 0;
}  
     
 
     
     
     
     
     
     
     
     
     
     
     
     
     

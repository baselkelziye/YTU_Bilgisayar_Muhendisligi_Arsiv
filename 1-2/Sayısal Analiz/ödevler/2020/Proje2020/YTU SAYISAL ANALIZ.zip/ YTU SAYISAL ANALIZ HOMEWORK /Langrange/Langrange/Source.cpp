#include<stdio.h>
#include<math.h>
  int main(){

    int n, i, j, d = 1;
    float a, s = 1, t = 1, result = 0 , x[100], y[100];
   
    printf(" enter the number of values of x and y : ");
    scanf_s("%d", &n);

    printf("\nenter values of x and y:\n");
    for (i = 1;i <= n;i++){

        printf("\nx[%d]=", i);
        scanf_s("%f", &x[i]);

        printf("y[%d]=", i);
        scanf_s("%f", &y[i]);
    }
    printf(" \n enter the value you want to calculate : ");
    scanf_s("%f", &a);

    for (i = 0; i < n; i++) {
        s = 1;
        t = 1;
            for (j = 0; j < n; j++){
                if (j != i){
                    s = s * (a - x[j]);
                    t = t * (x[i] - x[j]);
            }
        }
            result = result + ((s / t) * y[i]);
    }
    printf("\n\n The result is : %f\n", result);

    return 0;
}
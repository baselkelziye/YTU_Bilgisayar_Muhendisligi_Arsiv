#include<stdio.h>
#include<math.h>
int main() {
	int attempt = 0, step, i, degree;
	float epsilon, x, x0, Multiple[50], pre_result = 0, deltax, result = 0, rounded, value;
	printf("enter the function degree:");
	scanf_s("%d", &degree);
	for (i = 0;i <= degree;i++) {
		printf("Multiple x^%d. :", degree - i);
		scanf_s("%f", &Multiple[degree - i]);
	}
	printf("x0:");
	scanf_s("%f", &x0);
	printf("deltex:");
	scanf_s("%f", &deltax);
	printf("epsilon:");
	scanf_s("%f", &epsilon);
	x = 1;
	for (i = 0;i <= degree;i++) {
		result = result + Multiple[i] * x;
		x = x * x0;
	}
	pre_result = result;
	step = 1;
	while (step < 100 && attempt == 0) {
		result = 0;
		x = 1;
		x0 += deltax;
		for (i = 0; i <= degree; i++) {
			result = result + Multiple[i] * x;
			x = x * x0;
		}
		value = fabs(pre_result - result);
		if (x0 * result > 0) {
			if (value <= epsilon) {
				printf("\nEquation solved in %d. step. \nRoot X = %f\n", step, rounded);
				attempt++;
			} else {
				x0 -= deltax;
				deltax /= 2;
				rounded = x0;

			}
		}
		pre_result = result;
		step++;
	}
	return 0;
}

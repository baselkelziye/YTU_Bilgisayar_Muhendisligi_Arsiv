#include<stdio.h>
#include<math.h>
int main(){

    int n, i;
    float  a, b, A, result_x = 0, result_y = 0, result_xy = 0, result_x2 = 0, x[100], y[100] ,Y[100] ;
   
    printf(" enter the number of values of x and y : ");
    scanf_s("%d", &n);

    printf("\nenter values of x and y:\n");
    for (i = 1;i <= n ;i++)
    {
        printf("\nx[%d]=", i);
        scanf_s("%f", &x[i]);

        printf("y[%d]=", i);
        scanf_s("%f", &y[i]);
    }
        for (i = 1;i <= n ;i++)
        {
            Y[i] = log(y[i]);
        }
        for (i = 1;i <= n ;i++)
        {
            result_x = result_x + x[i];
            result_y = result_y + Y[i];
            result_xy = result_xy + x[i] * Y[i];
            result_x2 = result_x2 + x[i] * x[i];

        }
        A = ((result_x2 * result_y - result_x * result_xy) * 1.0 / (n * result_x2 - result_x * result_x) * 1.0);
        b = ((n * result_xy - result_x * result_y) * 1.0 / (n * result_x2 - result_x * result_x) * 1.0);

        a = exp(A);
        printf("\n\n The funcation is Y= %f*e^%fX", a, b);
        return 0;
    }

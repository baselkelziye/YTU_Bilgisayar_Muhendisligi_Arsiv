#include<stdio.h>
#include<math.h>

 int main(){
    int n , i, j, r, mxit;
    float x[100][100], a[100], ae, max, t, s, e;
    printf("Enter the number of equations:\n");
    scanf_s("%d", &n);
   
    for (i = 0;i < n;i++) a[i] = 0;
    puts(" Eneter the elemrnts of augmented matrix rowwise\n");
    for (i = 0;i < n;i++)
    {
        for (j = 0;j < n + 1;j++)
        {
            scanf_s("%f", &x[i][j]);
        }
    }
    printf(" Eneter the allowed error and maximum number of iteration: ");
    scanf_s("%f%d", &ae, &mxit);
    printf("Iteration\tx[1]\tx[2]\n");
    for (r = 1;r <= mxit;r++)
    {
        max = 0;
        for (i = 0;i < n;i++)
        {
            s = 0;
            for (j = 0;j < n;j++)
                if (j != i) s += x[i][j] * a[j];
            t = (x[i][n] - s) / x[i][i];
            e = fabs(a[i] - t);
            a[i] = t;
        }
        printf(" %5d\t", r);
        for (i = 0;i < n;i++)
            printf(" %9.4f\t", a[i]);
        printf("\n");
        if (max < ae)
        {
            printf(" Converses in %3d iteration\n", r);
            for (i = 0;i < n;i++)
                printf("a[%3d]=%7.4f\n", i + 1, a[i]);
          
        }

    } 
    return 0;
}
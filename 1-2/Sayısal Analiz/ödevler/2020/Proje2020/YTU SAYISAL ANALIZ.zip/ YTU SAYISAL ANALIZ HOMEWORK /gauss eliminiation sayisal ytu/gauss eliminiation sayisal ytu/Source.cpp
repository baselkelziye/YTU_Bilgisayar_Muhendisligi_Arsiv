#include <stdio.h>
int main(){
    int i, j, m;
    float current_row, matrix[50][50], results[50];

    printf("Dimension of Matrix : ");
    scanf_s("%d", &m);

    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
            printf("matrix[%d][%d] : ", i, j);
            scanf_s("%f", &matrix[i][j]);
        }
    }
    for (i = 0; i < m; i++) {
        printf("results[%d] : ", i);
        scanf_s("%f", &results[i]);
    }
    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
            matrix[i][j] = matrix[i][j] / matrix[i][i];
        }
        results[i] = results[i] / matrix[i][i];
    }
    printf("\n\nMATRIX :\n");
    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
            printf("%.3f  ", matrix[i][j]);
        }
        printf("| %f\n", results[i]);
    }
    return 0;
}

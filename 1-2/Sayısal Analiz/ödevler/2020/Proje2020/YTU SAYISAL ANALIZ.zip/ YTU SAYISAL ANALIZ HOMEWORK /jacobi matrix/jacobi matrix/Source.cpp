#include <stdio.h>
#include <math.h>
int main() {

    int i, j, k, n, m, temp, stop = 0;
    float x, sum, value, epsilon, max = 0, constant[100], pre_result[100], result[100],  matrix[100][100];

    printf("Enter epsilon : ");
    scanf_s("%f", &epsilon);

    printf("Dimension of Matrix : ");
    scanf_s("%d", &n);
    
    for (i = 0; i < n; i++) {
        printf("\nfuncation number : %d\n\n ",i+1);
        for (j = 0; j < n; j++) {
            printf("Multiple of x%d : ", j + 1); 
            scanf_s("%f", &matrix[i][j]);
        }

        printf("Enter the constant : "); 
        scanf_s("%f", &constant[i]);
        printf("\n"); }

    for ( i = 0; i < n; i++) {
        max = matrix[i][i];
        for ( j = i; j < n; j++) {
            if (fabs(matrix[j][i]) > max) {
                for ( k = 0; k < n; k++) {
                    temp = matrix[i][k];
                    matrix[i][k] = matrix[j][k];
                    matrix[j][k] = temp;
                    temp = constant[i];
                    constant[i] = constant[j];
                    constant[j] = temp; }
            }
        }
    }
    for ( i = 0; i < n; i++) {
        result[i] = 1;
    }

    while (stop == 0) {
        for ( i = 0; i < n; i++) {
            sum = 0;
            for ( j = 0; j < n; j++) {
                if (i != j) {
                    sum = sum + result[j] * matrix[i][j];
                }
            }
            pre_result[i] = (-sum + constant[i]) / matrix[i][i]; }
        k = 0;
        for ( i = 0; i < n; i++) {
            value = fabs(result[i] - pre_result[i]);
            result[i] = pre_result[i];
            if (value <= epsilon) {
                k++;
            }
        }
        if (k == n) {
            stop = 1;
        }
    }
    for ( i = 0; i < n; i++) {
        printf("x%d : %f\n", i + 1, pre_result[i]);
    }
    return 0;
}
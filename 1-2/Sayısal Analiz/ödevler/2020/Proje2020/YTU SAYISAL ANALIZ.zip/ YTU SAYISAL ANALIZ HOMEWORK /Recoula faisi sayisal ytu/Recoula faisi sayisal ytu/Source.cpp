#include<stdio.h>
#include<math.h>
int main() {
	int attemp = 0, step = 1, i, degree;
	float a, b, c, pre_c = 0, epsilon, x, x0, Multiple[50], pre_result = 0, result_A = 0, result_B = 0, result_C = 0, value;
	printf("enter the function degree:");
	scanf_s("%d", &degree);
	for (i = 0;i <= degree;i++) {
		printf("Multiple x^%d. :", degree - i);
		scanf_s("%f", &Multiple[degree - i]);
	}
	printf("a:");
	scanf_s("%f", &a);
	printf("b:");
	scanf_s("%f", &b);
	printf("epsilon:");
	scanf_s("%f", &epsilon);
	while (step < 100 && attemp == 0) {
		result_A = 0;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_A = result_A + Multiple[i] * x;
			x = x * a;
		}
		result_B = 0;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_B = result_B + Multiple[i] * x;
			x = x * b;
		}
		c = (b * result_A - a * result_B) / (result_A - result_B);
		result_C = 0;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_C = result_C + Multiple[i] * x;
			x = x * c;
		}
		value = fabs(c - pre_c);
		if (value <= epsilon) {
			printf("\nEquation solved in %d. step. Root X = %f\n", step, c);
			attemp++;
		}
		else {
			if (result_C * result_B > 0) {
				b = c;
			}
			else {
				a = c;
			}
		}
		pre_c = c;
		step++;
	}
	return 0;
}
#include<stdio.h>
#include<math.h>
int main() {
	int attemp = 0, step = 0, i, x0, degree;
	double epsilom, Multiple[50], value, x, G, H;
	printf("enter the function degree:");
	scanf_s("%d", &degree);
	for (i = 0;i <= degree;i++) {
		printf("Multiple x^%d. :", degree - i);
		scanf_s("%f", &Multiple[degree - i]);
	}
	printf("x:");
	scanf_s("%1F", &x);
	printf("epsilom:");
	scanf_s("%1f", &epsilom);
	while(step<100 && attemp==0){
		value = fabs(H-G );
		printf("value_G:%1f , value_H:%1f \n", G,H);
		if (value <= epsilom) {
			printf("Equation solved in %d. step. \nRoot X = %1f", step, H);
			attemp++;
		} else {
			x = 0;
			x += H;
			step++;
		}
	}
	
	return 0;
}
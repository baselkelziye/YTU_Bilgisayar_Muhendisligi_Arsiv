#include <stdio.h>

int main()
{
    int i, j, k, m;
    float static matrix[50][50], unit[50][50];
    float current_element, current_row;

    printf("Dimension of Matrix : ");
    scanf_s("%d", &m);
    for (i = 0; i < m; i++) {
        unit[i][i] = 1;
    }
    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
            printf("matrix[%d][%d] : ", i, j);
            scanf_s("%f", &matrix[i][j]);
        }
    }
    for (i = 0; i < m; i++) {
        current_element = matrix[i][i];

        for (j = 0; j < m; j++) {
            matrix[i][j] = matrix[i][j] / current_element;
            unit[i][j] = unit[i][j] / current_element;
        }
        for (k = 0; k < m; k++) {
            if (k != i) {
                current_row = matrix[k][i];
                for (j = 0; j < m; j++) {
                    matrix[k][j] = matrix[k][j] - (matrix[i][j] * current_row);
                    unit[k][j] = unit[k][j] - (unit[i][j] * current_row);
                }
            }
        }
    }
    printf("\n\nMATRIX :\n");
    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
            printf("%.3f  ", matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n\nUNIT MATRIX(INVERSE OF FIRST MATRIX) : \n");
    for (i = 0; i < m; i++) {
        for (j = 0; j < m; j++) {
            printf("%.3f  ", unit[i][j]);
        }
        printf("\n");
    }
    return 0;
}
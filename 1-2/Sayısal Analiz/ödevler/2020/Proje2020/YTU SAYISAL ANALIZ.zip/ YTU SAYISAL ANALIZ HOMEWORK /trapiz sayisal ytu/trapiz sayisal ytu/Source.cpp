#include <stdio.h>
#include <math.h>

float f(float x, float* fn)
{
    int i, d = (int)*(fn + 19);
    float result = 0;
    for (i = 0; i <= d; i++)
    {
        result += *(fn + i) * pow(x, d - i);
    }
    return result;
}

float fderivate(float x, float* fn)
{
    int i, d = (int)*(fn + 19);
    float result = 0;
    for (i = 0; i < d; i++)
    {
        result += (d - i) * *(fn + i) * pow(x, d - i - 1);
    }
    return result;
}
float* get_fn()
{
    int i, degree;
    static float fn[20];
    float x, result;
    printf("Function degree : ");
    scanf_s("%d", &degree);
    fn[19] = degree;
    for (i = 0; i <= degree; i++)
    {
        printf("Multiple of %d. degree : ", degree - i);
        scanf_s("%f", &fn[i]);
    }
    return &fn[0];
}

int main()
{
    int i;
    float bottom_limit, top_limit, x, h, n, result, * fn = get_fn();
    printf("top limit : ");
    scanf_s("%f", &top_limit);
    printf("bottom limit : ");
    scanf_s("%f", &bottom_limit);
    printf("n : ");
    scanf_s("%f", &n);
    h = (top_limit - bottom_limit) / n;
    for (i = 1; i < n; i++) {
        result += f(bottom_limit + i * h, fn);
    }
    result += (f(bottom_limit, fn) + f(top_limit, fn)) / 2;
    result = result * h;
    printf("Result : %f", result);
    return 0;
}

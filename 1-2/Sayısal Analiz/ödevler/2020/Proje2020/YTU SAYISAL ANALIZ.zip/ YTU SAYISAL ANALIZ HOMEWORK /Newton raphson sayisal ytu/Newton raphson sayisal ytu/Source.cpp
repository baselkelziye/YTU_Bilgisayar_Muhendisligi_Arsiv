#include<stdio.h>
#include<math.h>
int main() {
	int attemp = 0, step = 0, i, degree;
	float epsilon, Multiple[50], x, x0, result, result_1, result_2, derivation_FX , x1, y1, y2, delta=0.000001, value;
	printf("enter the function degree:");
	scanf_s("%d", &degree);
	for (i = 0;i <= degree;i++) {
		printf("Multiple x^%d. :", degree - i);
		scanf_s("%f", &Multiple[degree - i]);
	}
	printf("x0:");
	scanf_s("%f", &x0);
	printf("epsilon:");
	scanf_s("%f", &epsilon);

	while(step<100 && attemp==0){
		result = 0;
		result_1 = 0;
		result_2 = 0;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result = result + Multiple[i] * x;
			x = x * x0;
		}
		y1 = x0 - delta;
		y2 = x0 + delta;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_1 = result_1 + Multiple[i] * x;
			x = x * y1;
		}
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_2 = result_2 + Multiple[i] * x;
			x = x * y2;
		}
		derivation_FX = (result_2 - result_1) / (2 * delta);
		x1 = x0 - (result / derivation_FX);
		value = fabs(x1 - x0);

		if (value <= epsilon) {
			printf("\nEquation solved in %d. step. \nRoot X = %f\n", step, x1);
			attemp++;
		} else {
			x0=x1;
			step++;
		}
	}

	return 0;
}
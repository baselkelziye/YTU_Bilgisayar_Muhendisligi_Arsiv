#include<stdio.h>
#include<math.h>
int main() {
	int attemp = 0, step = 1, i, degree;
	float epsilon, x, x0, x1, x2, Multiple[50], result_0 = 0, result_1 = 0 , result_2 = 0 , value;
	printf("enter the function degree:");
	scanf_s("%d", &degree);
	for (i = 0;i <= degree;i++) {
		printf("Multiple x^%d. :", degree - i);
		scanf_s("%f", &Multiple[degree - i]);
	}
	printf("x0:");
	scanf_s("%f", &x0);
	printf("x1:");
	scanf_s("%f", &x1);
	printf("epsilon:");
	scanf_s("%f", &epsilon);

	while (step < 100 && attemp == 0) {
		result_0 = 0;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_0 = result_0 + Multiple[i] * x;
			x = x * x0;
		}
		result_1 = 0;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_1 = result_1 + Multiple[i] * x;
			x = x * x1;
		}
		x2 = x0 - ((x1 - x0) / (result_1 - result_0) * result_0);
		result_2 = 0;
		x = 1;
		for (i = 0;i <= degree;i++) {
			result_2 = result_2 + Multiple[i] * x;
			x = x * x2;
		}
		value = fabs(x2 - x0);
		if (value <= epsilon) {
			printf("\nEquation solved in %d. step .\n Root x =%f \n ", step, x2);
			attemp++;
		} else {
			x0 = x2;
			result_0 += result_2;
			step++;
		}
	}

	return 0;
}
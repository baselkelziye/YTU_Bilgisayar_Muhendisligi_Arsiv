const environment = {
    optimizationServiceUrl: 'http://localhost:11000'
}

export default environment;
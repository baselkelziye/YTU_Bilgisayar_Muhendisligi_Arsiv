import pandas as pd
from google.colab import drive
import emoji
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB, MultinomialNB
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
# !pip install emoji

# Mount Google Drive
drive.mount('/content/drive/')
# !pip install openpyxl
# Load the dataset
df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_data4.xlsx')

# Define the emoji mapping
emoji_mapping = {
    'joy': emoji.emojize(':smile:', language='alias'),
    'anger': emoji.emojize(':angry:', language='alias'),
    'sadness': emoji.emojize(':cry:', language='alias'),
    'fear': emoji.emojize(':fearful:', language='alias'),
    'disgust': emoji.emojize(':nauseated_face:', language='alias'),
    'guilt': emoji.emojize(':pensive:', language='alias'),
    'shame': emoji.emojize(':flushed:', language='alias')
}

# Add Emoji column to the dataframe
df['Emoji'] = df['Label'].map(emoji_mapping)

# Vectorize the text data
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['Text']).toarray()
y = df['Label']

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Gaussian Naive Bayes model
gnb = GaussianNB()
gnb.fit(X_train, y_train)

# Make predictions
y_pred = gnb.predict(X_test)

# Generate classification report
print("Gaussian Naive Bayes Report:\n")
print(classification_report(y_test, y_pred))

# Generate confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=emoji_mapping.keys(), yticklabels=emoji_mapping.keys())
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix - Gaussian Naive Bayes')
plt.show()

# Train Multinomial Naive Bayes model
mnb_classifier = MultinomialNB()
mnb_classifier.fit(X_train, y_train)
y_pred_mnb = mnb_classifier.predict(X_test)
print("Multinomial NB Classification Report:")
print(classification_report(y_test, y_pred_mnb))

# Confusion Matrix for Multinomial NB
cm_mnb = confusion_matrix(y_test, y_pred_mnb)
plt.figure(figsize=(10, 7))
sns.heatmap(cm_mnb, annot=True, fmt='d', cmap='Blues', xticklabels=emoji_mapping.keys(), yticklabels=emoji_mapping.keys())
plt.title('Confusion Matrix - Multinomial Naive Bayes')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()


gnb_classifier = GaussianNB()
gnb_classifier.fit(X_train, y_train)
y_pred_gnb = gnb_classifier.predict(X_test)
print("Gaussian NB Classification Report:")
print(classification_report(y_test, y_pred_gnb))


cm_gnb = confusion_matrix(y_test, y_pred_gnb)
plt.figure(figsize=(10, 7))
sns.heatmap(cm_gnb, annot=True, fmt='d', cmap='Blues', xticklabels=emoji_mapping.keys(), yticklabels=emoji_mapping.keys())
plt.title('Confusion Matrix - Gaussian Naive Bayes')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()
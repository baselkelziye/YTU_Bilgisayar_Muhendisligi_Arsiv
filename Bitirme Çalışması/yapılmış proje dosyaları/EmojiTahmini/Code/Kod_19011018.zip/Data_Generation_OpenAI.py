# !pip install openai
# !openai migrate

import openai
import os

# Set up your OpenAI API key
openai_API_KEY = ""

import pandas as pd
from google.colab import drive

# Mount Google Drive
drive.mount('/content/drive/')

# Load the dataset
df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_data4.xlsx')
df.head()

df = df.head(1000)

from openai import OpenAI
client = OpenAI(
    api_key=openai_API_KEY
)

for i, row in df.head(15).iterrows():
    print(f"Text: {row['Text']}")

#Preparing the generator model with proper prompt to generate compatible data
completion = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a helpful assistant. You will generate a tweet for each prompt."},
        {"role": "user", "content": "Create a new sentence expressing the emotion of 'fear'. Respond in Turkish. Example text: Bir trafik kazasına karıştığım zaman.\nNew Text:"}
    ],
    temperature=0.7,
    max_tokens=100,
    )

print("Sample generated text for label 'fear':")
completion.choices[0].message.content

# Function to generate data according to the given text and label pairs.
def generate_text_based_on_label(text, label):
    prompt = f"Create a new sentence expressing the emotion of '{label}'. Respond in Turkish. Example text: {text}.\nNew Text:"

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant. You will generate a tweet for each prompt."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.5,
        max_tokens=150
    )

    new_text = response.choices[0].message.content.strip()
    return new_text

# Parameters
save_interval = 10  # Save after every 10 generations
save_path = '/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/generated_texts_openai.xlsx'

def save_generated_texts(generated_texts, save_path):
    df_generated = pd.DataFrame(generated_texts)
    df_generated.to_excel(save_path, index=False)
    print(f"Data saved to {save_path}")

# Initialize list to hold generated texts
generated_texts = []

# Loop through the dataset and save data to excel file.
for i, row in df.iterrows():
    text, label = row['Text'], row['Label']
    new_text = generate_text_based_on_label(text, label)
    generated_texts.append({"Text": new_text, "Label": label})

    # Print the progress
    print(f"Generated {i + 1}/{len(df)}: {new_text}")

    # Save at intervals
    if (i + 1) % save_interval == 0:
        save_generated_texts(generated_texts, save_path)

# Save any remaining texts after the loop
if len(generated_texts) % save_interval != 0:
    save_generated_texts(generated_texts, save_path)
    print(f"All entries processed and saved.")
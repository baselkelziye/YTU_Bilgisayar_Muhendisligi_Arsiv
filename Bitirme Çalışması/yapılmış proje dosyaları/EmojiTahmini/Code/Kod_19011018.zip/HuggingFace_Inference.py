# !pip install aiohttp
# !pip install --upgrade huggingface_hub[inference]
# !pip install asyncio
# !pip install --upgrade huggingface_hub
# !pip install minijinja
# !pip install openpyxl

import json
import os
import pandas as pd
from huggingface_hub import AsyncInferenceClient, InferenceClient, notebook_login
import asyncio
import aiohttp
from google.colab import drive

drive.mount('/content/drive/')

# Load the dataset
df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_data4.xlsx')
df = df.head(1000)  # Select the first 1000 entries

# Convert the dataset to a list of dictionaries
data = df.to_dict(orient='records')

os.environ["HF_TOKEN"] = ""

notebook_login()

client = AsyncInferenceClient("meta-llama/Meta-Llama-3-8B")
#https://api-inference.huggingface.co/models/meta-llama/Meta-Llama-3-8B
# meta-llama/Meta-Llama-3-8B

# tweet = """Biri benden bir şey yapmamı istedi, ben de bir bahane uydurup hayır dedim. Daha sonra gittim ve aynı şeyi başka biriyle yapmadım ve ilk kişinin asla öğrenmemesini umdum."""
# label = "guilt"

# chat = [
#     {
#         "role": "system",
#         "content": "You are a helpful assistant. Tweets always in Turkish. Labels stay English original. Only respond with the tweet and its label. Do not write anything else.  Example output: tweet\n\nlabel"
#     },
#     {
#         "role": "user",
#         "content": f"Can you generate a tweet and its corresponding emoji label using the below example please? Generate tweet with the label that i provided to you by example.  tweet: {tweet} label: {label}"
#     },
# ]

# chat[1]["content"]

# response = await client.chat_completion(chat, max_tokens=512, temperature=0.1)
# from transformers import pipeline
# generator = pipeline('text-generation', model = 'HuggingFaceH4/zephyr-7b-beta')
# generator("Hello, I'm a language model", max_length = 30, num_return_sequences=1)
## [{'generated_text': "Hello, I'm a language modeler. So while writing this, when I went out to meet my wife or come home she told me that my"},
##  {'generated_text': "Hello, I'm a language modeler. I write and maintain software in Python. I love to code, and that includes coding things that require writing"}, ...

response = "slm"
print(response.choices[0].message.content)

# response

# Sample dataset
# data = [
#     {"tweet": "Ailem tüm arkadaşlarımın katıldığı sosyal bir etkinliğe gitmeme izin vermedi.", "label": "anger"},
#     {"tweet": "10 yıldır Yeni Zelanda dışında olan ağabeyim, ailemizden hiçbirinin daha önce tanışmadığı eşiyle birlikte ziyarete geldiğinde.", "label": "joy"},
#     {"tweet": "Benim yaşlarımda, tanımadığım yaklaşık 200 kişilik bir dinleyici kitlesine tarihi bir olayla ilgili bir konuşma yapmam gerektiğinde.", "label": "fear"},
#     {"tweet": "3 haftadır sadece bir kez görüştüğüm büyükbabam birkaç ay sonra öldüğünde. Gerçekten çok üzüldüm çünkü o çok iyi bir insandı ve onun yanında kalacak maddi imkanım yoktu.", "label": "sadness"},
#     {"tweet": "İlk defa erkek arkadaşımla birlikte evden ayrıldım ve nerede kalacağımız konusunda yalan söyledim.", "label": "guilt"},
#     {"tweet": "Bir keresinde yolun yukarısında yaşlı bir adamın çöp kutularını ve olukları karıştırdığını gördüm. İlk başta gerçekten tiksinmiştim ama o zamandan beri onu birkaç kez gördüm ve şimdi onun için gerçekten üzülüyorum ve onu gördüğümde sık sık ona sigara veriyorum, çünkü çoğunlukla sigara izmaritlerinin peşinden gidiyor ve bu iğrenç.", "label": "disgust"},
#     {"tweet": "Ben 15 yaşımdayken annem odamda 15 yaşındaki çocukların bulundurması beklenmeyen çeşitli eşyalar keşfetti; çoğunlukla alkol, esrar ve doğum kontrol hapları!", "label": "shame"},
# ]

import time
# Function to generate tweet through Inference Client
async def generate_tweet(client, tweet, label):
    chat = [
        {
            "role": "system",
            "content": "You are a helpful assistant. Tweets are always in Turkish. Only respond with the tweet. Do not write anything else."
        },
        {
            "role": "user",
            "content": f"Please generate a tweet for the given label. tweet: {tweet} label: {label}"
        },
    ]

    for i in range(5):
        try:
            response = await client.chat_completion(chat, max_tokens=256, temperature=0.1)
            return response.choices[0].message.content
        except aiohttp.ClientResponseError as e:
            if e.status == 429:
                print(f"Too many requests. Retrying in {i+1} seconds...")
                time.sleep(i+1)
            else:
                raise e

    raise Exception("Failed to generate tweet after 5 retries.")

async def main():
    generated_data = []

    # Check if there is a partial result file and load it
    output_file = '/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/generated_tweets.xlsx'
    if os.path.exists(output_file):
        df_existing = pd.read_excel(output_file)
        generated_data = df_existing.to_dict('records')
        start_index = len(generated_data)
    else:
        start_index = 0

    for i, record in enumerate(data[start_index:], start=start_index):
        response = await generate_tweet(client, record['Text'], record['Label'])
        generated_data.append({"tweet": response, "label": record['Label']})

        # Print progress
        print(f"Generated {i+1} entries")

        # Save progress every 10 entries
        if (i+1) % 10 == 0:
            df_generated = pd.DataFrame(generated_data)
            df_generated.to_excel(output_file, index=False)
            print(f"Progress saved to {output_file}")

    # Final save
    df_generated = pd.DataFrame(generated_data)
    df_generated.to_excel(output_file, index=False)
    print(f"Final data saved to {output_file}")

await main()

# Read the excel file
import pandas as pd
import re
pd.set_option('display.max_colwidth', None)
df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/generated_tweets.xlsx')
# tweet sütununu generated tweet olarak dğeişitir
df.rename(columns={'tweet': 'generated_tweet'}, inplace=True)
df.head(10)

# @title label

from matplotlib import pyplot as plt
import seaborn as sns
df.groupby('label').size().plot(kind='barh', color=sns.palettes.mpl_palette('Dark2'))
plt.gca().spines[['top', 'right',]].set_visible(False)
# title of the plot: "selam"
plt.title("Label Distribution of Generated Tweets")
plt.show()
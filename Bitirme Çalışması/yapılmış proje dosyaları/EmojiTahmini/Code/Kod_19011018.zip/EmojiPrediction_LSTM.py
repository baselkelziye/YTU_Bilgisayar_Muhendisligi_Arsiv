import pandas as pd
from google.colab import drive
import numpy as np
import re
import emoji
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import LSTM, Embedding, Dense, Dropout, SpatialDropout1D, Bidirectional
from keras.callbacks import EarlyStopping
from keras.utils import to_categorical
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, precision_recall_fscore_support
import itertools
import nltk
import string

# @title Required Packages
# !pip install emoji
# !pip install openpyxl
# !pip install tensorflow

drive.mount('/content/drive/')

df1 = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_data4.xlsx')
df2 = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/generated_texts_openai.xlsx')
#!pip install openpyxl

# prompt: df2'yi df1'in üstüne ekle birleştir

import pandas as pd
df_merged = pd.concat([df1, df2], ignore_index=True)
df_merged

# prompt: label çeşitlerini yazdır

print(df_merged['Label'].value_counts())

# Define the emoji mapping
emoji_mapping = {
    'joy': emoji.emojize(':smile:', language='alias'),
    'anger': emoji.emojize(':angry:', language='alias'),
    'sadness': emoji.emojize(':cry:', language='alias'),
    'fear': emoji.emojize(':fearful:', language='alias'),
    'disgust': emoji.emojize(':nauseated_face:', language='alias'),
    'guilt': emoji.emojize(':pensive:', language='alias'),
    'shame': emoji.emojize(':flushed:', language='alias')
}
# emoji_mapping = {
#     'kızgın' : emoji.emojize(':angry_face:', language='alias'),
#     'korku' : emoji.emojize(':fearful:', language='alias'),
#     'mutlu' : emoji.emojize(':smile:', language='alias'),
#     'üzgün' : emoji.emojize(':crying_face:', language='alias'),
#     'surpriz' : emoji.emojize(':astonished_face:', language='alias')

# }
emoji_mapping

# Access the dataset and load it as a dataframe
drive.mount('/content/drive/')
df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_dataset.xlsx')
df['Emoji'] = df['Label'].map(emoji_mapping)
df

# @title Text counts for each label
# df1['Etiket'].value_counts().plot(kind='barh', color=sns.palettes.mpl_palette('Dark2'))
# plt.gca().spines[['top', 'right',]].set_visible(False)

df_merged['Label'].value_counts().plot(kind='barh', color=sns.palettes.mpl_palette('Dark2'))
plt.gca().spines[['top', 'right',]].set_visible(False)
plt.xlabel('Text Count')
plt.ylabel('Label')
plt.title('Text counts for each label')
plt.show()

# prompt: nan rowları kaldır

df1 = df1.dropna()

# @title Preprocess text data

# nltk.download('stopwords')
def preprocess_text(text):
    stop_words = set(nltk.corpus.stopwords.words('turkish'))
    text = text.lower()
    text = re.sub(r'@\w+', '', text)  # Remove mentions
    text = re.sub(r'#\w+', '', text)  # Remove hashtags
    text = re.sub(r'http\S+', '', text)  # Remove URLs
    text = ''.join([char for char in text if char not in string.punctuation])
    text = ' '.join([word for word in text.split() if word not in stop_words])
    return text

df_merged['Text'] = df_merged['Text'].apply(preprocess_text)
df_merged

# Random Over Sampling to balance the dataset
ros = RandomOverSampler(random_state=42)
X_ros, y_ros = ros.fit_resample(df1['Text'].values.reshape(-1, 1), df1['Label'].values)

# Convert X_ros back from 2D to 1D
X_ros = X_ros.flatten()

# Vectorization of text using CountVectorizer for demonstration
vectorizer = CountVectorizer()
X_vectorized = vectorizer.fit_transform(X_ros)

# Split the dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y_ros, test_size=0.2, random_state=42)

# Visualizing the balanced classes
plt.figure(figsize=(8, 5))
sns.countplot(x=y_train)
plt.title('Frequency of Each Class after Resampling')
plt.xlabel('Emojis')
plt.ylabel('Frequency')
plt.show()

# Encode labels
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(df_merged['Label'])
categorical_labels = to_categorical(encoded_labels)

# Split the dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(padded_sequences, categorical_labels, test_size=0.2, random_state=42)

# Class weights to handle imbalance
class_weights = {i : max(np.bincount(encoded_labels)) / count for i, count in enumerate(np.bincount(encoded_labels))}

# LSTM Model building
model = Sequential([
    Embedding(input_dim=10000, output_dim=50, input_length=40),
    SpatialDropout1D(0.2),
    Bidirectional(LSTM(128, dropout=0.2, recurrent_dropout=0.2)),
    Dropout(0.2),
    Dense(len(emoji_mapping), activation='softmax')
])

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

# Early stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)

# Train the model
history = model.fit(X_train, y_train, epochs=20, batch_size=64, validation_data=(X_test, y_test), callbacks=[early_stopping], class_weight=class_weights, verbose=1)

# Plotting training history
plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy for Merged Dataset (gpt-3.5-turbo)')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss for Merged Dataset (gpt-3.5-turbo)')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.show()

from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_recall_fscore_support

# Predict classes with the model
predictions = model.predict(X_test)
predicted_classes = np.argmax(predictions, axis=1)
true_classes = np.argmax(y_test, axis=1)

# Calculate accuracy, precision, recall, and F1 score
accuracy = accuracy_score(true_classes, predicted_classes)
precision, recall, f1, _ = precision_recall_fscore_support(true_classes, predicted_classes, average='weighted')

print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1 Score: {f1:.4f}")

# Classification report
print("Bidirectional LSTM Report - Merged Dataset (gpt-3.5-turbo)")
print(classification_report(true_classes, predicted_classes, target_names=label_encoder.classes_))

# Confusion matrix
cm = confusion_matrix(true_classes, predicted_classes)
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
plt.title('Confusion Matrix - Bidirectional LSTM for Merged Dataset (gpt-3.5-turbo)')
plt.ylabel('Actual Class')
plt.xlabel('Predicted Class')
plt.show()

# Plotting training history (if not already plotted)
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()

plt.tight_layout()
plt.show()

import itertools

def plot_confusion_matrix(cm, classes, normalize=True, title='Confusion Matrix', cmap=plt.cm.Blues):
    plt.figure(figsize=(10, 10))
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix - Bidirectional LSTM")
    else:
        print('Confusion matrix, without normalization - Bidirectional LSTM')

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment='center',
                 color='white' if cm[i, j] > thresh else 'black')

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.show()

# Predict classes with the model
predictions = model.predict(X_test)
predicted_classes = np.argmax(predictions, axis=1)
true_classes = np.argmax(y_test, axis=1)

# Calculate accuracy, precision, recall, and F1 score
accuracy = accuracy_score(true_classes, predicted_classes)
precision, recall, f1, _ = precision_recall_fscore_support(true_classes, predicted_classes, average='weighted')

print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1 Score: {f1:.4f}")

# Classification report
print(classification_report(true_classes, predicted_classes, target_names=label_encoder.classes_))

# Confusion matrix
cm = confusion_matrix(true_classes, predicted_classes)
plot_confusion_matrix(cm, label_encoder.classes_, normalize=True, title='Normalized Confusion Matrix - Bidirectional LSTM Merged dataset (gpt-3.5-turbo)')

# Plotting training and validation accuracy
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend(loc='upper left')

# Plotting training and validation loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend(loc='upper right')

plt.tight_layout()
plt.show()
import pandas as pd
from google.colab import drive
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, accuracy_score, classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from transformers import EarlyStoppingCallback, Trainer, TrainingArguments, AutoModelForSequenceClassification

# !pip install transformers[torch]
# !pip install transformers
# !pip install openpyxl
# !pip install datasets
# !pip install accelerate -U
# !pip install torch
# !pip install accelerate==0.21.0
# ! pip install -U accelerate
# ! pip install -U transformers

drive.mount('/content/drive/')

train_df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_dataset_train.xlsx')
test_df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_dataset_test.xlsx')
print("Train data: ", train_df.shape)
print("Test data", test_df.shape)

from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
import torch
from datasets import Dataset, DatasetDict

# BERT Tokenizer
tokenizer = AutoTokenizer.from_pretrained('dbmdz/bert-base-turkish-128k-uncased')

# Veriyi tokenize etme fonksiyonu
def tokenize_and_encode(examples):
    tokenized_inputs = tokenizer(examples['Text'], padding="max_length", truncation=True, max_length=128)
    tokenized_inputs['labels'] = examples['Label']
    return tokenized_inputs

# Pandas DataFrame'leri Hugging Face Dataset objelerine dönüştürme
train_dataset = Dataset.from_pandas(train_df)
test_dataset = Dataset.from_pandas(test_df)

# DatasetDict oluşturma
data_splits = DatasetDict({
    'train': train_dataset,
    'test': test_dataset
})

# Veriyi tokenize etme
data_encoded = data_splits.map(tokenize_and_encode, batched=True)

# Etiketleri sayısal formata çevirme
label_encoder = {label: i for i, label in enumerate(train_df['Label'].unique())}
num_labels = len(label_encoder)
data_encoded = data_encoded.map(lambda examples: {'labels': [label_encoder[label] for label in examples['Label']]}, batched=True)

# Modeli yükle
model = AutoModelForSequenceClassification.from_pretrained('dbmdz/bert-base-turkish-128k-uncased', num_labels=num_labels).to('cuda' if torch.cuda.is_available() else 'cpu')

# Eğitim argümanları
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="steps",
    eval_steps=50,  # Değerlendirme adımları
    logging_steps=10,
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=10,  # Daha fazla epoch belirleyin
    weight_decay=0.01,
    logging_dir='./logs',
    load_best_model_at_end=True,
    metric_for_best_model='f1',
    greater_is_better=True
)

early_stopping_callback = EarlyStoppingCallback(
    early_stopping_patience=3  
)

# Performans metriği hesaplama fonksiyonu
def compute_metrics(p):
    preds = np.argmax(p.predictions, axis=1)
    labels = p.label_ids
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='weighted')
    acc = accuracy_score(labels, preds)
    return {
        'accuracy': acc,
        'f1': f1,
        'precision': precision,
        'recall': recall
    }

# Trainer başlatma
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=data_encoded['train'],
    eval_dataset=data_encoded['test'],
    compute_metrics=compute_metrics,
    callbacks=[early_stopping_callback]
)

# Modeli eğitme
trainer.train()

# Test veri seti üzerinde tahminler yapma ve değerlendirme
results = trainer.predict(test_dataset=data_encoded['test'])
print("Performance metrics for initial dataset")
print(f"Accuracy: {results.metrics['test_accuracy']}")
print(f"F1 Score: {results.metrics['test_f1']}")
print(f"Precision: {results.metrics['test_precision']}")
print(f"Recall: {results.metrics['test_recall']}")

# Classification Report ve Confusion Matrix oluşturma
y_true = data_encoded['test']['labels']
y_pred = np.argmax(results.predictions, axis=1)

print("\nBERT Classification Report for initial dataset:")
print(classification_report(y_true, y_pred, target_names=label_encoder.keys()))

print("BERT - Confusion Matrix for initial dataset:")
cm = confusion_matrix(y_true, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=label_encoder.keys(), yticklabels=label_encoder.keys())
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('BERT - Confusion Matrix for initial dataset:')
plt.show()

# @title Merged Dataset (Mistral)

train_df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_dataset_train.xlsx')
generated_tweets_mistral = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/generated_tweets_mistral.xlsx')
# train_df ve generated_tweets birleştir
merged_df = pd.concat([train_df, generated_tweets_mistral], ignore_index=True)
print("Train data: ", train_df.shape)
print("Generated Tweets: ", generated_tweets_mistral.shape)
print("Merged Dataset: ", merged_df.shape)

test_df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_dataset_test.xlsx')
print("Train data: ", merged_df.shape)
print("Test data", test_df.shape)

from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
import torch
from datasets import Dataset, DatasetDict

# BERT Tokenizer
tokenizer = AutoTokenizer.from_pretrained('dbmdz/bert-base-turkish-128k-uncased')

# Veriyi tokenize etme fonksiyonu
def tokenize_and_encode(examples):
    tokenized_inputs = tokenizer(examples['Text'], padding="max_length", truncation=True, max_length=128)
    tokenized_inputs['labels'] = examples['Label']
    return tokenized_inputs

# Pandas DataFrame'leri Hugging Face Dataset objelerine dönüştürme
train_dataset = Dataset.from_pandas(merged_df)
test_dataset = Dataset.from_pandas(test_df)

# DatasetDict oluşturma
data_splits = DatasetDict({
    'train': train_dataset,
    'test': test_dataset
})

# Veriyi tokenize etme
data_encoded = data_splits.map(tokenize_and_encode, batched=True)

# Etiketleri sayısal formata çevirme
label_encoder = {label: i for i, label in enumerate(merged_df['Label'].unique())}
num_labels = len(label_encoder)
data_encoded = data_encoded.map(lambda examples: {'labels': [label_encoder[label] for label in examples['Label']]}, batched=True)

# Modeli yükle
model = AutoModelForSequenceClassification.from_pretrained('dbmdz/bert-base-turkish-128k-uncased', num_labels=num_labels).to('cuda' if torch.cuda.is_available() else 'cpu')

# Eğitim argümanları
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="steps",
    learning_rate=2e-5,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    num_train_epochs=3,
    weight_decay=0.01,
    logging_dir='./logs',
    logging_steps=10,
    load_best_model_at_end=True,
    metric_for_best_model='f1'
)

early_stopping_callback = EarlyStoppingCallback(
    early_stopping_patience=5  
)

# Performans metriği hesaplama fonksiyonu
def compute_metrics(p):
    preds = np.argmax(p.predictions, axis=1)
    labels = p.label_ids
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='weighted')
    acc = accuracy_score(labels, preds)
    return {
        'accuracy': acc,
        'f1': f1,
        'precision': precision,
        'recall': recall
    }

# Trainer başlatma
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=data_encoded['train'],
    eval_dataset=data_encoded['test'],
    compute_metrics=compute_metrics,
    callbacks=[early_stopping_callback]
)

# Modeli eğitme
trainer.train()

# Test veri seti üzerinde tahminler yapma ve değerlendirme
results = trainer.predict(test_dataset=data_encoded['test'])
print("Performance metrics: for merged dataset (Mistral)")
print(f"Accuracy: {results.metrics['test_accuracy']}")
print(f"F1 Score: {results.metrics['test_f1']}")
print(f"Precision: {results.metrics['test_precision']}")
print(f"Recall: {results.metrics['test_recall']}")

# Classification Report ve Confusion Matrix oluşturma
y_true = data_encoded['test']['labels']
y_pred = np.argmax(results.predictions, axis=1)

print("\nBERT Classification Report for merged dataset (Mistral)")
print(classification_report(y_true, y_pred, target_names=label_encoder.keys()))

print("BERT - Confusion Matrix for merged dataset (Mistral)")
cm = confusion_matrix(y_true, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=label_encoder.keys(), yticklabels=label_encoder.keys())
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('BERT - Confusion Matrix for merged dataset (Mistral)')
plt.show()

# @title gpt-3.5-turbo

train_df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_dataset_train.xlsx')
generated_texts_openai = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/generated_texts_openai.xlsx')

merged_df = pd.concat([train_df, generated_texts_openai], ignore_index=True)
print("Train data: ", train_df.shape)
print("Generated texts: ", generated_texts_openai.shape)
print("Merged Dataset: ", merged_df.shape)

test_df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_dataset_test.xlsx')
print("Train data: ", merged_df.shape)
print("Test data", test_df.shape)

from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
import torch
from datasets import Dataset, DatasetDict

# BERT Tokenizer
tokenizer = AutoTokenizer.from_pretrained('dbmdz/bert-base-turkish-128k-uncased')

# Veriyi tokenize etme fonksiyonu
def tokenize_and_encode(examples):
    tokenized_inputs = tokenizer(examples['Text'], padding="max_length", truncation=True, max_length=128)
    tokenized_inputs['labels'] = examples['Label']
    return tokenized_inputs

# Pandas DataFrame'leri Hugging Face Dataset objelerine dönüştürme
train_dataset = Dataset.from_pandas(merged_df)
test_dataset = Dataset.from_pandas(test_df)

# DatasetDict oluşturma
data_splits = DatasetDict({
    'train': train_dataset,
    'test': test_dataset
})

# Veriyi tokenize etme
data_encoded = data_splits.map(tokenize_and_encode, batched=True)

# Etiketleri sayısal formata çevirme
label_encoder = {label: i for i, label in enumerate(merged_df['Label'].unique())}
num_labels = len(label_encoder)
data_encoded = data_encoded.map(lambda examples: {'labels': [label_encoder[label] for label in examples['Label']]}, batched=True)

# Modeli yükle
model = AutoModelForSequenceClassification.from_pretrained('dbmdz/bert-base-turkish-128k-uncased', num_labels=num_labels).to('cuda' if torch.cuda.is_available() else 'cpu')

# Eğitim argümanları
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="steps",
    eval_steps=50,  # Değerlendirme adımları
    logging_steps=10,
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=10,  # Daha fazla epoch belirleyin
    weight_decay=0.01,
    logging_dir='./logs',
    load_best_model_at_end=True,
    metric_for_best_model='f1',
    greater_is_better=True
)

early_stopping_callback = EarlyStoppingCallback(
    early_stopping_patience=3  # Metriğin iyileşmediği maksimum adım sayısı
)

# Performans metriği hesaplama fonksiyonu
def compute_metrics(p):
    preds = np.argmax(p.predictions, axis=1)
    labels = p.label_ids
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='weighted')
    acc = accuracy_score(labels, preds)
    return {
        'accuracy': acc,
        'f1': f1,
        'precision': precision,
        'recall': recall
    }

# Trainer başlatma
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=data_encoded['train'],
    eval_dataset=data_encoded['test'],
    compute_metrics=compute_metrics,
    callbacks=[early_stopping_callback]
)

# Modeli eğitme
trainer.train()

# Test veri seti üzerinde tahminler yapma ve değerlendirme
results = trainer.predict(test_dataset=data_encoded['test'])
print("Performance metrics: for merged dataset (gpt-3.5-turbo)")
print(f"Accuracy: {results.metrics['test_accuracy']}")
print(f"F1 Score: {results.metrics['test_f1']}")
print(f"Precision: {results.metrics['test_precision']}")
print(f"Recall: {results.metrics['test_recall']}")

# Classification Report ve Confusion Matrix oluşturma
y_true = data_encoded['test']['labels']
y_pred = np.argmax(results.predictions, axis=1)

print("\nBERT Classification Report for merged dataset (gpt-3.5-turbo)")
print(classification_report(y_true, y_pred, target_names=label_encoder.keys()))

print("BERT - Confusion Matrix for merged dataset (gpt-3.5-turbo)")
cm = confusion_matrix(y_true, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=label_encoder.keys(), yticklabels=label_encoder.keys())
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('BERT - Confusion Matrix for merged dataset (gpt-3.5-turbo)')
plt.show()
import pandas as pd
from google.colab import drive
import numpy as np
import re
import emoji
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, precision_recall_fscore_support
import seaborn as sns
import matplotlib.pyplot as plt
import itertools
import nltk
import string

# Required Packages
# !pip install emoji
# !pip install openpyxl
# !pip install tensorflow

# Mount Google Drive
drive.mount('/content/drive/')

# Load the dataset
df = pd.read_excel('/content/drive/MyDrive/Colab Notebooks/Bitirme Projesi/dataset/turkish_data4.xlsx')

# Define the emoji mapping
emoji_mapping = {
    'joy': emoji.emojize(':smile:', language='alias'),
    'anger': emoji.emojize(':angry:', language='alias'),
    'sadness': emoji.emojize(':cry:', language='alias'),
    'fear': emoji.emojize(':fearful:', language='alias'),
    'disgust': emoji.emojize(':nauseated_face:', language='alias'),
    'guilt': emoji.emojize(':pensive:', language='alias'),
    'shame': emoji.emojize(':flushed:', language='alias')
}

# Add Emoji column to the dataframe
df['Emoji'] = df['Label'].map(emoji_mapping)

# Preprocess text data
nltk.download('stopwords')
def preprocess_text(text):
    stop_words = set(nltk.corpus.stopwords.words('turkish'))
    text = text.lower()
    text = re.sub(r'@\w+', '', text)  # Remove mentions
    text = re.sub(r'#\w+', '', text)  # Remove hashtags
    text = re.sub(r'http\S+', '', text)  # Remove URLs
    text = ''.join([char for char in text if char not in string.punctuation])
    text = ' '.join([word for word in text.split() if word not in stop_words])
    return text

df['Text'] = df['Text'].apply(preprocess_text)

# Count Vectorizer for feature extraction
vectorizer = CountVectorizer(max_features=5000)
X_vectorized = vectorizer.fit_transform(df['Text'])

# Encode labels
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(df['Label'])

# Split the dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, encoded_labels, test_size=0.2, random_state=42)

# Finding the best k
k_range = range(1, 50)
k_scores = []

for k in k_range:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, X_train, y_train, cv=5, scoring='accuracy')
    k_scores.append(scores.mean())

plt.figure(figsize=(10, 6))
plt.plot(k_range, k_scores, marker='o')
plt.xlabel('Value of K for KNN')
plt.ylabel('Cross-Validated Accuracy')
plt.title('KNN Classifier Accuracy for Different k Values (CountVectorizer)')
plt.show()

# Train the model with the best k value
best_k = k_range[np.argmax(k_scores)]
knn = KNeighborsClassifier(n_neighbors=best_k)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)

# Confusion matrix and classification report
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:\n", cm)

# Classification report
report = classification_report(y_test, y_pred, target_names=label_encoder.classes_, output_dict=True)
report_df = pd.DataFrame(report).transpose()

# Print the classification report as a table
print("Classification Report - KNN (CountVectorizer):\n")
display(report_df)

# Plot confusion matrix
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix - with CountVectorizer')
plt.show()
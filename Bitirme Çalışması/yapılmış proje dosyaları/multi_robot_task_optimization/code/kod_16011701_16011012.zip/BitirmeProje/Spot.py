import pygame

top_left_x = (720 - 500) // 2
top_left_y = (1280 - 500) // 2

RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 255, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)
GREY = (80, 80, 80)
GREY2 = (140, 140, 140)
TURQUOISE = (64, 224, 208)


class Spot:
    def __init__(self, row, col, width, total_rows, flag):
        self.row = row
        self.col = col
        self.x = row * width
        self.y = col * width
        self.color = WHITE
        self.neighbors = []
        self.visited = False
        self.distance = 1
        self.weight = 9999999
        self.width = width
        self.total_rows = total_rows
        self.flag = flag
        self.prev = None

    def get_difficulty(self):
        if self.is_medium():
            return 10
        if self.is_hard():
            return 15
        else:
            return 1

    def is_yellow(self):
        return self.color == YELLOW

    def make_yellow(self):
        self.color = YELLOW

    def get_pos(self):
        return self.row, self.col

    def is_red(self):
        return self.color == RED

    def is_open(self):
        return self.color == GREEN

    def is_barrier(self):
        return self.color == BLACK

    def is_start(self):
        return self.color == ORANGE

    def is_end(self):
        return self.color == TURQUOISE

    def reset(self):
        self.color = WHITE

    def make_start(self):
        self.color = ORANGE

    def make_closed(self):
        self.color = RED

    def make_open(self):
        self.color = GREEN

    def make_barrier(self):
        self.color = BLACK

    def make_medium(self):
        self.color = GREY2

    def is_medium(self):
        return self.color == GREY2

    def make_hard(self):
        self.color = GREY

    def is_hard(self):
        return self.color == GREY

    def make_end(self):
        self.color = TURQUOISE

    def make_path(self):
        self.color = PURPLE

    def draw(self, win):
        pygame.draw.rect(win, self.color, (self.x + top_left_y, self.y + top_left_x, self.width, self.width))

    def drawA(self, win):
        pygame.draw.rect(win, self.color, (self.x + 70, self.y + top_left_x + 75, self.width, self.width))

    def drawA2(self, win):
        pygame.draw.rect(win, self.color, (self.x + 70, self.y + top_left_x + 350, self.width, self.width))

    def drawD(self, win):
        pygame.draw.rect(win, self.color,
                         (self.x + top_left_y + 500 + 70, self.y + top_left_x + 75, self.width, self.width))

    def drawD2(self, win):
        pygame.draw.rect(win, self.color,
                         (self.x + top_left_y + 500 + 70, self.y + top_left_x + 350, self.width, self.width))

    def update_neighbors(self, grid):
        self.neighbors = []
        if self.row < self.total_rows - 1 and not grid[self.row + 1][self.col].is_barrier():  # DOWN
            self.neighbors.append(grid[self.row + 1][self.col])

        if self.row > 0 and not grid[self.row - 1][self.col].is_barrier():  # UP
            self.neighbors.append(grid[self.row - 1][self.col])

        if self.col < self.total_rows - 1 and not grid[self.row][self.col + 1].is_barrier():  # RIGHT
            self.neighbors.append(grid[self.row][self.col + 1])

        if self.col > 0 and not grid[self.row][self.col - 1].is_barrier():  # LEFT
            self.neighbors.append(grid[self.row][self.col - 1])

    def __lt__(self, other):
        return False

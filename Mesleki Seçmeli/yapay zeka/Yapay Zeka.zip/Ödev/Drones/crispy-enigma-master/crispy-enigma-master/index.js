const express = require('express');
const path = require('path')

const PORT = process.env.PORT || 5000

const server = express();
server.use(express.json());
server.use(express.static(path.join(__dirname, 'public')));
server.set('views', path.join(__dirname, 'view'));
server.set('view engine', 'ejs');
server.get('/', (req, res) => res.render('pages/index'))

server.listen(PORT, () => console.log(`Listening on ${ PORT }`))
const express = require('express');
const path = require('path');

const PORT = process.env.PORT || 5000;

const app = express();

const cities = require('./src/api/cities')

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'view'));
app.set('view engine', 'ejs');

app.get('/', (resquest, response) => response.render('pages/index'));

app.use('/api/cities', cities);

app.listen(PORT, () => console.log(`App running on ${PORT}`));
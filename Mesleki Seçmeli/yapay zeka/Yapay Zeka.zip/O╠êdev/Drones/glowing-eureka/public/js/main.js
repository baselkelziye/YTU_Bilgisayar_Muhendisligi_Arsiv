const windowsHeight = window.innerHeight;

$(document).ready(() => {
    $(document).foundation();

    const algorithms = {
        bfs: blindSearchUtil.bfs,
        dfs: blindSearchUtil.dfs,
        best: heuristicSearchUtil.bfs,
        astar: heuristicSearchUtil.astar
    };

    let stage;
    let searchAlgorithm = algorithms.bfs;
    let startPoint = 1;
    let endPoint = 15;
    let mapSize = 20;
    let map;
    let cityIds;

    initializeConfigurationMenu();

    drawCanvas();

    function drawCanvas() {
        $("#canvas").remove();

        const canvasDivWidth = $("#canvas-cell").width();
        const headerHeight = $("#topbar").outerHeight(true);
        const canvasHeight = windowsHeight - headerHeight - 7;
        const canvasWidth = canvasDivWidth;

        const canvas = $(`<canvas id="canvas" height=${canvasHeight} width=${canvasWidth}>Tarayıcınız canvas desteklemiyor.</canvas>`);
        canvas.appendTo('#canvas-cell');

        $('canvas').bind('contextmenu', () => {
            return false;
        });

        if (stage) {
            stage.removeAllChildren();
        }

        stage = new createjs.Stage("canvas");

        $("#map-size").change();

    }

    function initializeConfigurationMenu() {
        $("#blind-checkbox").change((event) => {
            handleCheckboxChange(event, "#blind-checkbox");
        });
        $("#heuristic-checkbox").change((event) => {
            handleCheckboxChange(event, "#heuristic-checkbox");
        });
        $("#blind-algorithms").change((event) => {
            searchAlgorithm = algorithms[event.target.selectedOptions[0].value];
        });
        $("#heuristic-algorithms").change((event) => {
            searchAlgorithm = algorithms[event.target.selectedOptions[0].value];
        });
        $("#start-point").change((event) => {
            let point = parseInt(event.target.value);
            if (cityIds.includes(point)) {
                startPoint = point;
            } else {
                event.target.value = startPoint;
            }
        });
        $("#end-point").change((event) => {
            let point = parseInt(event.target.value);
            if (cityIds.includes(point)) {
                endPoint = point;
            } else {
                event.target.value = endPoint;
            }
        });
        $("#map-size").change((event) => {
            mapSize = event.target.selectedOptions[0].value;

            $.get("api/cities?number=" + mapSize, (data) => {
                map = data.map;
                cityIds = data.cityIds;

                stage.removeAllChildren();

                var layoutRect = new createjs.Shape();
                var layoutWidth = stage.canvas.width;
                var layoutHeight = stage.canvas.height;

                let img = document.createElement("img");
                img.crossOrigin = "Anonymous";
                img.src = "imgs/romania" + mapSize + ".png";

                img.onload = function () {
                    let x = (stage.canvas.width - layoutWidth) / 2,
                        y = (stage.canvas.height - layoutHeight) / 2;

                    let m = new createjs.Matrix2D();
                    m.translate(x, y);
                    m.scale(layoutWidth / img.width, layoutHeight / img.height);

                    layoutRect.graphics.beginStroke("black")
                        .beginBitmapFill(img, "no-repeat", m)
                        .drawRect(x, y, layoutWidth, layoutHeight, 20);
                    stage.update();
                };
                stage.addChild(layoutRect);
            });
        });
        $("#search-button").click(() => {
            const result = searchAlgorithm({ cities: map, cityIds }, startPoint, endPoint);

            $("#result-button").remove();
            $("#result-modal").remove();
            $("#modal-close").remove();
            $("#queue-content").remove();

            createResultModal(result);

            setTimeout(() => $("#warning-close").click(), 3000);
        });
    }

    function handleCheckboxChange(event, checkboxId) {
        const otherCheckbox = checkboxId === "#blind-checkbox" ? $("#heuristic-checkbox") : $("#blind-checkbox");
        const selectedCheckbox = $(`#${event.target.value}`);

        if (event.target.checked) {
            if (otherCheckbox[0].checked) {
                otherCheckbox[0].checked = false;
                otherCheckbox.change();
            } else {
                selectedCheckbox[0].disabled = false;
                searchAlgorithm = algorithms[selectedCheckbox[0][selectedCheckbox[0].selectedIndex].value];
            }
        } else {
            selectedCheckbox[0].disabled = true;
            otherCheckbox[0].checked = true;
            otherCheckbox.change();
        }
    }

    function createResultModal(result) {
        const { tabs, content } = getQueueInfoTabs(result.queue);

        $("#side-menu").append(`<div id="search-warning" class="callout warning text-center" data-closable>
                        Searching complete 
                        <button id="warning-close" class="close-button" aria-label="Dismiss alert" type="button" data-close>
                            <span aria-hidden="true">&times;</span>
                        </button> 
                    </div>`);
        $("#warning-close").click(() => {
            $("#search-warning").remove();
        });
        $("#side-menu").append(`<p id="result-button"><button data-toggle="result-modal" class="button popup-button">Result</button></p>`);
        $("#canvas-cell").prepend(
            `<div id="result-modal" class="callout primary text-center aling-center" hidden data-closable data-toggler data-animate="fade-in fade-out">
                    <h1>Path ${result.success ? "found" : "could not found"}</h1> <hr>
                    <p class="lead">Going <span class="red">${map[startPoint].name}</span> to <span class="red">${map[endPoint].name}</span></p> <hr>
                    <p>Total distance: ${result.path.distance} <br>
                        ${getPathString(result.path)}
                    </p> <hr>
                    ${tabs}
                    ${content}
                    <button id="modal-close" class="close-button popup-close-button" data-close aria-label="Close modal" type="button">
                        <span aria-hidden="true">&times;</span>
                    </button>
             </div>`);

        $(document).foundation();
    }

    function getPathString(path) {
        let pathString;
        let point = path;

        if (point) {
            pathString = point.city.name;
            point = point.prevCity;
            while (point) {
                pathString = point.city.name + " > " + pathString;
                point = point.prevCity;
            }
        } else {
            pathString = "No path";
        }
        return pathString;
    }

    function getQueueInfoTabs(queue) {
        let tabs = `<ul class="tabs" data-active-collapse="true" data-tabs id="queue-info">`;
        let content = `<div id="queue-content" class="tabs-content" data-tabs-content="queue-info" data-overlay="false">`;

        for (let ind in queue) {
            tabs += `<li class="tabs-title"><a href="#iteration${ind}">Iteration ${parseInt(ind) + 1}</a></li>`;
            content += `<div class="tabs-panel" id="iteration${ind}"> 
                Selected City: <span class="red">${queue[ind].selectedCity.cityName} ${queue[ind].selectedCity.score || queue[ind].selectedCity.score == 0 ? " - " + queue[ind].selectedCity.score : ""}</span>
                <div class="table-scroll">
                    <table class="unstriped"> <tr>`;
            for (let q of queue[ind].queue) {
                content += `<td>${q.cityName} ${q.score || q.score == 0 ? " - " + q.score : ""}</td>`;
            }
            content += `</tr></table></div></div>`;
        }
        return {
            tabs: tabs + `</ul>`,
            content: content + `</div>`
        };
    }
}); 
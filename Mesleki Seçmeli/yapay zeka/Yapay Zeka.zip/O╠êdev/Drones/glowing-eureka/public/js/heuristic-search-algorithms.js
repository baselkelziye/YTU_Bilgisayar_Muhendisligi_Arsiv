const heuristicSearch = (cities, start, end, heuristic) => {
    const _cities = JSON.parse(JSON.stringify(cities.cities));
    let found = false;


    const queue = new PriorityQueue();
    const queueInfo = [];

    queue.insert({ city: _cities[start], prevCity: null, distance: 0 }, heuristic(start, 0));
    queueInfo.push({ queue: [{ cityName: _cities[start].name, score: heuristic(start, 0) }], selectedCity: { cityName: _cities[start].name } });

    let iteration = 1;
    let city;
    _cities[start].traversed = true;
    for (city = queue.remove(); city !== null; city = queue.remove()) {
        queueInfo[iteration - 1].selectedCity = { cityName: city.value.city.name, score: city.score };

        if (city.value.city.id == end) {
            found = true;
            break;
        } else {
            city.value.city.neighbors.forEach(neighbor => {
                let neighborCity = _cities[neighbor.id];
                if (!neighborCity.traversed && cities.cityIds.includes(neighborCity.id)) {
                    neighborCity.traversed = true;
                    let pathCity = {
                        city: neighborCity,
                        prevCity: city.value,
                        distance: city.value.distance + neighbor.distance
                    };
                    
                    let newNode = {
                        pathCity,
                        score: heuristic(neighborCity.id, pathCity.distance)
                    };
                    
                    queue.insert(newNode.pathCity, newNode.score);
                }
            });
            queueInfo.push({ queue: [] });
            queue.forEach(element => {
                queueInfo[iteration].queue.push({ cityName: element.value.city.name, score: element.score });
            });
        }
        iteration++;
    }

    if (city) {
        queueInfo[iteration - 1].selectedCity = { cityName: city.value.city.name, score: city.score };
    }

    return { success: found, path: city ? city.value : null, queue: queueInfo };
};

const heuristicSearchUtil = {
    astar: (cities, start, end) => heuristicSearch(cities, start, end, (id, distance) => distance + Math.floor(cities.cities[end].birdFlightDistances[id])),

    bfs: (cities, start, end) => heuristicSearch(cities, start, end, id => Math.floor(cities.cities[end].birdFlightDistances[id]))
};
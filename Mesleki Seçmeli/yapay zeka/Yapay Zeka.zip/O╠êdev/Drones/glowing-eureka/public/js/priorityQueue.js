//A binary heap data structure
//Taken from: https://gist.github.com/mperitz/3af09de5539c5bf0d3a14f72ab6b54f9

class PriorityQueue {
    constructor() {
        this.first = null;
        this.insert = this.insert.bind(this)
        this.remove = this.remove.bind(this)
        this.forEach = this.forEach.bind(this);
    }

    insert(value, score) {
        const newNode = { value, score};
        if (!this.first || score < this.first.score) {
            newNode.next = this.first;
            this.first = newNode;
        } else {
            let pointer = this.first;
            while (pointer.next && score > pointer.next.score) {
                pointer = pointer.next;
            }
            newNode.next = pointer.next;
            pointer.next = newNode;
        }
    }

    remove() {
        const first = this.first;
        if(first) {
            this.first = this.first.next;
        }
        return first;
    }

    forEach(callback) {
        let pointer = this.first;
        while(pointer) {
            callback(pointer);
            pointer = pointer.next;
        }
    }
};
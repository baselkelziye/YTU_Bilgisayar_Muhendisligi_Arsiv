const blind = (cities, start, end, handleQueue) => {
    const _cities = JSON.parse(JSON.stringify(cities.cities));

    let found = false;

    const queue = [];
    const queueInfo = [];

    queue.push({ city: _cities[start], prevCity: null, distance: 0 });
    queueInfo.push({ queue: [{ cityName: _cities[start].name }], selectedCity: { cityName: _cities[start].name } });

    let city;
    let iteration = 1;
    _cities[start].traversed = true;
    while (queue.length != 0 && !found) {
        city = handleQueue(queue);
        queueInfo[iteration - 1].selectedCity = { cityName: city.city.name };
        
        if (city.city.id == end) {
            found = true;
            break;
        } else {
            city.city.neighbors.forEach(neighbor => {
                let neighborCity = _cities[neighbor.id];
                if (!neighborCity.traversed && cities.cityIds.includes(neighborCity.id)) {
                    neighborCity.traversed = true;
                    let pathCity = {
                        city: neighborCity,
                        prevCity: city,
                        distance: city.distance + neighbor.distance
                    };
                    queue.push(pathCity);
                }
            });
            queueInfo.push({ queue: [] });
            queue.forEach(element => {
                queueInfo[iteration].queue.push({ cityName: element.city.name });
            });
        }
        iteration++;
    }
    if (city) {
        queueInfo[iteration - 1].selectedCity = { cityName: city.city.name };
    }

    return { success: found, path: city, queue: queueInfo };
};

const blindSearchUtil = {
    bfs: (cities, start, end) => blind(cities, start, end, queue => queue.shift()),

    dfs: (cities, start, end) => blind(cities, start, end, stack => stack.pop())
};
const romania = require('../../data/maps/romania.json');
const router = require("express").Router();

router.get("/", (request, response) => {
    const numberOfCities = request.query.number || 20;

    let cityIds;
    if (numberOfCities == 5) {
        cityIds = [1, 5, 13, 14, 15];
    } else if (numberOfCities == 10) {
        cityIds = [0, 1, 5, 9, 12, 13, 14, 15, 16, 19];
    } else {
        cityIds = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];
    }

    response.send({ cityIds, map: romania });
});

module.exports = router;
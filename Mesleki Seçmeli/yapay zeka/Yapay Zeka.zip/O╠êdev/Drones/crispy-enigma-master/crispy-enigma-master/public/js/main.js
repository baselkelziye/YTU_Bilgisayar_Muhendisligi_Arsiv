const windowsHeight = window.innerHeight

$(document).ready(() => {
    $(document).foundation();

    initializeConfigurationMenu();

    let stage;
    let tileSize = 50;
    let maze = {};
    let startTile;
    let finishTile;
    let mutationRate;
    let stepSize;
    let populationSize;

    drawMaze(tileSize);

    function drawMaze(tileSizeParam) {
        $("#canvas").remove();

        tileSizeParam = tileSize === tileSizeParam ? tileSize : 50;

        const canvasDivWidth = $("#canvas-cell").width();
        const headerHeight = $("#topbar").outerHeight(true);
        const canvasHeight = windowsHeight - headerHeight - ((windowsHeight - headerHeight) % tileSizeParam)
        const canvasWidth = canvasDivWidth - (canvasDivWidth % tileSizeParam);

        const canvas = $(`<canvas id="canvas" height=${canvasHeight} width=${canvasWidth}>Browser'ınız Canvas'ı desteklemiyor.</canvas>`);
        canvas.appendTo('#canvas-cell');

        $('canvas').bind('contextmenu', () => {
            return false;
        });

        if (stage) {
            stage.removeAllChildren();
        }

        stage = new createjs.Stage("canvas");

        const row = canvasHeight / tileSizeParam;
        const column = canvasWidth / tileSizeParam;

        delete maze.tiles;
        maze.tiles = generateTiles(column, row, tileSizeParam);
        maze.column = column;
        maze.row = row;

        maze.tiles.forEach(element => stage.addChild(...element));
        stage.update();
    }

    function generateTiles(column, row, tileSizeParam) {

        const _tiles = []
        for (i = 0; i < column; i++) {
            let tileRow = [];
            for (j = 0; j < row; j++) {
                let square = getSquare(tileSizeParam);
                square.x = tileSizeParam * i;
                square.y = tileSizeParam * j;
                if ((i === 0) || (i === column - 1) || j === 0 || (j === row - 1)) {
                    square.isObstacle = true;
                    paintTile(square, "red", tileSizeParam);
                } else {
                    square.isObstacle = false;
                    square.addEventListener("click", handleClick);
                }
                tileRow.push(square);
            }
            _tiles.push(tileRow);
        }

        startTile = _tiles[1][1];
        paintTile(startTile, "yellow", tileSizeParam);
        finishTile = _tiles[column - 2][row - 2];
        paintTile(finishTile, "black", tileSizeParam);

        return _tiles;
    }
    function handleClick(event) {
        let shape = event.target;
        shape.isObstacle = !shape.isObstacle;
        let color = shape.isObstacle ? "red" : "white";
        if (event.nativeEvent.button == 0) {
            if (shape !== startTile && shape !== finishTile)
                paintTile(shape, color, tileSize)
        }
        stage.update();
    }

    function paintTile(shape, color, tileSizeParam) {
        shape.graphics.clear()
            .setStrokeStyle(2)
            .beginStroke("black")
            .beginFill(color).drawRect(0, 0, tileSizeParam, tileSizeParam)
            .endFill();
    }

    function initializeConfigurationMenu() {
        $("#tileSize").on("change", (event) => {
            tileSize = event.target.selectedOptions[0].value || 50
            drawMaze(tileSize);
        })
        $("#randomObs").on("click", () => {
            generateObstacles(maze);
            stage.update()
        })
        $("#populationSize").on("change", (event) => {
            populationSize = event.target.value;
        })
        $("#mutationRate").on("change", (event) => {
            mutationRate = event.target.value;
        })
        $("#stepSize").on("change", (event) => {
            stepSize = event.target.value;
        })
    }

    function getSquare(tileSize) {
        let graphics = new createjs.Graphics().setStrokeStyle(2).beginStroke("black")
        graphics.beginFill("white").rect(0, 0, tileSize, tileSize);
        var shape = new createjs.Shape(graphics);
        return shape;
    }

    function getRndm(max) {
        return Math.floor(Math.random() * Math.floor(max));
    }

    function markAsObstacle(tile) {
        if (tile !== startTile && tile !== finishTile) {
            tile.isObstacle = true;
            tile.addEventListener("click", handleClick)
            paintTile(tile, 'red', tileSize)
        }
    }

    function generateObstacles(mazeParam) {
        if (maze === mazeParam) {
            mazeParam.tiles.forEach((elementRow, index) => {
                if (index !== 0 && index !== mazeParam.column - 1) {
                    elementRow.forEach((element, index) => {
                        if (index !== 0 && index !== mazeParam.row - 1) {
                            element.isObstacle = false
                            if (element !== startTile && element !== finishTile)
                                paintTile(element, 'white', tileSize)
                        }
                    })
                }
            });

            let eksen = getRndm(2);

            if (eksen == 0) {                                                               //dikey engel oluşturulacak
                for (i = getRndm(2) + 1; i < mazeParam.column - 1; i = i + getRndm(4)) {
                    for (j = 2; j < mazeParam.row - 2; j = j + getRndm(4)) {
                        tile = mazeParam.tiles[i][j]
                        markAsObstacle(tile)
                    }
                }
            } else if (eksen == 1) {
                for (i = getRndm(2) + 1; i < mazeParam.row - 1; i = i + 2) {
                    let yon = getRndm(2)
                    if (yon == 0) {
                        for (j = getRndm(mazeParam.column * 0.20) + 1; j < mazeParam.column - 2; j++) {
                            tile = mazeParam.tiles[j][i]
                            markAsObstacle(tile)
                        }
                    } else {
                        for (j = 1; j < getRndm(mazeParam.column * 0.60) - 2; j++) {
                            tile = mazeParam.tiles[j][i]
                            markAsObstacle(tile)
                        }
                    }
                }
            }
        }
    }
});
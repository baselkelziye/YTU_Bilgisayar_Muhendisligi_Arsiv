
# coding: utf-8

# In[1]:


import pandas as pd
import quandl


# In[6]:


df = quandl.get('wiki/googl')


# In[8]:


df = df[['Adj. Open','Adj. High','Adj. Low','Adj. Close','Adj. Volume']]


# In[9]:


df['HL %'] = (df['Adj. High'] - df['Adj. Close']) / df['Adj. Close'] * 100.0


# In[10]:


df['% CHANGE'] = (df['Adj. Close'] - df['Adj. Open']) / df['Adj. Open'] * 100.0


# In[11]:


df = df[['Adj. Close','HL %','% CHANGE','Adj. Volume']]


# In[12]:


print(df.head())


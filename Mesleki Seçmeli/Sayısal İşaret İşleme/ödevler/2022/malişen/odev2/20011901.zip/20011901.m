%%
% My DSP homework
% Muhammet Kayra Bulut
% 20011901


%%
% 2D-DFT and 2D-IDFT

myImg=(imread('mrImage.jpeg'));

[KA,MA]=size(myImg);
%2D_DFT
dft= dft2(myImg,KA,MA);
%2D-IDFT
idft=idft2(dft,KA,MA);

subplot(1,2,1), imshow(idft,[])
title('IDFT');
subplot(1,2,2), imshow(dft)
title('DFT');


%%

% Apply 2D-DFT of a grayscale image and compute the magnitude and the angle
% components of 2D-DFT. Show them in two different figures

myImg=(imread('mrImage.jpeg'));
[KA,MA]=size(myImg);
dft= dft2(myImg,KA,MA);
subplot(1,2,1), imshow(angle(fftshift(dft)),[]);
title('Angle');
subplot(1,2,2), imshow(log(abs(fftshift(dft))),[]);
title('Magnitude');

%%

% Multiply the Fourier Transform with given mask by elementwise and apply 2D-IDFT to
% the resulted image. 
myImg=(imread('mrImage.jpeg'));
maske=(imread('mask.jpeg'));

[KA,MA]=size(myImg);

dft= dft2(myImg,KA,MA);
key=fftshift(dft).*double(maske);
key=ifftshift(key);
I=idft2(key,KA,MA);
imshow (real(I),[]);
title('IDFT WITH MASK and SHIFT');
%%
%% 
function idft=idft2(myImg,KA,MA)
dft21        = zeros(KA, KA);
dft22        = zeros(MA, MA);
for v = 0 : (MA - 1)
    for y = 0 : (MA - 1)
        dft22(y+1, v+1) = exp(-2i * pi / MA * y * v);
    end    
end

for u = 0 : (KA - 1)
    for x = 0 : (KA - 1)
        dft21(u+1, x+1) = exp(2i * pi  / KA * x * u);
    end    
end



idft =(1/(KA*MA))* dft21 * double(myImg)* dft22;
end


%% My 2D-DFT code
function dft=dft2(myImg,KA,MA)
dft21        = zeros(KA, KA);
dft22        = zeros(MA, MA);
for ka = 0 : (MA - 1)
    for je = 0 : (MA - 1)
        dft22(je+1, ka+1) = exp(-2i * pi  / MA * je * ka);
    end    
end


for hu = 0 : (KA - 1)
    for ix = 0 : (KA - 1)
        dft21(hu+1, ix+1) = exp(-2i * pi / KA * ix * hu);
    end    
end



dft = dft21 * double(myImg)* dft22;
end
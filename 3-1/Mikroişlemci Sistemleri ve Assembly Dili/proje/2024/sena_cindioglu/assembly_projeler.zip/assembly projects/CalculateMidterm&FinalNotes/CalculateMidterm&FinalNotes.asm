STEK SEGMENT PARA STACK
    STK  DW 30 DUP(?)
STEK ENDS


; degerli hocam son anda odev dosyasinda vize ve final notlari icin degerler verdiginizi farkettim ama yapmaya vaktim yetmedi. 
;girdigim degerlerle cikan obp puanlari tam uyusmakta. hesaplari ekleyeyim:(hexa) 
; vize = 3F, 46,50,5A,4B,55,28,37,3C,44
;FINAL = 50,64,5A,5F,46,4B,3C,41,4E,58
;OBP = 73=49, 88=58, 86=56, 93 = 5D, 72=48,79=4F,52=34,61=3D

DSG SEGMENT PARA 'DTS'
    ogrenciSayisi DW  10
    vize          DB  63, 70, 80, 90, 75, 85, 40, 55, 60, 68     ; Midterm scores for 10 students
    bos1          DB  1 DUP(?)
    final         DB  80, 100, 90, 95, 70, 75, 60, 65, 78, 88    ; Final scores for 10 students
    bos2          DB  1 DUP(?)
    obp           DW  10 DUP(?)                                  ; Space for 10 students' overall performance scores
    bos3          DB  1 DUP(?)
    Sorted        DW  10 DUP(?)                                  ; Space for sorted scores
    scale_factor  EQU 100                                        ; Scale factor for fixed-point arithmetic
DSG ENDS

CSG SEGMENT PARA 'CODE'
                     ASSUME CS:CSG, DS:DSG, SS:STEK

BASLA PROC FAR
                     PUSH   DS
                     XOR    AX, AX
                     PUSH   AX
                     MOV    AX, DSG
                     MOV    DS, AX                     ; Set up the data segment

                     MOV    CX, ogrenciSayisi          ; Number of students
                     XOR    SI, SI                     ; Start index for arrays (0)

    hesapla_ogrenci:    
    ; Calculate midterm contribution: Midterm * 40 / 100
                     MOV    AL, [vize + SI]            ; Get midterm score
                     MOV    BL, 40                     ; 0.4 as a fixed point (40)
                     MUL    BL                         ; AL = midterm * 40
                     MOV    BL, 100                    ; Divisor
                     DIV    BL                         ; AL = (midterm * 40) / 100
                     MOV    DL, AL                     ; Store midterm contribution in DL

    ; Calculate final contribution: Final * 60 / 100
                     MOV    AL, [final + SI]           ; Get final score
                     MOV    BL, 60                     ; 0.6 as a fixed point (60)
                     MUL    BL                         ; AL = final * 60
                     MOV    BL, 100                    ; Divisor
                     DIV    BL                         ; AL = (final * 60) / 100
                     ADD    AL, DL                     ; Total = midterm contribution + final contribution

    ; Rounding and scaling
                     MOV    BX, scale_factor           ; Scale factor = 100
                     MUL    BX                         ; AX = total * scale_factor (e.g., 77.75 * 100 = 7775)
                     MOV    DX, 0                      ; Clear DX
                     DIV    BX                         ; AX = AX / 100 (integer part in AX, fraction in DX)

    ; Check the fractional part for rounding
                     MOV    BX, 50                     ; Rounding threshold
                     CMP    DX, BX                     ; Compare fractional part with 50
                     JL     below_half                 ; If less than 50, round down

    ; Round up
                     INC    AX                         ; Increment to round up
                     JMP    done

    below_half:                                        ; Round down
    ; Do nothing, AX remains unchanged

    done:            
                     MOV    [obp + SI], AX             ; Store the rounded OBP

                     INC    SI                         ; Move to the next student
                     LOOP   hesapla_ogrenci            ; Repeat for all students

    ; Sorting process
                     MOV    CX, ogrenciSayisi          ; Number of students = 10
                     DEC    CX
                     XOR    SI, SI                     ; Reset index for Sorted array
    ; Loop count (n-1)

    copy_to_sorted:  
                     MOV    AX, [obp + SI]             ; Get OBP from obp array
                     MOV    [Sorted + SI], AX          ; Copy to Sorted array
                     ADD    SI, 2                      ; Move to the next item (DW is 2 bytes)
                     LOOP   copy_to_sorted
                    
    ; Continue until all copied
    outer_loop:      
                     MOV    CX, ogrenciSayisi          ; Toplam öğrenci sayısını al
                     DEC    CX                         ; Dış döngü için n-1 ayarla

    outer_loop_start:                                  ; Dış döngünün başlangıcı
                     MOV    DX, CX                     ; Kalan eleman sayısını DX'e al
                     XOR    SI, SI                     ; İç döngü için SI'yi sıfırla

    inner_loop_start:
                     MOV    AX, [Sorted + SI]          ; İlk elemanı al
                     MOV    BX, [Sorted + SI + 2]      ; İkinci elemanı al
                     CMP    AX, BX                     ; Karşılaştır
                     JGE    no_swap                    ; Eğer AX >= BX ise, takas yapma

    ; Takas yap
                     MOV    [Sorted + SI], BX          ; İkincisini birincinin yerine koy
                     MOV    [Sorted + SI + 2], AX      ; Birincisini ikincinin yerine koy

    no_swap:         
                     ADD    SI, 2                      ; Sonraki çifte geç
                     DEC    DX                         ; Kalan eleman sayısını azalt
                     JNZ    inner_loop_start           ; Eğer eleman kalmışsa iç döngüye dön

                     DEC    CX                         ; Dış döngü sayısını azalt
                     JNZ    outer_loop_start           ; Dış döngüye geri dön



                     RETF
BASLA ENDP
CSG ENDS
END BASLA

﻿#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>

// Function to print a matrix stored in a 1D array
void print_matrix(unsigned* matrix, unsigned rows, unsigned cols, FILE* file);
// Function to read matrix from a file
void read_matrix(const char* filename, unsigned** matrix, unsigned* rows, unsigned* cols);
// Function to read kernel from a file
void read_kernel(const char* filename, unsigned** kernel, unsigned* k);
// Function to write output matrix to a file
void write_output(const char* filename, unsigned* output, unsigned rows, unsigned cols);
// Initialize output as zeros.
void initialize_output(unsigned*, unsigned, unsigned);

int main() {

    unsigned n, m, k;  // n = rows of matrix, m = cols of matrix, k = kernel size
    // Dynamically allocate memory for matrix, kernel, and output
    unsigned* matrix = NULL;  // Input matrix
    unsigned* kernel = NULL;  // Kernel size 3x3
    unsigned* output = NULL;  // Max size of output matrix

    char matrix_filename[30];
    char kernel_filename[30];

    // Read the file names
    printf("Enter matrix filename: ");
    scanf("%s", matrix_filename);
    printf("Enter kernel filename: ");
    scanf("%s", kernel_filename);


    // Read matrix and kernel from files
    read_matrix(matrix_filename, &matrix, &n, &m);  // Read matrix from file
    read_kernel(kernel_filename, &kernel, &k);      // Read kernel from file

    // For simplicity we say: padding = 0, stride = 1
    // With this setting we can calculate the output size
    unsigned output_rows = n - k + 1;
    unsigned output_cols = m - k + 1;
    output = (unsigned*)malloc(output_rows * output_cols * sizeof(unsigned));
    initialize_output(output, output_rows, output_cols);

    // Print the input matrix and kernel
    printf("Input Matrix: ");
    print_matrix(matrix, n, m, stdout);

    printf("\nKernel: ");
    print_matrix(kernel, k, k, stdout);

    /******************* KODUN BU KISMINDAN SONRASINDA DEĞİŞİKLİK YAPABİLİRSİNİZ - ÖNCEKİ KISIMLARI DEĞİŞTİRMEYİN *******************/

    // Assembly kod bloğu içinde kullanacağınız değişkenleri burada tanımlayabilirsiniz. ---------------------->
    // Aşağıdaki değişkenleri kullanmak zorunda değilsiniz. İsterseniz değişiklik yapabilirsiniz.
    unsigned matrix_value, kernel_value;    // Konvolüsyon için gerekli 1 matrix ve 1 kernel değişkenleri saklanabilir.
    unsigned sum=0;                           // Konvolüsyon toplamını saklayabilirsiniz.
    unsigned matrix_offset = k / 2;                // Input matrisi üzerinde gezme işleminde sınırları ayarlamak için kullanılabilir.
    unsigned temp_esi, tmp_edi;
    // Assembly dilinde 2d konvolüsyon işlemini aşağıdaki blokta yazınız ----->
    __asm {


        XOR EAX, EAX ;matrix satir sayaci

        i_loop:
        CMP EAX, output_rows ;son satira geldik mi
            JGE end_loop ;son satira gelirsek donguden cik

            XOR EBX, EBX ;matrix sutun sayaci

            j_loop:
            CMP EBX, output_cols ;son sutuna geldik mi ?
                JGE sonraki_j ;son satira gelirsek donguden cik

                MOV sum, 0 ;dongu basi yeni sum hesplanacagi icin sifirla
                XOR EDX, EDX
                MOV EDX, k ; k = kernel size

                XOR ESI, ESI ;kernel satir sayaci
                MOV sum, 0
                kernel_i_loop:
                CMP ESI , EDX  ; son satira geldik mi?
                    JGE kernel_i_end_loop ;son satir ise donguden cik

                    XOR EDI, EDI ;kernel sutun sayaci

                    kernel_j_loop:
                    CMP EDI, EDX ;son sutuna geldik mi?
                        JGE kernel_j_end_loop

                        PUSH EAX
                        PUSH EDX

                        ;matrix elemanina erisim
                        ADD EAX, ESI ;(i+kenel satir)
                        MUL m ; eax = eax * m -> i * m 
                        ADD EAX, EBX ; EAX = EAX + EBX -> (i*m) + j
                        ADD EAX, EDI ;((i+ ki) * m) + j * kj
                        SHL EAX, 2   ;dort ile carp (32 lik sistem)
                        XOR ECX, ECX

                        PUSH EBX
                        MOV temp_esi, ESI

                        XOR ESI, ESI
                        MOV ESI, EAX ; memory ye erisirken EAX kullanamayiz o yuzden
                        XOR EBX, EBX
                        MOV EBX, matrix
                        MOV ECX, [EBX + ESI] ;matristeki degere erisim

                        MOV ESI, temp_esi
                        POP EBX
                        MOV matrix_value, ECX
                        

                        ;kernel elemanina erisim
                        XOR EAX, EAX
                        MOV EAX, ESI
                        MUL k ; EAX = EAX * k -> (i*k)
                        ADD EAX, EDI ; EAX = EAX + EDI -> (i*k) + j 
                        SHL EAX, 2 ; 4 ile carp (32bit)
                        XOR ECX, ECX

                        PUSH EBX
                        MOV temp_esi, ESI
                        XOR ESI, ESI
                        MOV ESI, EAX
                        XOR EBX, EBX
                        MOV EBX, kernel
                        MOV ECX ,[EBX + ESI] ; kernel degerine erisim

                        MOV ESI, temp_esi
                        POP EBX
                        MOV kernel_value, ECX

                        ;carp ve topla
                        XOR EAX,EAX 
                        MOV EAX,matrix_value
                        MUl kernel_value ; EAX = matrix_value(EAX) * kernel_value 
                        ADD sum, EAX ; sum = sum + (matrixV * kernelV)

                        POP EDX
                        POP EAX

                        INC EDI
                        JMP kernel_j_loop

                        kernel_j_end_loop:
                            INC ESI
                            JMP kernel_i_loop

                        kernel_i_end_loop:
                            ;Output matrisine sonuclari yazma
                            PUSH EAX
                            PUSH EBX

                            MUL output_cols
                            ADD EAX, EBX 
                            SHL EAX, 2
                            MOV EBX, EAX

                            MOV ECX, sum
                            ADD EBX , output
                            MOV [EBX], ECX ; output matrisine toplanan degeri yazma

                            POP EBX
                            POP EAX

                        ADD EBX, 1
                        JMP j_loop

                        sonraki_j:
                            ADD EAX, 1
                            JMP i_loop

                        end_loop:

    }

    /******************* KODUN BU KISMINDAN ÖNCESİNDE DEĞİŞİKLİK YAPABİLİRSİNİZ - SONRAKİ KISIMLARI DEĞİŞTİRMEYİN *******************/


    // Write result to output file
    write_output("./output.txt", output, output_rows, output_cols);

    // Print result
    printf("\nOutput matrix after convolution: ");
    print_matrix(output, output_rows, output_cols, stdout);

    // Free allocated memory
    free(matrix);
    free(kernel);
    free(output);

    return 0;
}

void print_matrix(unsigned* matrix, unsigned rows, unsigned cols, FILE* file) {
    if (file == stdout) {
        printf("(%ux%u)\n", rows, cols);
    }
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fprintf(file, "%u ", matrix[i * cols + j]);
        }
        fprintf(file, "\n");
    }
}

void read_matrix(const char* filename, unsigned** matrix, unsigned* rows, unsigned* cols) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Error opening file %s\n", filename);
        exit(1);
    }

    // Read dimensions
    fscanf(file, "%u %u", rows, cols);
    *matrix = (unsigned*)malloc(((*rows) * (*cols)) * sizeof(unsigned));

    // Read matrix elements
    for (int i = 0; i < (*rows); i++) {
        for (int j = 0; j < (*cols); j++) {
            fscanf(file, "%u", &(*matrix)[i * (*cols) + j]);
        }
    }

    fclose(file);
}

void read_kernel(const char* filename, unsigned** kernel, unsigned* k) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Error opening file %s\n", filename);
        exit(1);
    }

    // Read kernel size
    fscanf(file, "%u", k);
    *kernel = (unsigned*)malloc((*k) * (*k) * sizeof(unsigned));

    // Read kernel elements
    for (int i = 0; i < (*k); i++) {
        for (int j = 0; j < (*k); j++) {
            fscanf(file, "%u", &(*kernel)[i * (*k) + j]);
        }
    }

    fclose(file);
}

void write_output(const char* filename, unsigned* output, unsigned rows, unsigned cols) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        printf("Error opening file %s\n", filename);
        exit(1);
    }

    // Write dimensions of the output matrix
    fprintf(file, "%u %u\n", rows, cols);

    // Write output matrix elements
    print_matrix(output, rows, cols, file);

    fclose(file);
}

void initialize_output(unsigned* output, unsigned output_rows, unsigned output_cols) {
    int i;
    for (i = 0; i < output_cols * output_rows; i++)
        output[i] = 0;
    
}


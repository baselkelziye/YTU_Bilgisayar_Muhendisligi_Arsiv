codesg segment para 'CODE'
                        ORG    100H
                        ASSUME CS:codesg, SS:codesg, DS:codesg,ES:codesg
    BILGI:              JMP    BASLA

    N                   DW     50
    PrimeOddSum         DW     15 DUP(0)
    NonPrimeOrEvenSum   DW     15 DUP(0)
    Hipo                DW     2
    PrimeOddIndex       DW     0                                            ; Index for PrimeOddSum
    NonPrimeIndex       DW     0                                            ; Index for NonPrimeOrEvenSum

BASLA proc NEAR
             

    MainLoop:           
    ; compare if hipotenus > 50
    ;initialize hipotenus
                        MOV    AX, Hipo                                     ; en kucuk iki olabilir
                        CMP    AX , N
                        JG     _END                                         ; end loop if greater
                        
                        mov    CX, 1                                        ; i dongusunun sayaci yani i=cx
    i_loop:             

                        MOV    BX , 1                                       ;j dongusunun sayaci yani j=dx
    j_loop:             
    ;check if hipo^2 = a^ + b^
                        MOV    SI , Hipo
                        MOV    AX, Hipo
                        MUL    SI                                           ; AX = SI x AX yani hipo^2 = AX
                        MOV    SI, AX                                       ;store hipo^2 = DX

                        MOV    AX , CX
                        MUL    CX                                           ; AX = AX x CX yani CX^2 =i^2
                        MOV    DI, AX                                       ; store AX in DI

                        MOV    AX, BX
                        MUL    BX                                           ; AX =AX x BX yani DX^2 = j^2
                        ADD    DI , AX                                      ; DI = i^2 + j^2

                        CMP    SI , DI                                      ; Hipo^2 esit mi a^2 + b^2 ?
                        JNE    next_j                                       ; hipotenus degilse sonraki j ye atlasin

    ; Check if is_it_prime
                        MOV    SI,2                                         ; en kucuk iki olabilir

    PrimeCheckLoop:     
                        MOV    AX, Hipo

                        CMP    SI, AX                                       ;Check if divisor < number
                        JGE    is_prime                                     ;If no divisors found, it is prime
                        XOR    DX, DX                                       ;Clear DX

                        DIV    SI                                           ; DX:AX = AX/ SI -> bolum: AX , Kalan:DX
                        CMP    DX, 0                                        ; Check if remainder is 0
                        JE     is_not_prime                                 ; If remainder is 0, it is not prime
                        INC    SI                                           ; Increment divisor
                        JMP    PrimeCheckLoop

    is_prime:           
    ;check if A+B= odd yani (A+B)%2 != 0
                        MOV    AX, CX                                       ; i
                        ADD    AX, BX                                       ; i+j
                        AND    AX, 1                                        ; If AX (i + j) is odd, the LSB will be 1; if it’s even, the LSB will be 0.
                        JZ     skip_check                                   ;asal sayi ama a +b toplami tek degil

    ; Check for uniqueness in PrimeOddSum
                        CALL   IsUniquePrime                                ; Check uniqueness 01df
                        CMP    AX,1                                         ; 0 ise unique degil 1 ise unique
                        JNE    skip_check                                   ; unique degilse skip edelim

    ; If unique, store hypotenuse in PrimeOddSum
                        MOV    AX, Hipo
                        LEA    SI, [PrimeOddSum]                            ; SI register'ına dizinin ilk elemanının adresini yükler
                        MOV    [SI + PrimeOddIndex], AX                     ; Store hypotenuse in PrimeOddSum
                        ADD    PrimeOddIndex,2                              ; Increment index for PrimeOddSum


    skip_check:         
    next_j:             
                        INC    BX                                           ; j++x
                        CMP    BX , Hipo                                    ; j < hipo ?
                        JL     j_loop

    next_I:             
                        INC    CX                                           ; i++
                        CMP    CX , Hipo                                    ; i < hipo?
                        JL     i_loop

                        INC    Hipo
                        MOV    AX, Hipo                                     ;hipo ++

                        JMP    MainLoop

    is_not_prime:       

    ; Check for uniqueness in NonPrimeOrEvenSum
                        CALL   IsUniqueNonPrime                             ; Check uniqueness 01fe
                        CMP    AX,1                                         ; 0 ise unique degil 1 ise unique
                        JNE    skip_check                                   ; unique degilse skip edelim


    ; If unique, store hypotenuse in NonPrimeOrEvenSum
                        MOV    AX, Hipo
                        LEA    SI, [NonPrimeOrEvenSum]                      ; SI register'ına dizinin ilk elemanının adresini yükler
                        MOV    [SI + NonPrimeIndex], AX                     ; Store hypotenuse in NonPrimeOrEvenSum
                        ADD    NonPrimeIndex,2                              ; Increment index for NonPrimeOrEvenSum
                        JMP    skip_check                                   ; Skip to next hypotenuse


    ; Function to check uniqueness for PrimeOddSum
IsUniquePrime PROC
                        PUSH   CX
                        LEA    SI, [PrimeOddSum]                            ; SI register'ına dizinin ilk elemanının adresini yükler
                        MOV    AX, Hipo                                     ; Current hypotenuse to check
                        MOV    CX , 0

    CheckLoopPrime:     

                        CMP    CX,15                                        ; Compare the count with the index -hepsini kontrol ettik mi
    ; sona geldik mi? eger sona geldiysek ve donguden cikilmadiysa demek ki dizide bu hipo degeri yok
                        JAE    IsUniquePrimeEnd                             ; Exit if we checked all entries
                        MOV    DX, PrimeOddSum[SI]                          ; Load hypotenuse from array
                        CMP    AX, DX                                       ; Compare current hypotenuse with the one in the array
                        JE     NotUnique                                    ; If they match, it's not unique
                        ADD    SI,2                                         ; Next index
                        JMP    CheckLoopPrime                               ; Continue checking

    NotUnique:          
                        MOV    AX,0
                        pop    CX                                           ; Restore counter
                        RET

    IsUniquePrimeEnd:   
                        MOV    AX,1
                        pop    CX                                           ; Restore counter
                        RET
IsUniquePrime ENDP

    ; Function to check uniqueness for NonPrimeOrEvenSum
IsUniqueNonPrime PROC
                        push   CX
                        LEA    SI, [NonPrimeOrEvenSum]                      ; SI register'ına dizinin ilk elemanının adresini yükler
                        MOV    AX, Hipo                                     ; Current hypotenuse to check
                        MOV    CX,0

    CheckLoopNonPrime:  
                        CMP    CX,15                                        ; Compare with the number of entries
                        JAE    IsUniqueNonPrimeEnd                          ; Exit if we checked all entries
                        MOV    DX, NonPrimeOrEvenSum[SI]                    ; Load hypotenuse from array
                        CMP    AX, DX                                       ; Compare current hypotenuse with the one in the array
                        JE     NotUniqueNonPrime                            ; If they match, it's not unique
                        ADD    SI,2                                         ; Next index
                        JMP    CheckLoopNonPrime                            ; Continue checking

    NotUniqueNonPrime:  
                        MOV    Ax, 0                                        ; not unique
                        PUSH   CX                                           ; Restore counter
                        RET

    IsUniqueNonPrimeEnd:
                        MOV    AX, 1                                        ;unique
                        POP    CX                                           ; Restore counter
                        RET
IsUniqueNonPrime ENDP

    _END:               

                        RET
BASLA ENDP
codesg ENDS
    END BILGI
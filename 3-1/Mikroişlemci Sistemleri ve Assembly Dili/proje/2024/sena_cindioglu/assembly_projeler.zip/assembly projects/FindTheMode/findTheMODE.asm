
SSEG SEGMENT PARA STACK 'STACK'
             DW 32 DUP (?)
SSEG ENDS

DSEG SEGMENT PARA 'DATA'
        CR        EQU 13
        LF        EQU 10
        MSG1      DB  'gireceginiz dizi kac elemandan olusuyor (MAX 10 OLABILIR) ',0
        MSG2      DB  CR, LF, 'dizinin elemanlarini giriniz lutfen : ', 0
        HATA      DB  CR, LF, 'yanlis giris, sayi girmeniz gerekmektedir ', 0
        SONUC     DB  CR, LF, 'Mod degeri: ', 0
        N         DW  0
        SAYILAR   DW  10 DUP(?)

        Sayac     DW  0
        _MOD_     DW  0
        MAX_Tekar DW  0
        MAX_Sayi  DW  0
DSEG ENDS

CSEG SEGMENT PARA 'CODE'
                        ASSUME     CS:CSEG, DS:DSEG, SS:SSEG


GIRIS_DIZI MACRO N, SAYILAR
                    LOCAL      L1
                    PUSH       BP
                    PUSH       BX
                    MOV        BP, SP

                    ;burda cx teki deleman sayisini stacke akataracagiz
                    MOV        AX, OFFSET MSG2
                    CALL       PUT_STR                      ; Show MSG2
                                       
                    MOV        CX , [BP + 4]
                    ;Makrolar stack'te bir adres veya segment bilgisi saklamaz.
                    MOV        CX, N                        ; stack ten N degerini al
                    XOR        DI, DI                       ; Clear DI for index usage
                L1:             
                    CALL       GETN                         ; Read each element into AX

                    LEA        BX, SAYILAR                  ; Load address of SAYILAR array into BX
                    MOV        [BX + DI], AX                ; Store AX in SAYILAR[DI]
                    ;MOV [BP + DI + 8], AX                  ; Transfer parameter to stack
                    ADD        DI, 2                        ; Move to the next element (word size)
                    LOOP       L1                           ; Continue until CX is zero

                    ;MOV          N, CX
                    POP        BP
                    POP        BX
ENDM

ANA PROC FAR
                        PUSH       DS
                        XOR        AX,AX
                        PUSH       AX
                        MOV        AX, DSEG
                        MOV        DS, AX
                      
                        MOV        AX, OFFSET MSG1
                        CALL       PUT_STR                          ; Show MSG1
                        CALL       GETN                             ; Read N
                        MOV        N , AX
                        MOV        CX, AX
                        PUSH       CX

                        GIRIS_DIZI N,SAYILAR

                        CALL       FAR PTR _MOD
        

                        MOV        AX, OFFSET SONUC
                        CALL       PUT_STR                          ; Sonucu göster
                        POP        AX                               ; max sayi en basta oldugu icin ilk pop ile alailirz
                        MOV        AL,AH
                        MOV        AH,0
                        CALL       PUTN                             ; MOD değerini yaz



                        RETF
ANA ENDP


_MOD PROC FAR

                        PUSH       BP
                        PUSH       AX
                        PUSH       CX
                        PUSH       DX
                        PUSH       BX
                        PUSH       DI
                        PUSH       SI
                        MOV        BP , SP

                        MOV        SI, N
                        LEA        DI , SAYILAR
                        MOV        CX, 1
        i_loop:         
                        mov        dx,1
                        MOV        Sayac,0
        j_loop:         
                        MOV        BX, DX
                        MOV        AX, [DI + BX]                    ; for SAYILAR[j]
                        MOV        BX, CX
                        push       cx
                        MOV        CX , [DI + BX]                   ; For SAYILAR[i]
                        MOV        BX, CX
                        POP        CX
        ; now compare sayilar[i] =? sayilar[j]
                        CMP        AX,BX
                        JZ         SAYAC_ARTTIR


                        ADD        DX,2
                        CMP        DX, SI                           ; j, N'e ulasti mi?
                        JL         j_loop

            
                        MOV        AX, Sayac
                        MOV        BX, MAX_Tekar
                        CMP        AX , BX                          ; sayac > max_tekrar ??
                        JAE        MAX_TEKRAR_EDEN                  ; jump if above or equal

                        ADD        CX,2
                        CMP        CX, SI                           ; i , N'e ulsati mi?
                        JL         i_loop                           ; ulasmadiysa loop'a devam

        SAYAC_ARTTIR:   
                        INC        Sayac

        

        MAX_TEKRAR_EDEN:
                        MOV        AX, Sayac                        ; Store the current repetition count in AX
                        MOV        MAX_Tekar, AX                    ; Update max count
                        MOV        BX, CX                           ; Move the index of the max element into BX
                        MOV        AX, WORD PTR [DI + BX]           ; Retrieve the maximum value from SAYILAR[BX]
                        MOV        MAX_Sayi, AX                     ; Store the new max value
                        MOV        _MOD_, AX
                        
                        MOV        AX , MAX_Sayi
                        MOV        [BP + 18], AX                    ; en cok tekrar eden sayiyi stack'e atalim

                        POP        SI
                        POP        DI
                        POP        BX
                        POP        DX
                        POP        CX
                        POP        AX
                        POP        BP
                        RET

_MOD ENDP


GETC PROC NEAR
        ;------------------------------------------------------------------------
        ; Klavyeden basılan karakteri AL yazmacına alır ve ekranda gösterir.
        ; işlem sonucunda sadece AL etkilenir.
        ;------------------------------------------------------------------------
                        MOV        AH, 1h
                        INT        21H
                        RET
GETC ENDP

PUTC PROC NEAR
        ;------------------------------------------------------------------------
        ; AL yazmacındaki değeri ekranda gösterir. DL ve AH değişiyor. AX ve DX
        ; yazmaçlarının değerleri korumak için PUSH/POP yapılır.
        ;------------------------------------------------------------------------
                        PUSH       AX
                        PUSH       DX
                        MOV        DL, AL
                        MOV        AH,2
                        INT        21H
                        POP        DX
                        POP        AX
                        RET
PUTC ENDP

GETN PROC NEAR
        ;------------------------------------------------------------------------
        ; Klavyeden basılan sayiyi okur, sonucu AX yazmacı üzerinden dondurur.
        ; DX: sayının işaretli olup/olmadığını belirler. 1 (+), -1 (-) demek
        ; BL: hane bilgisini tutar
        ; CX: okunan sayının islenmesi sırasındaki ara değeri tutar.
        ; AL: klavyeden okunan karakteri tutar (ASCII)
        ; AX zaten dönüş değeri olarak değişmek durumundadır. Ancak diğer
        ; yazmaçların önceki değerleri korunmalıdır.
        ;------------------------------------------------------------------------
                        PUSH       BX
                        PUSH       CX
                        PUSH       DX
        GETN_START:     
                        MOV        DX, 1                            ; sayının şimdilik + olduğunu varsayalım
                        XOR        BX, BX                           ; okuma yapmadı Hane 0 olur.
                        XOR        CX,CX                            ; ara toplam değeri de 0’dır.
        NEW:            
                        CALL       GETC                             ; klavyeden ilk değeri AL’ye oku.
                        CMP        AL,CR
                        JE         FIN_READ                         ; Enter tuşuna basilmiş ise okuma biter
                        CMP        AL, '-'                          ; AL ,'-' mi geldi ?
                        JNE        CTRL_NUM                         ; gelen 0-9 arasında bir sayı mı?
        NEGATIVE:       
                        MOV        DX, -1                           ; - basıldı ise sayı negatif, DX=-1 olur
                        JMP        NEW                              ; yeni haneyi al
        CTRL_NUM:       
                        CMP        AL, '0'                          ; sayının 0-9 arasında olduğunu kontrol et.
                        JB         error
                        CMP        AL, '9'
                        JA         error                            ; değil ise HATA mesajı verilecek
                        SUB        AL,'0'                           ; rakam alındı, haneyi toplama dâhil et
                        MOV        BL, AL                           ; BL’ye okunan haneyi koy
                        MOV        AX, 10                           ; Haneyi eklerken *10 yapılacak
                        PUSH       DX                               ; MUL komutu DX’i bozar işaret için saklanmalı
                        MUL        CX                               ; DX:AX = AX * CX
                        POP        DX                               ; işareti geri al
                        MOV        CX, AX                           ; CX deki ara değer *10 yapıldı
                        ADD        CX, BX                           ; okunan haneyi ara değere ekle
                        JMP        NEW                              ; klavyeden yeni basılan değeri al
        ERROR:          
                        MOV        AX, OFFSET HATA
                        CALL       PUT_STR                          ; HATA mesajını göster
                        JMP        GETN_START                       ; o ana kadar okunanları unut yeniden sayı almaya başla
        FIN_READ:       
                        MOV        AX, CX                           ; sonuç AX üzerinden dönecek
                        CMP        DX, 1                            ; İşarete göre sayıyı ayarlamak lazım
                        JE         FIN_GETN
                        NEG        AX                               ; AX = -AX
        FIN_GETN:       
                        POP        DX
                        POP        CX
                        POP        DX
                        RET
GETN ENDP

PUTN PROC NEAR
        ;------------------------------------------------------------------------
        ; AX de bulunan sayiyi onluk tabanda hane hane yazdırır.
        ; CX: haneleri 10’a bölerek bulacağız, CX=10 olacak
        ; DX: 32 bölmede işleme dâhil olacak. Soncu etkilemesin diye 0 olmalı
        ;------------------------------------------------------------------------
                        PUSH       CX
                        PUSH       DX
                        XOR        DX,	DX                           ; DX 32 bit bölmede soncu etkilemesin diye 0 olmalı
                        PUSH       DX                               ; haneleri ASCII karakter olarak yığında saklayacağız.
        ; Kaç haneyi alacağımızı bilmediğimiz için yığına 0
        ; değeri koyup onu alana kadar devam edelim.
                        MOV        CX, 10                           ; CX = 10
                        CMP        AX, 0
                        JGE        CALC_DIGITS
                        NEG        AX                               ; sayı negatif ise AX pozitif yapılır.
                        PUSH       AX                               ; AX sakla
                        MOV        AL, '-'                          ; işareti ekrana yazdır.
                        CALL       PUTC
                        POP        AX                               ; AX’i geri al
        
        CALC_DIGITS:    
                        DIV        CX                               ; DX:AX = AX/CX  AX = bölüm DX = kalan
                        ADD        DX, '0'                          ; kalan değerini ASCII olarak bul
                        PUSH       DX                               ; yığına sakla
                        XOR        DX,DX                            ; DX = 0
                        CMP        AX, 0                            ; bölen 0 kaldı ise sayının işlenmesi bitti demek
                        JNE        CALC_DIGITS                      ; işlemi tekrarla
        
        DISP_LOOP:      
        ; yazılacak tüm haneler yığında. En anlamlı hane üstte
        ; en az anlamlı hane en alta ve onu altında da
        ; sona vardığımızı anlamak için konan 0 değeri var.
                        POP        AX                               ; sırayla değerleri yığından alalım
                        CMP        AX, 0                            ; AX=0 olursa sona geldik demek
                        JE         END_DISP_LOOP
                        CALL       PUTC                             ; AL deki ASCII değeri yaz
                        JMP        DISP_LOOP                        ; işleme devam
        
        END_DISP_LOOP:  
                        POP        DX
                        POP        CX
                        RET
PUTN ENDP

PUT_STR PROC NEAR
        ;------------------------------------------------------------------------
        ; AX de adresi verilen sonunda 0 olan dizgeyi karakter karakter yazdırır.
        ; BX dizgeye indis olarak kullanılır. Önceki değeri saklanmalıdır.
        ;------------------------------------------------------------------------
                        PUSH       BX
                        MOV        BX,	AX                           ; Adresi BX’e al
                        MOV        AL, BYTE PTR [BX]                ; AL’de ilk karakter var
        PUT_LOOP:       
                        CMP        AL,0
                        JE         PUT_FIN                          ; 0 geldi ise dizge sona erdi demek
                        CALL       PUTC                             ; AL’deki karakteri ekrana yazar
                        INC        BX                               ; bir sonraki karaktere geç
                        MOV        AL, BYTE PTR [BX]
                        JMP        PUT_LOOP                         ; yazdırmaya devam
        PUT_FIN:        
                        POP        BX
                        RET
PUT_STR ENDP

CSEG ENDS
	END ANA

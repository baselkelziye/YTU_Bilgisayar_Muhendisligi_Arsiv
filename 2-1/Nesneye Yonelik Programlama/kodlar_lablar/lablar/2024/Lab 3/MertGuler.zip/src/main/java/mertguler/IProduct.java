package mertguler;

public interface IProduct {
    String getName();
    double getPrice();
}

package mertguler;

public class ProductShippingError extends RuntimeException {
    public ProductShippingError(String message) {
        super(message);
    }
}

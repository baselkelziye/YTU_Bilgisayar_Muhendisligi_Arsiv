package mertguler;

public interface IShipping {
    boolean shipProduct(String productName, String customerName);
}

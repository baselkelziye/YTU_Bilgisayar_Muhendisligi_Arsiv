package reservationandticketing;

import flightmanagement.Flight;
import flightmanagement.Seat;

import java.util.UUID;

public class Reservation {
    private String reservationPNR;
    private Flight flight;
    private Passenger passenger;
    private Seat seat;
    private String dateOfReservation;
    private Baggage baggage;

    public Reservation(Flight flight, Passenger passenger, Seat seat, String dateOfReservation, double baggageWeight) {
        this.reservationPNR = generatePNR();
        this.flight = flight;
        this.passenger = passenger;
        this.seat = seat;
        this.dateOfReservation = dateOfReservation;
        this.baggage = new Baggage(baggageWeight);
    }

    public String getReservationPNR() {
        return reservationPNR;
    }

    public void setReservationPNR(String reservationPNR) {
        this.reservationPNR = reservationPNR;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public Seat getSeat() {
        return seat;
    }

    public void setSeat(Seat seat) {
        this.seat = seat;
    }

    public String getDateOfReservation() {
        return dateOfReservation;
    }

    public void setDateOfReservation(String dateOfReservation) {
        this.dateOfReservation = dateOfReservation;
    }

    public Baggage getBaggage() {
        return baggage;
    }

    public static String generatePNR() {
        return UUID.randomUUID().toString().substring(0, 6).toUpperCase();
    }
}

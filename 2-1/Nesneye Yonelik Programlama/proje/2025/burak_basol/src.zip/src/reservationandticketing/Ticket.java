package reservationandticketing;

public class Ticket {
    private String ticketID;
    private double price;
    private Reservation reservation;
    private double baggageAllowance;

    public Ticket(String ticketID, double price, Reservation reservation, double baggageAllowance) {
        this.ticketID = ticketID;
        this.price = price;
        this.reservation = reservation;
        this.baggageAllowance = baggageAllowance;
    }

    public String getTicketID() {
        return ticketID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Reservation getReservation() {
        return reservation;
    }

    public void setReservation(Reservation reservation) {
        this.reservation = reservation;
    }

    public double getBaggageAllowance() {
        return baggageAllowance;
    }

}

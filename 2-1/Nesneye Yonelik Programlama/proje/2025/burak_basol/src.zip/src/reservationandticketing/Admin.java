package reservationandticketing;

public class Admin extends User {

    public Admin(String username, String password) {
        super(username, password, "Admin");
    }

    @Override
    public void displayUserInfo() {
        System.out.println("=== Admin Information ===");
        System.out.println("Username: " + username);
        System.out.println("User Type: " + userType);
        System.out.println("Access Level: Administrator");
        System.out.println("Permissions: Full system access, manage users, manage staff, system configuration");
    }

}

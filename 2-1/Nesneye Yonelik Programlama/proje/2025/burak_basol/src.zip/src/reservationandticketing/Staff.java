package reservationandticketing;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Staff extends User {
    private double salary;

    public Staff(String username, String password, double salary) {
        super(username, password, "Staff");
        this.salary = salary;
    }

    @Override
    public void displayUserInfo() {
        System.out.println("=== Staff Information ===");
        System.out.println("Username: " + username);
        System.out.println("User Type: " + userType);
        System.out.println("Salary: $" + String.format("%.2f", salary));
        System.out.println("Access Level: Staff Member");
        System.out.println("Permissions: Manage flights, view all reservations, assist passengers");
    }

    public double getSalary() {
        return salary;
    }

    public static void showAllStaff(Component parent, Map<String, User> users) {
        List<Staff> staffList = new ArrayList<>();
        for (User user : users.values()) {
            if (user instanceof Staff) {
                staffList.add((Staff) user);
            }
        }

        if (staffList.isEmpty()) {
            JOptionPane.showMessageDialog(parent,
                    "No staff members found in the system.",
                    "No Staff Found",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String[] columnNames = { "Username", "Salary" };
        Object[][] data = new Object[staffList.size()][2];

        for (int i = 0; i < staffList.size(); i++) {
            Staff s = staffList.get(i);
            data[i][0] = s.getUsername();
            data[i][1] = String.format("$%.2f", s.getSalary());
        }

        JTable table = new JTable(data, columnNames);
        table.setFillsViewportHeight(true);
        table.setDefaultEditor(Object.class, null);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(500, 300));

        JOptionPane.showMessageDialog(parent,
                scrollPane,
                "All Staff Members (" + staffList.size() + " total)",
                JOptionPane.INFORMATION_MESSAGE);
    }

}

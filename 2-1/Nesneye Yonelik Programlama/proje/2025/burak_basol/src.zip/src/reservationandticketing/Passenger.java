package reservationandticketing;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Passenger extends User {
    private String passengerID;
    private String name;
    private String surname;
    private String contactInfo;

    public Passenger(String username, String password, String passengerID, String name, String surname,
            String contactInfo) {
        super(username, password, "Passenger");
        this.passengerID = passengerID;
        this.name = name;
        this.surname = surname;
        this.contactInfo = contactInfo;
    }

    public Passenger(String passengerID, String name, String surname, String contactInfo) {
        super("", "", "Passenger");
        this.passengerID = passengerID;
        this.name = name;
        this.surname = surname;
        this.contactInfo = contactInfo;
    }

    @Override
    public void displayUserInfo() {
        System.out.println("=== Passenger Information ===");
        System.out.println("Username: " + username);
        System.out.println("User Type: " + userType);
        System.out.println("Passenger ID: " + passengerID);
        System.out.println("Name: " + name + " " + surname);
        System.out.println("Contact Info: " + contactInfo);
        System.out.println("Access Level: Standard User");
        System.out.println("Permissions: Book flights, view reservations, select seats");
    }

    public String getPassengerID() {
        return passengerID;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public String getPassportNumber() {
        return passengerID;
    }

    public static void showAllPassengers(Container parent, Map<String, User> users) {
        List<Passenger> passengerList = new ArrayList<>();
        for (User user : users.values()) {
            if (user instanceof Passenger) {
                passengerList.add((Passenger) user);
            }
        }

        if (passengerList.isEmpty()) {
            JOptionPane.showMessageDialog(parent,
                    "No passengers found in the system.",
                    "No Passengers Found",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String[] columnNames = { "Passenger ID", "Name", "Contact Info" };
        Object[][] data = new Object[passengerList.size()][3];

        for (int i = 0; i < passengerList.size(); i++) {
            Passenger p = passengerList.get(i);
            data[i][0] = p.getPassengerID();
            data[i][1] = p.getName() + " " + p.getSurname();
            data[i][2] = p.getContactInfo();
        }

        JTable table = new JTable(data, columnNames);
        table.setFillsViewportHeight(true);
        table.setDefaultEditor(Object.class, null);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(600, 400));

        JOptionPane.showMessageDialog(parent,
                scrollPane,
                "All Passengers (" + passengerList.size() + " total)",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public void editPassenger(String password, String passengerID, String name, String surname, String contactInfo) {
        if (password != null && !password.isEmpty()) {
            this.password = password;
        }
        if (passengerID != null && !passengerID.isEmpty()) {
            this.passengerID = passengerID;
        }
        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
        if (surname != null && !surname.isEmpty()) {
            this.surname = surname;
        }
        if (contactInfo != null && !contactInfo.isEmpty()) {
            this.contactInfo = contactInfo;
        }
    }
}

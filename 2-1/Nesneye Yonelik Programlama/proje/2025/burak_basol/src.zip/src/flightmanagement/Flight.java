package flightmanagement;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

public class Flight extends Route {
    private String flightNum;
    private Plane plane;
    private LocalDate date;
    private LocalTime hour;
    private Duration duration;

    public Flight(String flightNum, Plane plane, String departurePlace, String arrivalPlace, LocalDate date,
            LocalTime hour, Duration duration) {
        super(departurePlace, arrivalPlace);
        this.flightNum = flightNum;
        this.plane = plane;
        this.date = date;
        this.hour = hour;
        this.duration = duration;
    }

    public String getFlightNum() {
        return flightNum;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getHour() {
        return hour;
    }

    public void setHour(LocalTime hour) {
        this.hour = hour;
    }

    public Duration getDuration() {
        return duration;
    }

    public void setDuration(Duration duration) {
        this.duration = duration;
    }

    public Plane getPlane() {
        return plane;
    }

    public void setPlane(Plane plane) {
        this.plane = plane;
    }

}

package flightmanagement;

public enum SeatEnum {
    ECONOMY,
    BUSINESS,
}

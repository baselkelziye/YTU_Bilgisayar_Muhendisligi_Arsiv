package flightmanagement;

import java.util.ArrayList;

public class Plane {
    private String planeID;
    private String planeModel;
    private int capacity;
    private ArrayList<ArrayList<Seat>> seatMatrix;

    public Plane(String planeID, String planeModel, int capacity) {
        this.planeID = planeID;
        this.planeModel = planeModel;
        this.capacity = capacity;
        this.seatMatrix = new ArrayList<>();

        int numRows = this.capacity / 6;
        for (int i = 0; i < numRows; i++) {
            this.seatMatrix.add(new ArrayList<>());
        }
    }

    public String getPlaneID() {
        return planeID;
    }

    public String getPlaneModel() {
        return planeModel;
    }

    public int getCapacity() {
        return capacity;
    }

    public ArrayList<ArrayList<Seat>> getSeatMatrix() {
        return seatMatrix;
    }

    public void setSeatMatrix(ArrayList<ArrayList<Seat>> seatMatrix) {
        this.seatMatrix = seatMatrix;
    }

}

package flightmanagement;

public class Seat {
    private String seatNum; 
    public SeatEnum seatClass;
    private double price;
    private boolean reserveStatus;

    public Seat(String seatNum, SeatEnum seatClass) {
        this.seatNum = seatNum;
        this.seatClass = seatClass;
        this.reserveStatus = false;
        if (seatClass == SeatEnum.ECONOMY) {
            this.price = 100;
        } else if (seatClass == SeatEnum.BUSINESS) {
            this.price = 200;
        }
    }

    public String getSeatNum() {
        return seatNum;
    }

    public SeatEnum getSeatClass() {
        return seatClass;
    }

    public double getPrice() {
        return price;
    }

    public boolean getReserveStatus() {
        return reserveStatus;
    }

    public void setReserveStatus(boolean reserveStatus) {
        this.reserveStatus = reserveStatus;
    }
}

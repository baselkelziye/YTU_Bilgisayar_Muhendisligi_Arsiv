package ui.gui;

import flightmanagement.Flight;
import flightmanagement.Plane;
import flightmanagement.Seat;
import servicesandmanagers.CalculatePrice;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;

public class SeatSelectionDialog extends JDialog {

    private final Flight flight;
    private final Seat currentSeat;
    private Seat selectedSeat;
    private JPanel seatGridPanel;
    private JButton confirmButton;
    private JLabel infoLabel;

    
    private static final Color AVAILABLE_COLOR = Color.WHITE;
    private static final Color BUSINESS_CLASS_COLOR = new Color(216, 191, 216); 
    private static final Color SELECTED_COLOR = new Color(152, 251, 152); 
    private static final Color RESERVED_COLOR = Color.LIGHT_GRAY;
    private static final Color CURRENT_SEAT_COLOR = new Color(100, 149, 237); 

    private final ArrayList<JButton> seatButtons = new ArrayList<>();

    public SeatSelectionDialog(Frame owner, Flight flight, Seat currentSeat) {
        super(owner, "Select New Seat", true);
        this.flight = flight;
        this.currentSeat = currentSeat;

        setSize(800, 600);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        
        getContentPane().setBackground(new Color(32, 33, 36));

        initComponents();
        buildSeatGrid();
    }

    private void initComponents() {
        
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        headerPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("Select a New Seat for Flight " + flight.getFlightNum());
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        headerPanel.add(titleLabel, BorderLayout.NORTH);

        infoLabel = new JLabel("Current Seat: " + currentSeat.getSeatNum() + " (" + currentSeat.getSeatClass() + ")");
        infoLabel.setForeground(Color.LIGHT_GRAY);
        infoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        headerPanel.add(infoLabel, BorderLayout.SOUTH);

        add(headerPanel, BorderLayout.NORTH);

        
        seatGridPanel = new JPanel();
        seatGridPanel.setBackground(new Color(48, 50, 56)); 
        JScrollPane scrollPane = new JScrollPane(seatGridPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);

        
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footerPanel.setOpaque(false);
        footerPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JButton cancelButton = new JButton("Cancel");
        styleButton(cancelButton, new Color(244, 67, 54)); 
        cancelButton.addActionListener(e -> dispose());

        confirmButton = new JButton("Confirm Change");
        styleButton(confirmButton, new Color(76, 175, 80)); 
        confirmButton.setEnabled(false);
        confirmButton.addActionListener(e -> {
            if (selectedSeat != null) {
                setVisible(false);
            }
        });

        footerPanel.add(cancelButton);
        footerPanel.add(confirmButton);
        add(footerPanel, BorderLayout.SOUTH);
    }

    private void styleButton(JButton btn, Color bg) {
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void buildSeatGrid() {
        seatGridPanel.removeAll();
        seatButtons.clear();

        Plane plane = flight.getPlane();
        if (plane == null || plane.getSeatMatrix() == null)
            return;

        ArrayList<ArrayList<Seat>> matrix = plane.getSeatMatrix();
        int rows = matrix.size();
        int cols = matrix.get(0).size();

        seatGridPanel.setLayout(new GridLayout(rows, cols, 5, 5));
        seatGridPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        CalculatePrice pricer = new CalculatePrice();

        for (ArrayList<Seat> row : matrix) {
            for (Seat seat : row) {
                JButton btn = new JButton(seat.getSeatNum());
                btn.setFont(new Font("Segoe UI", Font.BOLD, 10));
                btn.setPreferredSize(new Dimension(50, 40));

                
                if (seat.getSeatNum().equals(currentSeat.getSeatNum())) {
                    
                    btn.setBackground(CURRENT_SEAT_COLOR);
                    btn.setForeground(Color.WHITE);
                    btn.setText(seat.getSeatNum() + " (Yours)");
                    btn.setEnabled(false);
                } else if (seat.getReserveStatus()) {
                    
                    btn.setBackground(RESERVED_COLOR);
                    btn.setEnabled(false);
                } else {
                    
                    if (seat.getSeatClass().toString().equals("BUSINESS")) {
                        btn.setBackground(BUSINESS_CLASS_COLOR);
                    } else {
                        btn.setBackground(AVAILABLE_COLOR);
                    }
                    btn.setForeground(Color.BLACK);

                    
                    btn.addActionListener(e -> selectSeat(seat, btn));
                }

                
                double price = pricer.calculatePrice(seat);
                btn.setToolTipText(String.format("Seat: %s | Class: %s | Price: $%.2f",
                        seat.getSeatNum(), seat.getSeatClass(), price));

                seatButtons.add(btn);
                seatGridPanel.add(btn);
            }
        }
    }

    private void selectSeat(Seat seat, JButton clickedBtn) {
        
        if (selectedSeat != null) {
            
            for (JButton btn : seatButtons) {
                if (btn.getText().equals(selectedSeat.getSeatNum())) {
                    
                    if (selectedSeat.getSeatClass().toString().equals("BUSINESS")) {
                        btn.setBackground(BUSINESS_CLASS_COLOR);
                    } else {
                        btn.setBackground(AVAILABLE_COLOR);
                    }
                    break;
                }
            }
        }

        selectedSeat = seat;
        clickedBtn.setBackground(SELECTED_COLOR);
        confirmButton.setEnabled(true);
        infoLabel.setText("Selected New Seat: " + seat.getSeatNum() + " (" + seat.getSeatClass() + ")");
    }

    public Seat getSelectedSeat() {
        return selectedSeat;
    }
}

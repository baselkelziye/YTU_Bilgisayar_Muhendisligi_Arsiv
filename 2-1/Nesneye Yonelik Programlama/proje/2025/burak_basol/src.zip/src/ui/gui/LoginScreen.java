package ui.gui;

import reservationandticketing.User;
import servicesandmanagers.UserManager;
import ui.gui.components.ModernButton;
import ui.gui.components.ModernPanel;
import ui.gui.components.ModernTextField;
import ui.theme.StyleConstants;
import ui.theme.ThemeManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginScreen extends JFrame implements ThemeManager.ThemeListener {

    private final UserManager userManager;
    private User authenticatedUser;

    private JPanel mainContainer;
    private ModernPanel contentPanel;
    private JLabel titleLabel;
    private JTabbedPane tabbedPane;

    public LoginScreen() {
        setTitle("Airline System - Login");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        userManager = new UserManager();

        ThemeManager.getInstance().addListener(this);

        initComponents();
        updateTheme();
    }

    private void initComponents() {
        mainContainer = new JPanel(new GridBagLayout());

        contentPanel = new ModernPanel(true);
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(30, 40, 30, 40));
        contentPanel.setPreferredSize(new Dimension(550, 550));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        headerPanel.setBorder(new EmptyBorder(0, 0, 20, 0));

        titleLabel = new JLabel("Welcome Aboard", SwingConstants.CENTER);
        titleLabel.setFont(StyleConstants.HEADER_FONT);
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        JButton themeToggleButton = new JButton("●");
        themeToggleButton.setPreferredSize(new Dimension(45, 45));
        themeToggleButton.setFont(new Font("Arial", Font.BOLD, 20));
        themeToggleButton.setFocusPainted(false);
        themeToggleButton.setBorderPainted(false);
        themeToggleButton.setContentAreaFilled(true);
        themeToggleButton.setOpaque(true);
        themeToggleButton.setToolTipText("Toggle Theme");
        themeToggleButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        themeToggleButton.addActionListener(e -> {
            ThemeManager.getInstance().toggleTheme();
            updateThemeToggleIcon(themeToggleButton);
        });
        updateThemeToggleIcon(themeToggleButton);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);
        buttonPanel.add(themeToggleButton);
        headerPanel.add(buttonPanel, BorderLayout.EAST);

        contentPanel.add(headerPanel, BorderLayout.NORTH);

        tabbedPane = new JTabbedPane();
        tabbedPane.setOpaque(false);
        tabbedPane.setFont(StyleConstants.BOLD_FONT);

        tabbedPane.addTab("Passenger", createPassengerPanel());
        tabbedPane.addTab("Staff", createStaffPanel());
        tabbedPane.addTab("Admin", createAdminPanel());

        contentPanel.add(tabbedPane, BorderLayout.CENTER);

        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footerPanel.setOpaque(false);
        footerPanel.setBorder(new EmptyBorder(20, 0, 0, 0));

        JButton exitButton = new ModernButton("Exit System", Color.RED);
        exitButton.addActionListener(e -> System.exit(0));

        footerPanel.add(exitButton);
        contentPanel.add(footerPanel, BorderLayout.SOUTH);

        mainContainer.add(contentPanel);
        add(mainContainer);
    }

    private JPanel createPassengerPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(true);
        panel.setBackground(ThemeManager.getInstance().getContentAreaColor());
        panel.setBorder(new EmptyBorder(20, 10, 10, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel userLabel = new JLabel("Username:");
        styleLabel(userLabel);
        panel.add(userLabel, gbc);

        gbc.gridx = 1;
        ModernTextField usernameField = new ModernTextField(15);
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passLabel = new JLabel("Password:");
        styleLabel(passLabel);
        panel.add(passLabel, gbc);

        gbc.gridx = 1;
        JPasswordField passwordField = new JPasswordField(15);
        stylePasswordField(passwordField);
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JButton loginButton = new ModernButton("Login as Passenger");
        loginButton.setBackground(new Color(46, 139, 87));
        panel.add(loginButton, gbc);

        loginButton.addActionListener(e -> handleLogin("PASSENGER", usernameField.getText(),
                new String(passwordField.getPassword())));

        gbc.gridy = 3;
        JButton registerButton = new ModernButton("Register New Passenger Account");
        panel.add(registerButton, gbc);
        registerButton.addActionListener(e -> handlePassengerRegister());

        return panel;
    }

    private JPanel createStaffPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(true);
        panel.setBackground(ThemeManager.getInstance().getContentAreaColor());
        panel.setBorder(new EmptyBorder(20, 10, 10, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel userLabel = new JLabel("Username:");
        styleLabel(userLabel);
        panel.add(userLabel, gbc);

        gbc.gridx = 1;
        ModernTextField usernameField = new ModernTextField(15);
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passLabel = new JLabel("Password:");
        styleLabel(passLabel);
        panel.add(passLabel, gbc);

        gbc.gridx = 1;
        JPasswordField passwordField = new JPasswordField(15);
        stylePasswordField(passwordField);
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JButton loginButton = new ModernButton("Login as Staff");
        loginButton.setBackground(new Color(46, 139, 87)); 
        panel.add(loginButton, gbc);

        loginButton.addActionListener(e -> handleLogin("STAFF", usernameField.getText(),
                new String(passwordField.getPassword())));

        gbc.gridy = 3;
        JButton registerButton = new ModernButton("Register New Staff Account");
        panel.add(registerButton, gbc);
        registerButton.addActionListener(e -> handleStaffRegister());

        return panel;
    }

    private JPanel createAdminPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(true);
        panel.setBackground(ThemeManager.getInstance().getContentAreaColor());
        panel.setBorder(new EmptyBorder(20, 10, 10, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel userLabel = new JLabel("Username:");
        styleLabel(userLabel);
        panel.add(userLabel, gbc);

        gbc.gridx = 1;
        ModernTextField usernameField = new ModernTextField(15);
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passLabel = new JLabel("Password:");
        styleLabel(passLabel);
        panel.add(passLabel, gbc);

        gbc.gridx = 1;
        JPasswordField passwordField = new JPasswordField(15);
        stylePasswordField(passwordField);
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JButton loginButton = new ModernButton("Login as Admin");
        loginButton.setBackground(new Color(46, 139, 87)); 
        panel.add(loginButton, gbc);

        loginButton.addActionListener(e -> handleLogin("ADMIN", usernameField.getText(),
                new String(passwordField.getPassword())));

        gbc.gridy = 3;
        JButton registerButton = new ModernButton("Register New Admin Account");
        panel.add(registerButton, gbc);
        registerButton.addActionListener(e -> handleAdminRegister());

        return panel;
    }

    private void handleLogin(String userType, String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = userManager.authenticate(username, password, userType);

        if (user != null) {
            authenticatedUser = user;
            JOptionPane.showMessageDialog(this, "Login Successful as " + userType + "!");
            this.dispose();

            ThemeManager.getInstance().removeListener(this);
            openDashboard(userType);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials for " + userType, "Login Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handlePassengerRegister() {
        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JPasswordField confirmField = new JPasswordField(15);
        JTextField passengerIdField = new JTextField(15);
        JTextField nameField = new JTextField(15);
        JTextField surnameField = new JTextField(15);
        JTextField contactField = new JTextField(15);

        Object[] message = {
                "Username:", usernameField,
                "Password:", passwordField,
                "Confirm Password:", confirmField,
                "Passenger ID:", passengerIdField,
                "First Name:", nameField,
                "Last Name:", surnameField,
                "Contact Info:", contactField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Register Passenger Account",
                JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirm = new String(confirmField.getPassword());
            String passengerId = passengerIdField.getText().trim();
            String name = nameField.getText().trim();
            String surname = surnameField.getText().trim();
            String contact = contactField.getText().trim();

            if (username.isEmpty() || password.isEmpty() || passengerId.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username, password, passenger ID, and name are required.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!password.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match.", "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (userManager.userExists(username, "PASSENGER")) {
                JOptionPane.showMessageDialog(this, "Username already exists. Please choose another.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = userManager.registerPassenger(username, password, passengerId, name, surname, contact);

            if (success) {
                JOptionPane.showMessageDialog(this, "Passenger account created successfully! You can now log in.",
                        "Registration Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create account. Please try again.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleStaffRegister() {
        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JPasswordField confirmField = new JPasswordField(15);
        JTextField salaryField = new JTextField(15);

        Object[] message = {
                "Username:", usernameField,
                "Password:", passwordField,
                "Confirm Password:", confirmField,
                "Salary:", salaryField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Register Staff Account",
                JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirm = new String(confirmField.getPassword());
            String salaryStr = salaryField.getText().trim();

            if (username.isEmpty() || password.isEmpty() || salaryStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username, password, and salary cannot be empty.",
                        "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!password.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match.", "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            double salary;
            try {
                salary = Double.parseDouble(salaryStr);
                if (salary < 0) {
                    JOptionPane.showMessageDialog(this, "Salary cannot be negative.", "Registration Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid salary format. Please enter a valid number.",
                        "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (userManager.userExists(username, "STAFF")) {
                JOptionPane.showMessageDialog(this, "Username already exists. Please choose another.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = userManager.registerStaff(username, password, salary);

            if (success) {
                JOptionPane.showMessageDialog(this, "Staff account created successfully! You can now log in.",
                        "Registration Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create account. Please try again.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleAdminRegister() {
        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JPasswordField confirmField = new JPasswordField(15);

        Object[] message = {
                "Username:", usernameField,
                "Password:", passwordField,
                "Confirm Password:", confirmField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Register Admin Account",
                JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirm = new String(confirmField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username and password cannot be empty.", "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!password.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match.", "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (userManager.userExists(username, "ADMIN")) {
                JOptionPane.showMessageDialog(this, "Username already exists. Please choose another.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = userManager.registerAdmin(username, password);

            if (success) {
                JOptionPane.showMessageDialog(this, "Admin account created successfully! You can now log in.",
                        "Registration Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create account. Please try again.",
                        "Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void styleLabel(JLabel label) {
        label.setFont(StyleConstants.NORMAL_FONT);
    }

    private void stylePasswordField(JPasswordField field) {
        field.setFont(StyleConstants.NORMAL_FONT);
    }

    private void openDashboard(String role) {
        System.out.println("Opening Dashboard for: " + role);
        this.dispose();

        new MainDashboard(role, authenticatedUser, () -> {
            SwingUtilities.invokeLater(() -> new LoginScreen().setVisible(true));
        }).setVisible(true);
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme newTheme) {
        updateTheme();
    }

    private void updateTheme() {
        ThemeManager tm = ThemeManager.getInstance();
        Color textColor = tm.getTextColor();
        Color bgColor = tm.getBackgroundColor();
        Color inputBg = tm.getInputBackgroundColor();

        mainContainer.setBackground(bgColor);
        contentPanel.setBackground(tm.getPanelColor());
        titleLabel.setForeground(textColor);

        tabbedPane.setForeground(textColor);
        tabbedPane.setBackground(tm.getPanelColor());

        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            Component comp = tabbedPane.getComponentAt(i);
            if (comp instanceof JPanel) {
                comp.setBackground(tm.getPanelColor());
            }
        }

        processContainerLabels(tabbedPane);

        try {
            UIManager.put("OptionPane.background", tm.getPanelColor());
            UIManager.put("Panel.background", tm.getPanelColor());
            UIManager.put("OptionPane.messageForeground", tm.getTextColor());
            UIManager.put("TabbedPane.contentAreaColor", tm.getPanelColor());
            UIManager.put("TabbedPane.selected", tm.getPanelColor());
            UIManager.put("TabbedPane.background", tm.getPanelColor());
            UIManager.put("TabbedPane.shadow", tm.getPanelColor());
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            Component comp = tabbedPane.getComponentAt(i);
            if (comp instanceof JPanel) {
                comp.setBackground(tm.getContentAreaColor());
            }
        }

        SwingUtilities.updateComponentTreeUI(this);
    }

    private void processContainerLabels(Container container) {
        ThemeManager tm = ThemeManager.getInstance();
        for (Component c : container.getComponents()) {
            if (c instanceof JLabel) {
                c.setForeground(tm.getTextColor());
            } else if (c instanceof JPasswordField) {
                c.setBackground(tm.getInputBackgroundColor());
                c.setForeground(tm.getInputTextColor());
            } else if (c instanceof JTextField && !(c instanceof ModernTextField)) {
                c.setBackground(tm.getInputBackgroundColor());
                c.setForeground(tm.getInputTextColor());
            } else if (c instanceof JPanel) {
                if (c.isOpaque()) {
                    c.setBackground(tm.getPanelColor());
                }
                processContainerLabels((Container) c);
            } else if (c instanceof Container) {
                processContainerLabels((Container) c);
            }
        }
    }

    private void updateThemeToggleIcon(JButton button) {
        boolean isDark = ThemeManager.getInstance().isDark();
        if (isDark) {
            button.setText("●");
            button.setBackground(new Color(255, 255, 255)); 
            button.setForeground(new Color(20, 20, 20));
            button.setToolTipText("Switch to Light Theme");
        } else {
            button.setText("●");
            button.setBackground(new Color(30, 30, 30)); 
            button.setForeground(new Color(255, 255, 255));
            button.setToolTipText("Switch to Dark Theme");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginScreen().setVisible(true);
        });
    }
}
package ui.cli;

import flightmanagement.Flight;
import reservationandticketing.Passenger;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.SeatManager;
import servicesandmanagers.TicketManager;

import java.util.ArrayList;
import java.util.Scanner;

public class FlightSearchFrame {

    private final FlightManager flightManager;
    private final SeatManager seatManager;
    private final ReservationManager reservationManager;
    private final TicketManager ticketManager;
    private final Passenger loggedInUser;

    public FlightSearchFrame(final FlightManager flightManager, final ReservationManager reservationManager,
                             final TicketManager ticketManager, final Passenger loggedInUser) {
        this.flightManager = flightManager;
        this.reservationManager = reservationManager;
        this.ticketManager = ticketManager;
        this.loggedInUser = loggedInUser;
        seatManager = new SeatManager();
    }

    public void start(final Scanner scanner) {
        boolean searching = true;
        while (searching) {
            System.out.println("\n--- Search Flights ---");
            System.out.println("1. Search by Departure City");
            System.out.println("2. Show All Flights");
            System.out.println("3. Back to Menu");
            System.out.print("Select: ");

            final String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    System.out.print("Enter Departure City: ");
                    final String city = scanner.nextLine().trim();
                    this.showFlights(city, scanner);
                    break;
                case "2":
                    this.showFlights("", scanner);
                    break;
                case "3":
                    searching = false;
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private void showFlights(final String filter, final Scanner scanner) {
        final ArrayList<Flight> flights = this.flightManager.getFlights();
        final ArrayList<Flight> matches = new ArrayList<>();

        if (filter.isEmpty()) {
            matches.addAll(flights);
        } else {
            for (final Flight f : flights) {
                if (f.getDeparturePlace().equalsIgnoreCase(filter)) {
                    matches.add(f);
                }
            }
        }

        if (matches.isEmpty()) {
            System.out.println("No flights found.");
            return;
        }

        System.out.printf("%-10s %-15s %-15s %-12s %-8s %-15s %-10s%n",
                "Flight No", "From", "To", "Date", "Time", "Duration", "Seats");
        
        for (final Flight f : matches) {
            final int available = this.seatManager.getAvailableSeats(f);
            final long hours = f.getDuration().toHours();
            final long mins = f.getDuration().toMinutes() % 60;
            System.out.printf("%-10s %-15s %-15s %-12s %-8s %-15s %-10s%n",
                    f.getFlightNum(), f.getDeparturePlace(), f.getArrivalPlace(),
                    f.getDate(), f.getHour(), hours + "h " + mins + "m", available);
        }

        System.out.print("\nOptions: [v] View Seats, [Enter] Back: ");
        final String opt = scanner.nextLine().trim();
        if ("v".equalsIgnoreCase(opt)) {
            System.out.print("Enter Flight Number: ");
            final String fNum = scanner.nextLine().trim();
            Flight selected = null;
            for (final Flight f : matches) {
                if (f.getFlightNum().equalsIgnoreCase(fNum)) {
                    selected = f;
                    break;
                }
            }
            if (null != selected) {
                new SeatDisplayFrame(selected, this.seatManager, reservationManager, ticketManager, loggedInUser).start(scanner);
                System.out.println("Press Enter to continue...");
                scanner.nextLine();
            } else {
                System.out.println("Flight not found in results.");
            }
        }
    }
}

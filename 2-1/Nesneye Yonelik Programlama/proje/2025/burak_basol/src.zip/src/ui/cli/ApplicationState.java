package ui.cli;

import flightmanagement.Plane;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.TicketManager;

import java.util.ArrayList;

public class ApplicationState {
    private static ApplicationState instance;
    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final TicketManager ticketManager;
    private final ArrayList<Plane> availablePlanes;
    private boolean initialized;

    private ApplicationState() {
        flightManager = new FlightManager();
        reservationManager = new ReservationManager();
        ticketManager = new TicketManager(this.reservationManager);
        availablePlanes = new ArrayList<>();
    }

    public static synchronized ApplicationState getInstance() {
        if (null == instance) {
            ApplicationState.instance = new ApplicationState();
        }
        return ApplicationState.instance;
    }

    public void initialize() {
        if (!this.initialized) {
            this.availablePlanes.add(new Plane("A321", "Airbus", 150));
            this.availablePlanes.add(new Plane("B737", "Boeing", 150));

            System.out.println("Loading flights from file...");
            this.flightManager.loadFlightsFromFile(this.availablePlanes);

            System.out.println("Loading reservations from file...");
            this.reservationManager.loadReservationsFromFile(this.flightManager);

            System.out.println("Loading tickets from file...");
            this.ticketManager.loadTicketsFromFile();

            this.initialized = true;
            System.out.println("Application state initialized successfully.");
        }
    }

    public FlightManager getFlightManager() {
        return this.flightManager;
    }

    public ReservationManager getReservationManager() {
        return this.reservationManager;
    }

    public TicketManager getTicketManager() {
        return this.ticketManager;
    }

    public ArrayList<Plane> getAvailablePlanes() {
        return this.availablePlanes;
    }
}

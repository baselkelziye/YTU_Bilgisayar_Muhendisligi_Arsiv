package ui.gui.components;

import ui.theme.StyleConstants;
import ui.theme.ThemeManager;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class ModernTextField extends JTextField implements ThemeManager.ThemeListener {

    public ModernTextField(int columns) {
        super(columns);
        setFont(StyleConstants.NORMAL_FONT);
        ThemeManager.getInstance().addListener(this);
        updateTheme();
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme newTheme) {
        updateTheme();
    }

    private void updateTheme() {
        setBackground(ThemeManager.getInstance().getInputBackgroundColor());
        setForeground(ThemeManager.getInstance().getInputTextColor());
        setCaretColor(ThemeManager.getInstance().getInputTextColor());

        Border line = new LineBorder(ThemeManager.getInstance().getBorderColor(), 1);
        Border empty = new EmptyBorder(5, 5, 5, 5);
        setBorder(new CompoundBorder(line, empty));
    }
}

package ui.cli;

import flightmanagement.Plane;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;

import java.util.List;

public class ReportGenerator {

    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final List<Plane> availablePlanes;

    public ReportGenerator(final FlightManager flightManager, final ReservationManager reservationManager, final List<Plane> availablePlanes) {
        this.flightManager = flightManager;
        this.reservationManager = reservationManager;
        this.availablePlanes = availablePlanes;
    }

    public void generate() {
        System.out.println("Preparing report...");

        final int totalFlights = this.flightManager.getFlights().size();
        final int totalReservations = this.reservationManager.getAllReservations().size();
        final double occupancy = 0 < totalFlights ? (totalReservations * 100.0 / (totalFlights * 180)) : 0;

        System.out.println("=== STATISTICS REPORT ===");
        System.out.println("Total Flights: " + totalFlights);
        System.out.println("Total Reservations: " + totalReservations);
        System.out.printf("Average Occupancy: %.1f%%%n", occupancy);
        System.out.println("Available Planes: " + this.availablePlanes.size());
    }
}

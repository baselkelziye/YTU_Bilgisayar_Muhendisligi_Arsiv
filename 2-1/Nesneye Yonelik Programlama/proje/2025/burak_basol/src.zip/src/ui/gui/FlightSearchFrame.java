package ui.gui;

import flightmanagement.Flight;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.SeatManager;
import servicesandmanagers.TicketManager;
import reservationandticketing.Passenger;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class FlightSearchFrame extends JFrame {
    private final JTable flightTable;
    private final DefaultTableModel tableModel;
    private final JTextField searchField;
    private final FlightManager flightManager;
    private final SeatManager seatManager;
    private final ReservationManager reservationManager;
    private final TicketManager ticketManager;
    private final Passenger loggedInUser;

    private static final Color BG_COLOR = new Color(32, 33, 36);
    private static final Color PANEL_COLOR = new Color(48, 50, 56);
    private static final Color TEXT_COLOR = new Color(232, 234, 237);
    private static final Color ACCENT_COLOR = new Color(100, 149, 237);

    public FlightSearchFrame(FlightManager flightManager, ReservationManager reservationManager, TicketManager ticketManager, Passenger loggedInUser) {
        this.flightManager = flightManager;
        this.reservationManager = reservationManager;
        this.ticketManager = ticketManager;
        this.loggedInUser = loggedInUser;
        this.seatManager = new SeatManager();

        setTitle("Search Flights");
        setSize(800, 500);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG_COLOR);

        JPanel topPanel = new JPanel();
        topPanel.setBackground(PANEL_COLOR);
        topPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel searchLabel = new JLabel("Departure City:");
        searchLabel.setForeground(TEXT_COLOR);
        searchLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        searchField = new JTextField(15);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JButton searchBtn = new JButton("Search by Departure");
        searchBtn.setBackground(ACCENT_COLOR);
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        searchBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        searchBtn.addActionListener(e -> loadFlights(searchField.getText()));

        JButton showAllBtn = new JButton("Show All Flights");
        showAllBtn.setBackground(new Color(76, 175, 80));
        showAllBtn.setForeground(Color.WHITE);
        showAllBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        showAllBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        showAllBtn.addActionListener(e -> loadFlights(""));

        topPanel.add(searchLabel);
        topPanel.add(searchField);
        topPanel.add(searchBtn);
        topPanel.add(showAllBtn);
        add(topPanel, BorderLayout.NORTH);

        String[] columns = { "Flight No", "From", "To", "Date", "Time", "Duration", "Plane Model", "Available Seats" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        flightTable = new JTable(tableModel);
        flightTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        flightTable.setRowHeight(25);
        flightTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        flightTable.getTableHeader().setBackground(PANEL_COLOR);
        flightTable.getTableHeader().setForeground(TEXT_COLOR);

        JScrollPane scrollPane = new JScrollPane(flightTable);
        scrollPane.getViewport().setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(PANEL_COLOR);
        bottomPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton viewSeatsBtn = new JButton("View Available Seats");
        viewSeatsBtn.setBackground(new Color(255, 152, 0)); 
        viewSeatsBtn.setForeground(Color.WHITE);
        viewSeatsBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        viewSeatsBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        viewSeatsBtn.addActionListener(e -> showSelectedFlightSeats());

        bottomPanel.add(viewSeatsBtn);
        add(bottomPanel, BorderLayout.SOUTH);

        loadFlights("");
    }

    private void loadFlights(String filter) {
        tableModel.setRowCount(0);

        ArrayList<Flight> flightsToDisplay;

        if (filter.isEmpty()) {
            flightsToDisplay = flightManager.getFlights();
        } else {
            flightsToDisplay = new ArrayList<>();
            for (Flight f : flightManager.getFlights()) {
                if (f.getDeparturePlace().equalsIgnoreCase(filter)) {
                    flightsToDisplay.add(f);
                }
            }
        }

        for (Flight flight : flightsToDisplay) {
            int availableSeats = seatManager.getAvailableSeats(flight);
            String planeModel = flight.getPlane() != null ? flight.getPlane().getPlaneModel() : "N/A";

            String[] rowData = {
                    flight.getFlightNum(),
                    flight.getDeparturePlace(),
                    flight.getArrivalPlace(),
                    flight.getDate().toString(),
                    flight.getHour().toString(),
                    formatDuration(flight.getDuration()),
                    planeModel,
                    String.valueOf(availableSeats)
            };
            tableModel.addRow(rowData);
        }

        if (flightsToDisplay.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    filter.isEmpty() ? "No flights available." : "No flights found from: " + filter,
                    "Search Results", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private String formatDuration(java.time.Duration duration) {
        long hours = duration.toHours();
        long minutes = duration.toMinutes() % 60;
        return hours + "h " + minutes + "m";
    }

    private void showSelectedFlightSeats() {
        int selectedRow = flightTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a flight from the table first!",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String flightNum = (String) tableModel.getValueAt(selectedRow, 0);

        Flight selectedFlight = null;
        for (Flight flight : flightManager.getFlights()) {
            if (flight.getFlightNum().equals(flightNum)) {
                selectedFlight = flight;
                break;
            }
        }

        if (selectedFlight != null) {
            new SeatDisplayFrame(selectedFlight, seatManager, reservationManager, ticketManager, loggedInUser).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Could not find flight details!",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

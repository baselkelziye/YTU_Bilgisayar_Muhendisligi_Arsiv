package ui.theme;

import java.awt.*;

public class StyleConstants {

    
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font SUBHEADER_FONT = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font NORMAL_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BOLD_FONT = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font SMALL_FONT = new Font("Segoe UI", Font.PLAIN, 12);


    public static final int CORNER_RADIUS = 15;
    public static final int PADDING_SMALL = 10;
    public static final int PADDING_MEDIUM = 20;
    public static final int PADDING_LARGE = 30;


    public static final Color DARK_BG = new Color(32, 33, 36);
    public static final Color DARK_PANEL = new Color(42, 45, 50);
    public static final Color DARK_TEXT = new Color(232, 234, 237);
    public static final Color DARK_ACCENT = new Color(100, 149, 237);


    public static final Color LIGHT_BG = new Color(240, 242, 245);
    public static final Color LIGHT_PANEL = new Color(255, 255, 255);
    public static final Color LIGHT_TEXT = new Color(33, 33, 33);
    public static final Color LIGHT_ACCENT = new Color(25, 118, 210);
}

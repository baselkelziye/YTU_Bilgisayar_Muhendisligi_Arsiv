package ui.gui;

import reservationandticketing.Ticket;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;

public class TicketDisplayDialog extends JDialog {

    public TicketDisplayDialog(Frame parent, ArrayList<Ticket> tickets) {
        super(parent, "My Tickets", true);
        setSize(500, 600);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(32, 33, 36));

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(new Color(32, 33, 36));
        contentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        for (Ticket ticket : tickets) {
            contentPanel.add(createTicketPanel(ticket));
            contentPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        }

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        add(scrollPane, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(32, 33, 36));
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createTicketPanel(Ticket ticket) {
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.setBackground(new Color(48, 50, 56));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 149, 237), 2),
                new EmptyBorder(15, 15, 15, 15)));
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));

        addLabel(panel, "Ticket ID: " + ticket.getTicketID(), new Font("Segoe UI", Font.BOLD, 16), Color.WHITE);
        addLabel(panel, "PNR: " + ticket.getReservation().getReservationPNR(), new Font("Segoe UI", Font.BOLD, 14),
                Color.LIGHT_GRAY);
        addLabel(panel, "Flight: " + ticket.getReservation().getFlight().getFlightNum(),
                new Font("Segoe UI", Font.PLAIN, 14), Color.LIGHT_GRAY);
        addLabel(panel,
                "Seat: " + ticket.getReservation().getSeat().getSeatNum() + " ("
                        + ticket.getReservation().getSeat().getSeatClass() + ")",
                new Font("Segoe UI", Font.PLAIN, 14), Color.LIGHT_GRAY);
        addLabel(panel, "Passenger: " + ticket.getReservation().getPassenger().getName(),
                new Font("Segoe UI", Font.PLAIN, 14), Color.LIGHT_GRAY);
        addLabel(panel, "Date: " + ticket.getReservation().getDateOfReservation(), new Font("Segoe UI", Font.PLAIN, 14),
                Color.LIGHT_GRAY);
        addLabel(panel, "Baggage: " + ticket.getBaggageAllowance() + " kg", new Font("Segoe UI", Font.PLAIN, 14),
                Color.LIGHT_GRAY);
        addLabel(panel, "Price: $" + String.format("%.2f", ticket.getPrice()), new Font("Segoe UI", Font.BOLD, 16),
                new Color(100, 149, 237));

        return panel;
    }

    private void addLabel(JPanel panel, String text, Font font, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(color);
        panel.add(label);
    }
}

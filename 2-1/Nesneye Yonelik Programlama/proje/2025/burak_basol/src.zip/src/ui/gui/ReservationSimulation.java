package ui.gui;

import flightmanagement.Flight;
import flightmanagement.Plane;
import flightmanagement.Seat;
import reservationandticketing.Passenger;
import reservationandticketing.Reservation;
import servicesandmanagers.CalculatePrice;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.SeatManager;
import servicesandmanagers.TicketManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class ReservationSimulation extends JFrame {
    private static final Color BG_COLOR = new Color(32, 33, 36);
    private static final Color PANEL_COLOR = new Color(48, 50, 56);
    private static final Color TEXT_COLOR = new Color(232, 234, 237);
    private static final Color ACCENT_COLOR = new Color(100, 149, 237);

    private static final Color AVAILABLE_COLOR = Color.WHITE;
    private static final Color BUSINESS_CLASS_COLOR = new Color(216, 191, 216);
    private static final Color SELECTED_COLOR = new Color(152, 251, 152);
    private static final Color RESERVED_COLOR = Color.LIGHT_GRAY;

    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final SeatManager seatManager;
    private final TicketManager ticketManager;
    private final CalculatePrice priceCalculator;

    private JComboBox<String> flightComboBox;
    private JLabel flightInfoLabel;
    private JPanel seatGridPanel;
    private JButton loadSeatsButton;
    private JButton reserveButton;
    private JButton clearButton;
    private JLabel selectionInfoLabel;

    private JTextField searchPNRField;
    private JTextField searchFlightField;
    private JTextArea searchResultsArea;

    private Flight selectedFlight;
    private final ArrayList<JButton> seatButtons;
    private final Set<Seat> selectedSeats;
    private double totalPrice;
    private final Passenger loggedInPassenger;

    public ReservationSimulation() {
        this(null);
    }

    public ReservationSimulation(Passenger loggedInPassenger) {
        this.loggedInPassenger = loggedInPassenger;
        System.out.println("ReservationSimulation: Constructor called" +
                (loggedInPassenger != null ? " with logged-in passenger: " + loggedInPassenger.getName() : ""));

        try {
            System.out.println("Step 1: Getting ApplicationState...");
            ApplicationState appState = ApplicationState.getInstance();
            if (appState == null) {
                throw new IllegalStateException("ApplicationState is null");
            }

            System.out.println("Step 2: Initializing ApplicationState...");
            appState.initialize();

            System.out.println("Step 3: Getting FlightManager...");
            this.flightManager = appState.getFlightManager();
            if (this.flightManager == null) {
                throw new IllegalStateException("FlightManager is null");
            }

            System.out.println("Step 4: Getting ReservationManager...");
            this.reservationManager = appState.getReservationManager();
            if (this.reservationManager == null) {
                throw new IllegalStateException(
                        "ReservationManager is null - ApplicationState not properly initialized");
            }

            System.out.println("Step 4.5: Getting TicketManager...");
            this.ticketManager = appState.getTicketManager();
            if (this.ticketManager == null) {
                throw new IllegalStateException("TicketManager is null");
            }

            System.out.println("Step 5: Creating SeatManager...");
            this.seatManager = new SeatManager();

            System.out.println("Step 5.5: Creating CalculatePrice service...");
            this.priceCalculator = new CalculatePrice();

            System.out.println("Step 6: Initializing collections...");
            this.seatButtons = new ArrayList<>();
            this.selectedSeats = new HashSet<>();
            this.totalPrice = 0.0;

            System.out.println("Step 7: Setting JFrame properties...");
            setTitle("Seat Reservation System");
            setSize(1400, 800);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            getContentPane().setBackground(BG_COLOR);
            setLayout(new BorderLayout(10, 10));
            setLocationRelativeTo(null);
            System.out.println("Step 8: Building UI (initComponents)...");
            initComponents();
            System.out.println("SUCCESS: All initialization steps complete!");
        } catch (Exception e) {
            System.err.println("Error in ReservationSimulation constructor: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize ReservationSimulation", e);
        }
    }

    private void initComponents() {
        JPanel mainContainer = new JPanel(new BorderLayout(10, 10));
        mainContainer.setBackground(BG_COLOR);
        mainContainer.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(BG_COLOR);

        leftPanel.add(createFlightSelectionPanel(), BorderLayout.NORTH);

        seatGridPanel = new JPanel();
        seatGridPanel.setBackground(PANEL_COLOR);
        JScrollPane seatScrollPane = new JScrollPane(seatGridPanel);
        seatScrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(ACCENT_COLOR),
                "Seat Map",
                0, 0,
                new Font("Segoe UI", Font.BOLD, 14),
                TEXT_COLOR));
        leftPanel.add(seatScrollPane, BorderLayout.CENTER);

        leftPanel.add(createControlPanel(), BorderLayout.SOUTH);

        JPanel rightPanel = createSearchPanel();

        mainContainer.add(leftPanel, BorderLayout.CENTER);
        mainContainer.add(rightPanel, BorderLayout.EAST);

        add(mainContainer);
    }

    private JPanel createFlightSelectionPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(PANEL_COLOR);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT_COLOR),
                new EmptyBorder(15, 15, 15, 15)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel label = new JLabel("Select Flight:");
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        flightComboBox = new JComboBox<>();
        flightComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        panel.add(flightComboBox, gbc);

        gbc.gridx = 2;
        gbc.weightx = 0;
        loadSeatsButton = new JButton("Load Seats");
        styleButton(loadSeatsButton, ACCENT_COLOR);
        loadSeatsButton.addActionListener(e -> loadSeatsForSelectedFlight());
        panel.add(loadSeatsButton, gbc);

        loadFlights();

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        flightInfoLabel = new JLabel(" ");
        flightInfoLabel.setForeground(new Color(200, 200, 200));
        flightInfoLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        panel.add(flightInfoLabel, gbc);

        return panel;
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 3, 10, 10));
        panel.setBackground(PANEL_COLOR);
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        selectionInfoLabel = new JLabel("Selected: 0 seats | Total: $0.00", SwingConstants.CENTER);
        selectionInfoLabel.setForeground(TEXT_COLOR);
        selectionInfoLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panel.add(selectionInfoLabel);

        clearButton = new JButton("Clear Selection");
        styleButton(clearButton, new Color(255, 140, 0));
        clearButton.addActionListener(e -> clearSelection());
        clearButton.setEnabled(false);
        panel.add(clearButton);

        reserveButton = new JButton("Reserve Selected Seats");
        styleButton(reserveButton, new Color(46, 139, 87));
        reserveButton.addActionListener(e -> reserveSeats());
        reserveButton.setEnabled(false);
        panel.add(reserveButton);

        return panel;
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(PANEL_COLOR);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT_COLOR),
                new EmptyBorder(15, 15, 15, 15)));
        panel.setPreferredSize(new Dimension(350, 0));

        JLabel title = new JLabel("Search Reservations");
        title.setForeground(TEXT_COLOR);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel pnrLabel = new JLabel("Search by PNR:");
        pnrLabel.setForeground(TEXT_COLOR);
        pnrLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(pnrLabel);

        JPanel pnrPanel = new JPanel(new BorderLayout(5, 5));
        pnrPanel.setBackground(PANEL_COLOR);
        pnrPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        searchPNRField = new JTextField();
        JButton searchPNRButton = new JButton("Search");
        styleButton(searchPNRButton, ACCENT_COLOR);
        searchPNRButton.addActionListener(e -> searchByPNR());
        pnrPanel.add(searchPNRField, BorderLayout.CENTER);
        pnrPanel.add(searchPNRButton, BorderLayout.EAST);
        panel.add(pnrPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel flightLabel = new JLabel("Search by Flight Number:");
        flightLabel.setForeground(TEXT_COLOR);
        flightLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(flightLabel);

        JPanel flightPanel = new JPanel(new BorderLayout(5, 5));
        flightPanel.setBackground(PANEL_COLOR);
        flightPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        searchFlightField = new JTextField();
        JButton searchFlightButton = new JButton("Search");
        styleButton(searchFlightButton, ACCENT_COLOR);
        searchFlightButton.addActionListener(e -> searchByFlight());
        flightPanel.add(searchFlightField, BorderLayout.CENTER);
        flightPanel.add(searchFlightButton, BorderLayout.EAST);
        panel.add(flightPanel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel resultsLabel = new JLabel("Results:");
        resultsLabel.setForeground(TEXT_COLOR);
        resultsLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(resultsLabel);

        searchResultsArea = new JTextArea();
        searchResultsArea.setEditable(false);
        searchResultsArea.setLineWrap(true);
        searchResultsArea.setWrapStyleWord(true);
        searchResultsArea.setBackground(new Color(60, 64, 66));
        searchResultsArea.setForeground(Color.LIGHT_GRAY);
        searchResultsArea.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        JScrollPane scrollPane = new JScrollPane(searchResultsArea);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(scrollPane);

        return panel;
    }

    private void loadFlights() {
        flightComboBox.removeAllItems();
        ArrayList<Flight> flights = flightManager.getFlights();

        if (flights == null) {
            System.err.println("WARNING: flightManager.getFlights() returned null!");
            flightComboBox.addItem("Error: No flights (null)");
            loadSeatsButton.setEnabled(false);
            return;
        }

        if (flights.isEmpty()) {
            flightComboBox.addItem("No flights available");
            loadSeatsButton.setEnabled(false);
        } else {
            for (Flight flight : flights) {
                if (flight == null) {
                    System.err.println("WARNING: Null flight in flights list!");
                    continue;
                }

                String flightNum = flight.getFlightNum();
                String departure = flight.getDeparturePlace();
                String arrival = flight.getArrivalPlace();

                if (flightNum == null)
                    flightNum = "UNKNOWN";
                if (departure == null)
                    departure = "UNKNOWN";
                if (arrival == null)
                    arrival = "UNKNOWN";

                String item = flightNum + " - " + departure + " -> " + arrival;
                flightComboBox.addItem(item);
            }
            loadSeatsButton.setEnabled(true);
        }
    }

    private void loadSeatsForSelectedFlight() {
        System.out.println("loadSeatsForSelectedFlight: Called");
        int selectedIndex = flightComboBox.getSelectedIndex();
        System.out.println("Selected index: " + selectedIndex);
        if (selectedIndex < 0) {
            System.out.println("ERROR: No flight selected (index < 0)");
            return;
        }

        ArrayList<Flight> flights = flightManager.getFlights();
        System.out.println("Total flights: " + (flights != null ? flights.size() : "null"));
        if (selectedIndex >= flights.size()) {
            System.out.println("ERROR: Index out of bounds");
            return;
        }

        selectedFlight = flights.get(selectedIndex);
        if (selectedFlight == null) {
            System.out.println("ERROR: Selected flight is null!");
            JOptionPane.showMessageDialog(this, "Error: Flight data is null", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Plane plane = selectedFlight.getPlane();
        if (plane == null) {
            System.out.println("ERROR: Flight has no plane assigned!");
            JOptionPane.showMessageDialog(this,
                    "Error: This flight has no plane assigned.\nPlease assign a plane in Flight Manager.",
                    "No Plane", JOptionPane.WARNING_MESSAGE);
            return;
        }

        System.out.println("Flight: " + selectedFlight.getFlightNum() + ", Plane: " + plane.getPlaneModel());

        ArrayList<ArrayList<Seat>> seatMatrix = plane.getSeatMatrix();
        boolean needsInitialization = seatMatrix.isEmpty();

        if (!needsInitialization && !seatMatrix.isEmpty()) {
            if (seatMatrix.get(0).isEmpty()) {
                needsInitialization = true;
                System.out.println("Seat matrix has empty rows - needs initialization");
            }
        }

        if (needsInitialization) {
            System.out.println("Initializing seat matrix...");
            int rows = plane.getCapacity() / 6;
            plane.setSeatMatrix(seatManager.createSeatArrangement(rows, 6));
            seatMatrix = plane.getSeatMatrix();
        }
        System.out.println("Seat matrix size: " + seatMatrix.size() + " rows");
        if (!seatMatrix.isEmpty()) {
            System.out.println("First row has " + seatMatrix.get(0).size() + " seats");
        }

        flightInfoLabel.setText(String.format("Flight: %s | Date: %s | Time: %s | Plane: %s",
                selectedFlight.getFlightNum(),
                selectedFlight.getDate(),
                selectedFlight.getHour(),
                plane.getPlaneModel()));

        clearSelection();

        System.out.println("Building seat grid...");
        buildSeatGrid(plane);
        System.out.println("Seat grid built successfully!");
    }

    private void buildSeatGrid(Plane plane) {
        System.out.println("buildSeatGrid: Starting...");
        seatGridPanel.removeAll();
        seatButtons.clear();

        ArrayList<ArrayList<Seat>> seatMatrix = plane.getSeatMatrix();

        if (seatMatrix == null || seatMatrix.isEmpty()) {
            System.out.println("ERROR: Seat matrix is null or empty");
            JLabel errorLabel = new JLabel("No seats available - seat matrix is empty");
            errorLabel.setForeground(TEXT_COLOR);
            errorLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            seatGridPanel.add(errorLabel);
            seatGridPanel.revalidate();
            seatGridPanel.repaint();
            return;
        }

        if (seatMatrix.get(0).isEmpty()) {
            System.out.println("ERROR: Seat matrix rows are empty");
            JLabel errorLabel = new JLabel("No seats available - seat rows are empty");
            errorLabel.setForeground(TEXT_COLOR);
            errorLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            seatGridPanel.add(errorLabel);
            seatGridPanel.revalidate();
            seatGridPanel.repaint();
            return;
        }

        int rows = seatMatrix.size();
        int cols = seatMatrix.get(0).size();
        System.out.println("Building grid: " + rows + " rows x " + cols + " cols");

        seatGridPanel.setLayout(new GridLayout(rows, cols, 3, 3));
        seatGridPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        for (int r = 0; r < rows; r++) {
            ArrayList<Seat> rowSeats = seatMatrix.get(r);

            if (rowSeats.size() != cols) {
                System.out.println("WARNING: Row " + r + " has " + rowSeats.size() + " seats, expected " + cols);
            }

            for (int c = 0; c < rowSeats.size(); c++) {
                Seat seat = rowSeats.get(c);
                JButton seatButton = new JButton(seat.getSeatNum());
                seatButton.setFont(new Font("Segoe UI", Font.BOLD, 10));
                seatButton.setPreferredSize(new Dimension(50, 40));

                if (seat.getReserveStatus()) {
                    seatButton.setBackground(RESERVED_COLOR);
                    seatButton.setEnabled(false);
                    seatButton.setToolTipText("Already Reserved");
                } else {
                    if (seat.getSeatClass().toString().equals("BUSINESS")) {
                        seatButton.setBackground(BUSINESS_CLASS_COLOR);
                    } else {
                        seatButton.setBackground(AVAILABLE_COLOR);
                    }
                    seatButton.setForeground(Color.BLACK);
                    seatButton.setEnabled(true);

                    double finalPrice = priceCalculator.calculatePrice(seat);
                    seatButton.setToolTipText(String.format("%s - $%.2f (%s) [incl. 18%% tax]",
                            seat.getSeatNum(), finalPrice, seat.getSeatClass()));

                    seatButton.addActionListener(e -> toggleSeatSelection(seat, seatButton));
                }

                seatButtons.add(seatButton);
                seatGridPanel.add(seatButton);
            }
        }

        System.out.println("Total seat buttons created: " + seatButtons.size());
        seatGridPanel.revalidate();
        seatGridPanel.repaint();
        System.out.println("buildSeatGrid: Complete - panel refreshed");
    }

    private void toggleSeatSelection(Seat seat, JButton button) {
        double calculatedPrice = priceCalculator.calculatePrice(seat);

        if (selectedSeats.contains(seat)) {
            selectedSeats.remove(seat);
            totalPrice -= calculatedPrice;

            if (seat.getSeatClass().toString().equals("BUSINESS")) {
                button.setBackground(BUSINESS_CLASS_COLOR);
            } else {
                button.setBackground(AVAILABLE_COLOR);
            }
            button.setForeground(Color.BLACK);
        } else {
            selectedSeats.add(seat);
            totalPrice += calculatedPrice;
            button.setBackground(SELECTED_COLOR);
            button.setForeground(Color.BLACK);
        }

        updateSelectionInfo();
    }

    private void updateSelectionInfo() {
        selectionInfoLabel.setText(String.format("Selected: %d seats | Total: $%.2f",
                selectedSeats.size(), totalPrice));

        boolean hasSelection = !selectedSeats.isEmpty();
        clearButton.setEnabled(hasSelection);
        reserveButton.setEnabled(hasSelection);
    }

    private void clearSelection() {
        selectedSeats.clear();
        totalPrice = 0.0;

        for (JButton btn : seatButtons) {
            if (btn.isEnabled()) {
                btn.setBackground(AVAILABLE_COLOR);
                btn.setForeground(Color.BLACK);
            }
        }

        updateSelectionInfo();
    }

    private void reserveSeats() {
        if (selectedSeats.isEmpty() || selectedFlight == null) {
            return;
        }

        Passenger passenger;
        String reservationDate = LocalDate.now().toString();

        
        String weightStr = JOptionPane.showInputDialog(this, "Please enter your baggage weight (kg):", "Baggage Check",
                JOptionPane.QUESTION_MESSAGE);
        if (weightStr == null)
            return; 

        double baggageWeight;
        try {
            baggageWeight = Double.parseDouble(weightStr);
            if (baggageWeight < 0) {
                JOptionPane.showMessageDialog(this, "Weight cannot be negative.", "Invalid Weight",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (baggageWeight > 15) {
                JOptionPane.showMessageDialog(this, "Reservation rejected. Baggage weight cannot exceed 15kg.",
                        "Baggage Limit Exceeded", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid weight format.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (loggedInPassenger != null) {
            
            passenger = loggedInPassenger;

            StringBuilder pnrList = new StringBuilder();
            pnrList.append("Reservation successful for ").append(passenger.getName()).append("!\n\n");
            pnrList.append("Passenger ID: ").append(passenger.getPassengerID()).append("\n");
            pnrList.append("Contact: ").append(passenger.getContactInfo()).append("\n\n");
            pnrList.append("Reservations:\n");

            for (Seat seat : selectedSeats) {
                reservationManager.creatReservation(selectedFlight, passenger, seat, reservationDate, baggageWeight);
                Reservation lastReservation = reservationManager.searchReservation(
                        reservationManager.getAllReservations()
                                .get(reservationManager.getAllReservations().size() - 1)
                                .getReservationPNR());

                
                ticketManager.createTicket(lastReservation);

                pnrList.append("* PNR: ").append(lastReservation.getReservationPNR())
                        .append(" - Seat ").append(seat.getSeatNum())
                        .append(" - $").append(String.format("%.2f", priceCalculator.calculatePrice(seat)))
                        .append("\n");
            }

            pnrList.append("\nTotal Price: $").append(String.format("%.2f", totalPrice));

            JOptionPane.showMessageDialog(this, pnrList.toString(),
                    "Reservation Confirmed", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JTextField nameField = new JTextField();
            JTextField passportField = new JTextField();
            JTextField contactField = new JTextField();

            Object[] message = {
                    "Passenger Name:", nameField,
                    "Passport Number:", passportField,
                    "Contact Info:", contactField
            };

            int option = JOptionPane.showConfirmDialog(this, message,
                    "Enter Passenger Details", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                String name = nameField.getText().trim();
                String passport = passportField.getText().trim();
                String contact = contactField.getText().trim();

                if (name.isEmpty() || passport.isEmpty() || contact.isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                            "All fields are required!",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                
                passenger = new Passenger(passport, name, "", contact);

                
                StringBuilder pnrList = new StringBuilder("Reservation successful!\n\nPNRs:\n");

                for (Seat seat : selectedSeats) {
                    reservationManager.creatReservation(selectedFlight, passenger, seat, reservationDate,
                            baggageWeight);
                    Reservation lastReservation = reservationManager.searchReservation(
                            reservationManager.getAllReservations()
                                    .get(reservationManager.getAllReservations().size() - 1)
                                    .getReservationPNR());

                    
                    ticketManager.createTicket(lastReservation);

                    pnrList.append("* ").append(lastReservation.getReservationPNR())
                            .append(" - Seat ").append(seat.getSeatNum()).append("\n");
                }

                JOptionPane.showMessageDialog(this, pnrList.toString(),
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                return; 
            }
        }

        loadSeatsForSelectedFlight();
    }

    private void searchByPNR() {
        String pnr = searchPNRField.getText().trim().toUpperCase();
        System.out.println("searchByPNR: Searching for PNR: '" + pnr + "'");
        if (pnr.isEmpty()) {
            searchResultsArea.setText("Please enter a PNR code.");
            return;
        }

        Reservation reservation = reservationManager.searchReservation(pnr);
        System.out.println("Search result: " + (reservation != null ? "FOUND" : "NOT FOUND"));
        if (reservation == null) {
            searchResultsArea.setText("No reservation found with PNR: " + pnr);
        } else {
            displayReservation(reservation);
        }
    }

    private void searchByFlight() {
        String flightNum = searchFlightField.getText().trim();
        if (flightNum.isEmpty()) {
            searchResultsArea.setText("Please enter a flight number.");
            return;
        }

        ArrayList<Reservation> matchingReservations = reservationManager.searchReservationsByFlight(flightNum);

        if (matchingReservations.isEmpty()) {
            searchResultsArea.setText("No reservations found for flight: " + flightNum);
        } else {
            StringBuilder result = new StringBuilder();
            result.append("Found ").append(matchingReservations.size())
                    .append(" reservation(s) for flight ").append(flightNum).append(":\n\n");

            for (Reservation res : matchingReservations) {
                result.append("PNR: ").append(res.getReservationPNR()).append("\n");
                result.append("Passenger: ").append(res.getPassenger().getName()).append("\n");
                result.append("Seat: ").append(res.getSeat().getSeatNum()).append("\n");
                result.append("Date: ").append(res.getDateOfReservation()).append("\n");
                result.append("---\n");
            }

            searchResultsArea.setText(result.toString());
        }
    }

    private void displayReservation(Reservation res) {
        String info = "=== RESERVATION DETAILS ===\n\n" +
                "PNR: " + res.getReservationPNR() + "\n" +
                "Flight: " + res.getFlight().getFlightNum() + "\n" +
                "Route: " + res.getFlight().getDeparturePlace() +
                " -> " + res.getFlight().getArrivalPlace() + "\n" +
                "Date: " + res.getFlight().getDate() + "\n" +
                "Time: " + res.getFlight().getHour() + "\n" +
                "Passenger: " + res.getPassenger().getName() + "\n" +
                "Contact: " + res.getPassenger().getContactInfo() + "\n" +
                "Seat: " + res.getSeat().getSeatNum() + "\n" +
                "Class: " + res.getSeat().getSeatClass() + "\n" +
                "Price: $" + String.format("%.2f", res.getSeat().getPrice()) + "\n" +
                "Reservation Date: " + res.getDateOfReservation() + "\n";

        searchResultsArea.setText(info);
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBorder(new EmptyBorder(8, 15, 8, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}
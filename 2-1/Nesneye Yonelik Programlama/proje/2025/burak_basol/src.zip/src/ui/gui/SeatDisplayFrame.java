package ui.gui;

import flightmanagement.Flight;
import flightmanagement.Seat;
import reservationandticketing.Passenger;
import reservationandticketing.Reservation;
import servicesandmanagers.CalculatePrice;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.SeatManager;
import servicesandmanagers.TicketManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class SeatDisplayFrame extends JFrame {
    private final Flight flight;
    private final SeatManager seatManager;
    private final ReservationManager reservationManager;
    private final TicketManager ticketManager;
    private final CalculatePrice priceCalculator;
    private final Passenger loggedInUser;

    
    private static final Color BG_COLOR = new Color(32, 33, 36);
    private static final Color PANEL_COLOR = new Color(48, 50, 56);
    private static final Color TEXT_COLOR = new Color(232, 234, 237);
    private static final Color AVAILABLE_SEAT_COLOR = new Color(76, 175, 80); 
    private static final Color RESERVED_SEAT_COLOR = new Color(244, 67, 54); 
    private static final Color BUSINESS_CLASS_COLOR = new Color(216, 191, 216); 

    public SeatDisplayFrame(Flight flight, SeatManager seatManager, ReservationManager reservationManager, TicketManager ticketManager, Passenger loggedInUser) {
        this.flight = flight;
        this.seatManager = seatManager;
        this.reservationManager = reservationManager;
        this.ticketManager = ticketManager;
        this.loggedInUser = loggedInUser;
        this.priceCalculator = new CalculatePrice();

        setTitle("Seat Map - Flight " + flight.getFlightNum());
        setSize(700, 600);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG_COLOR);

        
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        
        JPanel seatGridPanel = createSeatGridPanel();
        JScrollPane scrollPane = new JScrollPane(seatGridPanel);
        scrollPane.getViewport().setBackground(BG_COLOR);
        add(scrollPane, BorderLayout.CENTER);

        
        JPanel legendPanel = createLegendPanel();
        add(legendPanel, BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(PANEL_COLOR);
        panel.setBorder(new EmptyBorder(15, 20, 15, 20));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel flightLabel = new JLabel("Flight: " + flight.getFlightNum());
        flightLabel.setForeground(TEXT_COLOR);
        flightLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JLabel routeLabel = new JLabel(flight.getDeparturePlace() + " -> " + flight.getArrivalPlace());
        routeLabel.setForeground(TEXT_COLOR);
        routeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JLabel planeLabel = new JLabel("Aircraft: " + flight.getPlane().getPlaneModel() +
                " | Capacity: " + flight.getPlane().getCapacity());
        planeLabel.setForeground(TEXT_COLOR);
        planeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        int availableSeats = seatManager.getAvailableSeats(flight);
        JLabel availabilityLabel = new JLabel("Available Seats: " + availableSeats +
                " / " + flight.getPlane().getCapacity());
        availabilityLabel.setForeground(AVAILABLE_SEAT_COLOR);
        availabilityLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        panel.add(flightLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.add(routeLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.add(planeLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.add(availabilityLabel);

        return panel;
    }

    private JPanel createSeatGridPanel() {
        JPanel gridPanel = new JPanel();
        gridPanel.setBackground(BG_COLOR);
        gridPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        ArrayList<ArrayList<Seat>> seatMatrix = flight.getPlane().getSeatMatrix();

        if (seatMatrix == null || seatMatrix.isEmpty()) {
            JLabel noSeatsLabel = new JLabel("No seat information available for this flight.");
            noSeatsLabel.setForeground(TEXT_COLOR);
            noSeatsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            gridPanel.add(noSeatsLabel);
            return gridPanel;
        }

        int rows = seatMatrix.size();
        int cols = seatMatrix.get(0).size();

        
        gridPanel.setLayout(new GridLayout(rows + 1, cols + 2, 5, 5)); 
                                                                       

        
        gridPanel.add(createLabel("")); 
        char[] colLetters = { 'A', 'B', 'C', 'D', 'E', 'F' };
        for (int c = 0; c < cols; c++) {
            if (c == cols / 2) {
                gridPanel.add(createLabel("  ")); 
            }
            JLabel colHeader = createLabel(String.valueOf(colLetters[c]));
            colHeader.setFont(new Font("Segoe UI", Font.BOLD, 12));
            gridPanel.add(colHeader);
        }

        
        for (int r = 0; r < rows; r++) {
            
            JLabel rowLabel = createLabel(String.valueOf(r + 1));
            rowLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
            gridPanel.add(rowLabel);

            ArrayList<Seat> rowSeats = seatMatrix.get(r);
            for (int c = 0; c < rowSeats.size(); c++) {
                if (c == cols / 2) {
                    gridPanel.add(createLabel("  ")); 
                }

                Seat seat = rowSeats.get(c);
                JButton seatButton = createSeatButton(seat);
                gridPanel.add(seatButton);
            }
        }

        return gridPanel;
    }

    private JButton createSeatButton(Seat seat) {
        JButton button = new JButton(seat.getSeatNum());
        button.setFont(new Font("Segoe UI", Font.BOLD, 11));
        button.setPreferredSize(new Dimension(60, 40));
        button.setFocusPainted(false);

        
        if (seat.getReserveStatus()) {
            button.setBackground(RESERVED_SEAT_COLOR);
            button.setForeground(Color.WHITE);
            button.setEnabled(false);
        } else {
            
            if (seat.getSeatClass().toString().equals("BUSINESS")) {
                button.setBackground(BUSINESS_CLASS_COLOR);
            } else {
                button.setBackground(AVAILABLE_SEAT_COLOR);
            }
            button.setForeground(Color.WHITE);

            
            double finalPrice = priceCalculator.calculatePrice(seat);
            button.setToolTipText(String.format("%s - $%.2f (%s) [incl. 18%% tax]",
                    seat.getSeatNum(), finalPrice, seat.getSeatClass()));
            button.addActionListener(e -> selectSeat(seat));
        }

        return button;
    }

    private void selectSeat(Seat seat) {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Do you want to reserve seat " + seat.getSeatNum() + " (" + seat.getSeatClass() + ")?",
                "Reserve Seat",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // Get baggage weight
                String weightStr = JOptionPane.showInputDialog(this, "Please enter baggage weight (kg):", "Baggage", JOptionPane.QUESTION_MESSAGE);
                if (weightStr == null) return;
                
                double baggageWeight;
                try {
                    baggageWeight = Double.parseDouble(weightStr);
                    if (baggageWeight < 0 || baggageWeight > 15) {
                        JOptionPane.showMessageDialog(this, "Invalid weight (0-15kg).", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid number.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Passenger passenger = loggedInUser;
                // If guest, get details
                if (passenger == null) {
                    JTextField nameField = new JTextField();
                    JTextField passportField = new JTextField();
                    JTextField contactField = new JTextField();
                    
                    Object[] message = {
                        "Name:", nameField,
                        "Passport:", passportField,
                        "Contact:", contactField
                    };

                    int option = JOptionPane.showConfirmDialog(this, message, "Passenger Details", JOptionPane.OK_CANCEL_OPTION);
                    if (option != JOptionPane.OK_OPTION) return;
                    
                    String name = nameField.getText().trim();
                    String passport = passportField.getText().trim();
                    String contact = contactField.getText().trim();
                    
                    if (name.isEmpty() || passport.isEmpty() || contact.isEmpty()) {
                         JOptionPane.showMessageDialog(this, "All fields required.", "Error", JOptionPane.ERROR_MESSAGE);
                         return;
                    }
                    passenger = new Passenger(passport, name, "", contact);
                }

                // Create reservation
                String date = LocalDate.now().toString();
                reservationManager.creatReservation(flight, passenger, seat, date, baggageWeight);
                
                // Get the created reservation (it's added to the list, so get the last one or search)
                // Since creatReservation adds it and saves it, we can try to find it.
                // But wait, creatReservation doesn't return the ID. 
                // Let's assume the one we just added is the last one in the list?
                // Or better, searchReservation doesn't work well without PNR.
                // However, the reservation object we created inside Manager is not returned.
                // We should probably rely on finding it by passenger and flight?
                // Actually, looking at ReservationSimulation, it gets the last reservation from the list.
                // Let's do that for now to match existing logic.
                
                ArrayList<Reservation> allRes = reservationManager.getAllReservations();
                if (!allRes.isEmpty()) {
                    Reservation newRes = allRes.get(allRes.size() - 1);
                    ticketManager.createTicket(newRes);
                    
                    JOptionPane.showMessageDialog(this,
                            "Reservation Successful!\nPNR: " + newRes.getReservationPNR() + "\nSeat: " + seat.getSeatNum(),
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                     JOptionPane.showMessageDialog(this, "Reservation created but could not retrieve PNR.", "Warning", JOptionPane.WARNING_MESSAGE);
                }

                // Refresh UI
                dispose();
                new SeatDisplayFrame(flight, seatManager, reservationManager, ticketManager, loggedInUser).setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "Error reserving seat: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private JPanel createLegendPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(PANEL_COLOR);
        panel.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel legendTitle = new JLabel("Legend: ");
        legendTitle.setForeground(TEXT_COLOR);
        legendTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));

        JLabel availableLabel = new JLabel("[E] Available (Economy)");
        availableLabel.setForeground(AVAILABLE_SEAT_COLOR);
        availableLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JLabel businessLabel = new JLabel("[B] Available (Business)");
        businessLabel.setForeground(BUSINESS_CLASS_COLOR);
        businessLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JLabel reservedLabel = new JLabel("[R] Reserved");
        reservedLabel.setForeground(RESERVED_SEAT_COLOR);
        reservedLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        panel.add(legendTitle);
        panel.add(Box.createRigidArea(new Dimension(20, 0)));
        panel.add(availableLabel);
        panel.add(Box.createRigidArea(new Dimension(15, 0)));
        panel.add(businessLabel);
        panel.add(Box.createRigidArea(new Dimension(15, 0)));
        panel.add(reservedLabel);

        return panel;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        return label;
    }
}

package ui.gui;

import flightmanagement.Plane;
import servicesandmanagers.FlightManager;
import ui.gui.components.ModernButton;
import ui.gui.components.ModernTextField;
import ui.theme.StyleConstants;
import ui.theme.ThemeManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

public class FlightManagerFrame extends JFrame implements ThemeManager.ThemeListener {

    private ModernTextField fNum, fDep, fArr, fDate, fHour, fDurationHours, fDurationMins;
    private JComboBox<String> planeComboBox;
    private JPanel mainPanel;
    private JPanel durationPanel;
    private JButton saveBtn;

    private final FlightManager flightManager;
    private final ArrayList<Plane> availablePlanes;

    public FlightManagerFrame(FlightManager flightManager, ArrayList<Plane> availablePlanes) {
        this.flightManager = flightManager;
        this.availablePlanes = availablePlanes;

        setTitle("Admin - Flight Management");
        setSize(550, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        ThemeManager.getInstance().addListener(this);

        initializeUI();
        updateTheme();
    }

    private void initializeUI() {
        mainPanel = new JPanel(new GridLayout(8, 2, 10, 15));
        mainPanel.setBorder(new EmptyBorder(30, 30, 30, 30));

        mainPanel.add(createStyledLabel("Flight Number:"));
        fNum = new ModernTextField(15);
        mainPanel.add(fNum);

        mainPanel.add(createStyledLabel("Departure:"));
        fDep = new ModernTextField(15);
        mainPanel.add(fDep);

        mainPanel.add(createStyledLabel("Arrival:"));
        fArr = new ModernTextField(15);
        mainPanel.add(fArr);

        mainPanel.add(createStyledLabel("Date (yyyy-MM-dd):"));
        fDate = new ModernTextField(15);
        fDate.setToolTipText("Format: 2026-01-15");
        mainPanel.add(fDate);

        mainPanel.add(createStyledLabel("Time (HH:mm):"));
        fHour = new ModernTextField(15);
        fHour.setToolTipText("Format: 14:30");
        mainPanel.add(fHour);

        mainPanel.add(createStyledLabel("Duration (Hours:Mins):"));
        durationPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        fDurationHours = new ModernTextField(5);
        fDurationHours.setToolTipText("Hours");
        fDurationMins = new ModernTextField(5);
        fDurationMins.setToolTipText("Minutes");
        durationPanel.add(fDurationHours);
        durationPanel.add(fDurationMins);
        mainPanel.add(durationPanel);

        mainPanel.add(createStyledLabel("Select Plane:"));
        String[] planeOptions = new String[availablePlanes.size()];
        for (int i = 0; i < availablePlanes.size(); i++) {
            Plane p = availablePlanes.get(i);
            planeOptions[i] = p.getPlaneModel() + " (" + p.getPlaneID() + ", Cap: " + p.getCapacity() + ")";
        }
        planeComboBox = new JComboBox<>(planeOptions);
        planeComboBox.setFont(StyleConstants.NORMAL_FONT);
        mainPanel.add(planeComboBox);

        saveBtn = new ModernButton("Add Flight");
        saveBtn.setBackground(ThemeManager.getInstance().getAccentColor());
        saveBtn.addActionListener(e -> saveFlight());
        mainPanel.add(saveBtn);

        add(mainPanel);
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(StyleConstants.BOLD_FONT);
        return label;
    }

    private void saveFlight() {
        try {
            String flightNum = fNum.getText().trim();
            String departure = fDep.getText().trim();
            String arrival = fArr.getText().trim();
            String dateStr = fDate.getText().trim();
            String timeStr = fHour.getText().trim();
            String durationHoursStr = fDurationHours.getText().trim();
            String durationMinsStr = fDurationMins.getText().trim();

            if (flightNum.isEmpty() || departure.isEmpty() || arrival.isEmpty() ||
                    dateStr.isEmpty() || timeStr.isEmpty() || durationHoursStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all required fields!",
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE);
            LocalTime time = LocalTime.parse(timeStr, DateTimeFormatter.ofPattern("HH:mm"));

            int hours = Integer.parseInt(durationHoursStr);
            int minutes = durationMinsStr.isEmpty() ? 0 : Integer.parseInt(durationMinsStr);
            Duration duration = Duration.ofHours(hours).plusMinutes(minutes);

            int selectedIndex = planeComboBox.getSelectedIndex();
            Plane selectedPlane = availablePlanes.get(selectedIndex);

            flightManager.createFlight(flightNum, selectedPlane, departure, arrival, date, time, duration);

            JOptionPane.showMessageDialog(this,
                    "Flight " + flightNum + " added successfully!\nFrom: " + departure + " To: " + arrival,
                    "Success", JOptionPane.INFORMATION_MESSAGE);


            fNum.setText("");
            fDep.setText("");
            fArr.setText("");
            fDate.setText("");
            fHour.setText("");
            fDurationHours.setText("");
            fDurationMins.setText("");

        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                    "Invalid date or time format!\nDate: yyyy-MM-dd (e.g., 2026-01-15)\nTime: HH:mm (e.g., 14:30)",
                    "Format Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Duration must be numeric values!",
                    "Format Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error adding flight: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme newTheme) {
        updateTheme();
    }

    private void updateTheme() {
        ThemeManager tm = ThemeManager.getInstance();

        getContentPane().setBackground(tm.getBackgroundColor());
        mainPanel.setBackground(tm.getBackgroundColor());
        durationPanel.setBackground(tm.getBackgroundColor());

        for (Component c : mainPanel.getComponents()) {
            if (c instanceof JLabel) {
                c.setForeground(tm.getTextColor());
            }
        }

        saveBtn.setBackground(tm.getAccentColor());

        planeComboBox.setBackground(tm.getInputBackgroundColor());
        planeComboBox.setForeground(Color.BLACK);

        SwingUtilities.updateComponentTreeUI(this);
    }
}

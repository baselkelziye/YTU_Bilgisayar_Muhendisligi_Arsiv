package ui.cli;

import reservationandticketing.Ticket;
import java.util.ArrayList;

public class TicketDisplayDialog {

    public TicketDisplayDialog() {}

    public void display(final ArrayList<Ticket> tickets) {
        System.out.println("\n--- My Tickets ---");
        if (tickets.isEmpty()) {
            System.out.println("No tickets found.");
            return;
        }

        for (final Ticket t : tickets) {
            System.out.println("--------------------------------");
            System.out.println("Ticket ID: " + t.getTicketID());
            System.out.println("PNR: " + t.getReservation().getReservationPNR());
            System.out.println("Flight: " + t.getReservation().getFlight().getFlightNum());
            System.out.println("Seat: " + t.getReservation().getSeat().getSeatNum() + " (" + t.getReservation().getSeat().getSeatClass() + ")");
            System.out.println("Passenger: " + t.getReservation().getPassenger().getName());
            System.out.println("Date: " + t.getReservation().getDateOfReservation());
            System.out.println("Price: $" + String.format("%.2f", t.getPrice()));
            System.out.println("--------------------------------");
        }
    }
}

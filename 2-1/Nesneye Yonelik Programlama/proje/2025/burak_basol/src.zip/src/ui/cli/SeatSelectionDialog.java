package ui.cli;

import flightmanagement.Flight;
import flightmanagement.Seat;
import servicesandmanagers.CalculatePrice;

import java.util.ArrayList;
import java.util.Scanner;

public class SeatSelectionDialog {

    private final Flight flight;
    private final Seat currentSeat;
    private Seat selectedSeat;

    public SeatSelectionDialog(final Flight flight, final Seat currentSeat) {
        this.flight = flight;
        this.currentSeat = currentSeat;
    }

    public void start(final Scanner scanner) {
        System.out.println("\n--- Select New Seat ---");
        System.out.println("Current Seat: " + this.currentSeat.getSeatNum());

        
        final ArrayList<ArrayList<Seat>> matrix = this.flight.getPlane().getSeatMatrix();
        final int rows = matrix.size();
        final int cols = matrix.get(0).size();
        final int gapIndex = cols / 2;

        System.out.println("Legend: [ ] Available, [X] Reserved, [O] Your Current Seat");
        
         
        final char[] colLetters = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I' };
        System.out.print("      ");
        for (int c = 0; c < cols; c++) {
            if (c == gapIndex) System.out.print("  ");
            System.out.printf(" %-5s", colLetters[c % colLetters.length]);
        }
        System.out.println();

        for (int r = 0; r < rows; r++) {
            System.out.printf("Row %-2d", (r + 1));
            final ArrayList<Seat> rowSeats = matrix.get(r);
            for (int c = 0; c < rowSeats.size(); c++) {
                if (c == gapIndex) System.out.print("  ");
                
                final Seat seat = rowSeats.get(c);
                final String seatStr = seat.getSeatNum();
                
                if (seat.getSeatNum().equals(this.currentSeat.getSeatNum())) {
                     System.out.print(" [  O  ]");
                } else if (seat.getReserveStatus()) {
                    System.out.print(" [  X  ]");
                } else {
                    System.out.printf(" [%3s ]", seatStr);
                }
            }
            System.out.println();
        }

        System.out.print("\nEnter Seat Number to Select (or 'cancel'): ");
        final String input = scanner.nextLine().trim();

        if ("cancel".equalsIgnoreCase(input)) {
            return;
        }

        
        Seat pick = null;
        for (final ArrayList<Seat> row : matrix) {
            for (final Seat seat : row) {
                if (seat.getSeatNum().equalsIgnoreCase(input)) {
                    pick = seat;
                    break;
                }
            }
            if (null != pick) break;
        }

        if (null == pick) {
            System.out.println("Invalid seat number.");
            return;
        }
        
        if (pick.getSeatNum().equals(this.currentSeat.getSeatNum())) {
             System.out.println("That is your current seat.");
             return;
        }

        if (pick.getReserveStatus()) {
            System.out.println("Seat is already taken.");
            return;
        }

        final CalculatePrice pricer = new CalculatePrice();
        final double price = pricer.calculatePrice(pick);
        System.out.printf("Selected Seat: %s (%s) - Price: $%.2f%n", pick.getSeatNum(), pick.getSeatClass(), price);
        
        System.out.print("Confirm selection? (yes/no): ");
        if ("yes".equalsIgnoreCase(scanner.nextLine().trim())) {
            this.selectedSeat = pick;
        }
    }

    public Seat getSelectedSeat() {
        return this.selectedSeat;
    }
}

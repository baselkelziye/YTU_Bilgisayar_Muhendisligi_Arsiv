package ui.cli;

import reservationandticketing.User;
import servicesandmanagers.UserManager;

import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class LoginScreen {

    private final UserManager userManager;
    private final Scanner scanner;

    public LoginScreen() {
        userManager = new UserManager();
        scanner = new Scanner(System.in, StandardCharsets.UTF_8);
    }

    public static void main(final String[] args) {
        new LoginScreen().start();
    }

    public void start() {
        System.out.println("Welcome Aboard - Airline System CLI");
        boolean running = true;

        while (running) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Login as Passenger");
            System.out.println("2. Register New Passenger");
            System.out.println("3. Login as Staff");
            System.out.println("4. Register New Staff");
            System.out.println("5. Login as Admin");
            System.out.println("6. Register New Admin");
            System.out.println("7. Exit");
            System.out.print("Select an option: ");

            final String input = this.scanner.nextLine();

            switch (input) {
                case "1":
                    this.handleLogin("PASSENGER");
                    break;
                case "2":
                    this.handlePassengerRegister();
                    break;
                case "3":
                    this.handleLogin("STAFF");
                    break;
                case "4":
                    this.handleStaffRegister();
                    break;
                case "5":
                    this.handleLogin("ADMIN");
                    break;
                case "6":
                    this.handleAdminRegister();
                    break;
                case "7":
                    System.out.println("Exiting System. Goodbye!");
                    running = false;
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void handleLogin(final String userType) {
        System.out.println("\n--- " + userType + " Login ---");
        System.out.print("Username: ");
        final String username = this.scanner.nextLine().trim();
        System.out.print("Password: ");
        final String password = this.scanner.nextLine().trim();

        if (username.isEmpty() || password.isEmpty()) {
            System.out.println("Error: Please fill in all fields.");
            return;
        }

        final User user = this.userManager.authenticate(username, password, userType);

        if (null != user) {
            System.out.println("Login Successful as " + userType + "!");
            new MainDashboard(userType, user, this.scanner).start();
        } else {
            System.out.println("Error: Invalid credentials for " + userType);
        }
    }

    private void handlePassengerRegister() {
        System.out.println("\n--- Register Passenger ---");
        System.out.print("Username: ");
        final String username = this.scanner.nextLine().trim();
        System.out.print("Password: ");
        final String password = this.scanner.nextLine().trim();
        System.out.print("Confirm Password: ");
        final String confirm = this.scanner.nextLine().trim();
        System.out.print("Passenger ID: ");
        final String passengerId = this.scanner.nextLine().trim();
        System.out.print("First Name: ");
        final String name = this.scanner.nextLine().trim();
        System.out.print("Last Name: ");
        final String surname = this.scanner.nextLine().trim();
        System.out.print("Contact Info: ");
        final String contact = this.scanner.nextLine().trim();

        if (username.isEmpty() || password.isEmpty() || passengerId.isEmpty() || name.isEmpty()) {
            System.out.println("Error: Username, password, passenger ID, and name are required.");
            return;
        }

        if (!password.equals(confirm)) {
            System.out.println("Error: Passwords do not match.");
            return;
        }

        if (this.userManager.userExists(username, "PASSENGER")) {
            System.out.println("Error: Username already exists.");
            return;
        }

        final boolean success = this.userManager.registerPassenger(username, password, passengerId, name, surname, contact);

        if (success) {
            System.out.println("Success: Passenger account created! You can now log in.");
        } else {
            System.out.println("Error: Failed to create account.");
        }
    }

    private void handleStaffRegister() {
        System.out.println("\n--- Register Staff ---");
        System.out.print("Username: ");
        final String username = this.scanner.nextLine().trim();
        System.out.print("Password: ");
        final String password = this.scanner.nextLine().trim();
        System.out.print("Confirm Password: ");
        final String confirm = this.scanner.nextLine().trim();
        System.out.print("Salary: ");
        final String salaryStr = this.scanner.nextLine().trim();

        if (username.isEmpty() || password.isEmpty() || salaryStr.isEmpty()) {
            System.out.println("Error: Username, password, and salary cannot be empty.");
            return;
        }

        if (!password.equals(confirm)) {
            System.out.println("Error: Passwords do not match.");
            return;
        }

        final double salary;
        try {
            salary = Double.parseDouble(salaryStr);
            if (0 > salary) {
                System.out.println("Error: Salary cannot be negative.");
                return;
            }
        } catch (final NumberFormatException e) {
            System.out.println("Error: Invalid salary format.");
            return;
        }

        if (this.userManager.userExists(username, "STAFF")) {
            System.out.println("Error: Username already exists.");
            return;
        }

        final boolean success = this.userManager.registerStaff(username, password, salary);

        if (success) {
            System.out.println("Success: Staff account created! You can now log in.");
        } else {
            System.out.println("Error: Failed to create account.");
        }
    }

    private void handleAdminRegister() {
        System.out.println("\n--- Register Admin ---");
        System.out.print("Username: ");
        final String username = this.scanner.nextLine().trim();
        System.out.print("Password: ");
        final String password = this.scanner.nextLine().trim();
        System.out.print("Confirm Password: ");
        final String confirm = this.scanner.nextLine().trim();

        if (username.isEmpty() || password.isEmpty()) {
            System.out.println("Error: Username and password cannot be empty.");
            return;
        }

        if (!password.equals(confirm)) {
            System.out.println("Error: Passwords do not match.");
            return;
        }

        if (this.userManager.userExists(username, "ADMIN")) {
            System.out.println("Error: Username already exists.");
            return;
        }

        final boolean success = this.userManager.registerAdmin(username, password);

        if (success) {
            System.out.println("Success: Admin account created! You can now log in.");
        } else {
            System.out.println("Error: Failed to create account.");
        }
    }
}

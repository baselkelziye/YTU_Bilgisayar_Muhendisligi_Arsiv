package ui.cli;

import flightmanagement.Flight;
import servicesandmanagers.FlightManager;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class UpdateFlightFrame {

    private final FlightManager flightManager;

    public UpdateFlightFrame(final FlightManager flightManager) {
        this.flightManager = flightManager;
    }

    public void start(final Scanner scanner) {
        System.out.println("\n--- Update Flight ---");
        System.out.print("Enter Flight Number to Update: ");
        final String flightNum = scanner.nextLine().trim();

        final Flight currentFlight = this.flightManager.getFlight(flightNum);

        if (null == currentFlight) {
            System.out.println("Flight '" + flightNum + "' not found!");
            return;
        }

        System.out.println("Current Flight Information:");
        System.out.println("Flight Number: " + currentFlight.getFlightNum());
        System.out.println("Route: " + currentFlight.getDeparturePlace() + " -> " + currentFlight.getArrivalPlace());
        System.out.println("Date: " + currentFlight.getDate());
        System.out.println("Time: " + currentFlight.getHour());
        System.out.println("Duration: " + currentFlight.getDuration().toHours() + "h " + (currentFlight.getDuration().toMinutes() % 60) + "m");
        System.out.println("Plane: " + currentFlight.getPlane().getPlaneModel());

        try {
            System.out.print("New Date (yyyy-MM-dd) [" + currentFlight.getDate() + "]: ");
            String dateStr = scanner.nextLine().trim();
            if (dateStr.isEmpty()) dateStr = currentFlight.getDate().toString();

            System.out.print("New Time (HH:mm) [" + currentFlight.getHour() + "]: ");
            String timeStr = scanner.nextLine().trim();
            if (timeStr.isEmpty()) timeStr = currentFlight.getHour().toString();

            System.out.print("New Duration Hours [" + currentFlight.getDuration().toHours() + "]: ");
            String durationHoursStr = scanner.nextLine().trim();
            if (durationHoursStr.isEmpty()) durationHoursStr = String.valueOf(currentFlight.getDuration().toHours());

            System.out.print("New Duration Minutes [" + (currentFlight.getDuration().toMinutes() % 60) + "]: ");
            String durationMinsStr = scanner.nextLine().trim();
            if (durationMinsStr.isEmpty()) durationMinsStr = String.valueOf(currentFlight.getDuration().toMinutes() % 60);

            final LocalDate newDate = LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE);
            final LocalTime newTime = LocalTime.parse(timeStr, DateTimeFormatter.ofPattern("HH:mm"));

            final int hours = Integer.parseInt(durationHoursStr);
            final int minutes = Integer.parseInt(durationMinsStr);
            final Duration newDuration = Duration.ofHours(hours).plusMinutes(minutes);

            this.flightManager.updateFlight(currentFlight.getFlightNum(), newDate, newTime, newDuration);

            System.out.println("Success: Flight updated.");

        } catch (final DateTimeParseException e) {
            System.out.println("Error: Invalid date or time format!");
        } catch (final NumberFormatException e) {
            System.out.println("Error: Duration must be numeric!");
        } catch (final Exception e) {
            System.out.println("Error updating flight: " + e.getMessage());
        }
    }
}

package ui.gui;

import flightmanagement.Flight;
import servicesandmanagers.FlightManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class UpdateFlightFrame extends JFrame {
    private JTextField fNum, fDate, fHour, fDurationHours, fDurationMins;
    private final JLabel currentInfoLabel;
    private JButton searchBtn, updateBtn;
    private final FlightManager flightManager;
    private Flight currentFlight;

    
    private static final Color BG_COLOR = new Color(32, 33, 36);
    private static final Color PANEL_COLOR = new Color(48, 50, 56);
    private static final Color TEXT_COLOR = new Color(232, 234, 237);
    private static final Color ACCENT_COLOR = new Color(100, 149, 237);

    public UpdateFlightFrame(FlightManager flightManager) {
        this.flightManager = flightManager;

        setTitle("Update Flight Information");
        setSize(550, 500);
        getContentPane().setBackground(BG_COLOR);
        setLayout(new BorderLayout(10, 10));

        
        JPanel searchPanel = createSearchPanel();
        add(searchPanel, BorderLayout.NORTH);

        
        currentInfoLabel = new JLabel("<html><b>Search for a flight to update</b></html>");
        currentInfoLabel.setForeground(TEXT_COLOR);
        currentInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        currentInfoLabel.setBorder(new EmptyBorder(10, 20, 10, 20));
        currentInfoLabel.setBackground(PANEL_COLOR);
        currentInfoLabel.setOpaque(true);
        add(currentInfoLabel, BorderLayout.CENTER);

        
        JPanel updatePanel = createUpdatePanel();
        add(updatePanel, BorderLayout.SOUTH);

        
        setUpdateFieldsEnabled(false);
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panel.setBackground(PANEL_COLOR);
        panel.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel label = createStyledLabel("Flight Number:");
        fNum = createStyledTextField(15);

        searchBtn = new JButton("Search Flight");
        searchBtn.setBackground(ACCENT_COLOR);
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        searchBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        searchBtn.addActionListener(_ -> searchFlight());

        panel.add(label);
        panel.add(fNum);
        panel.add(searchBtn);

        return panel;
    }

    private JPanel createUpdatePanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(BG_COLOR);
        mainPanel.setBorder(new EmptyBorder(10, 20, 20, 20));

        
        JLabel titleLabel = new JLabel("Update Flight Details");
        titleLabel.setForeground(TEXT_COLOR);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        
        JPanel gridPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        gridPanel.setBackground(BG_COLOR);
        gridPanel.setMaximumSize(new Dimension(500, 150));
        gridPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        
        gridPanel.add(createStyledLabel("New Date (yyyy-MM-dd):"));
        fDate = createStyledTextField(20);
        fDate.setToolTipText("Format: 2026-01-15");
        gridPanel.add(fDate);

        
        gridPanel.add(createStyledLabel("New Time (HH:mm):"));
        fHour = createStyledTextField(20);
        fHour.setToolTipText("Format: 14:30");
        gridPanel.add(fHour);

        
        gridPanel.add(createStyledLabel("New Duration (Hours:Mins):"));
        JPanel durationPanel = new JPanel(new GridLayout(1, 2, 5, 0));
        durationPanel.setBackground(BG_COLOR);
        fDurationHours = createStyledTextField(10);
        fDurationHours.setToolTipText("Hours");
        fDurationMins = createStyledTextField(10);
        fDurationMins.setToolTipText("Minutes");
        durationPanel.add(fDurationHours);
        durationPanel.add(fDurationMins);
        gridPanel.add(durationPanel);

        mainPanel.add(gridPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        
        updateBtn = new JButton("Update Flight");
        updateBtn.setBackground(new Color(76, 175, 80)); 
        updateBtn.setForeground(Color.WHITE);
        updateBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        updateBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        updateBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        updateBtn.setMaximumSize(new Dimension(200, 40));
        updateBtn.addActionListener(_ -> updateFlight());
        mainPanel.add(updateBtn);

        return mainPanel;
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return label;
    }

    private JTextField createStyledTextField(int columns) {
        JTextField field = new JTextField(columns);
        field.setBackground(Color.WHITE);
        field.setForeground(Color.BLACK);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setCaretColor(Color.BLACK);
        return field;
    }

    private void searchFlight() {
        String flightNum = fNum.getText().trim();

        if (flightNum.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a flight number!",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        currentFlight = flightManager.getFlight(flightNum);

        if (currentFlight == null) {
            JOptionPane.showMessageDialog(this,
                    "Flight '" + flightNum + "' not found!",
                    "Flight Not Found",
                    JOptionPane.WARNING_MESSAGE);
            currentInfoLabel.setText("<html><b>Flight not found</b></html>");
            setUpdateFieldsEnabled(false);
        } else {
            
            String info = String.format(
                    "<html><b>Current Flight Information:</b><br>" +
                            "Flight Number: %s<br>" +
                            "Route: %s -> %s<br>" +
                            "Date: %s<br>" +
                            "Time: %s<br>" +
                            "Duration: %d hours %d minutes<br>" +
                            "Plane: %s (%s)</html>",
                    currentFlight.getFlightNum(),
                    currentFlight.getDeparturePlace(),
                    currentFlight.getArrivalPlace(),
                    currentFlight.getDate().toString(),
                    currentFlight.getHour().toString(),
                    currentFlight.getDuration().toHours(),
                    currentFlight.getDuration().toMinutes() % 60,
                    currentFlight.getPlane().getPlaneModel(),
                    currentFlight.getPlane().getPlaneID());
            currentInfoLabel.setText(info);

            
            fDate.setText(currentFlight.getDate().toString());
            fHour.setText(currentFlight.getHour().toString());
            fDurationHours.setText(String.valueOf(currentFlight.getDuration().toHours()));
            fDurationMins.setText(String.valueOf(currentFlight.getDuration().toMinutes() % 60));

            setUpdateFieldsEnabled(true);
        }
    }

    private void updateFlight() {
        if (currentFlight == null) {
            JOptionPane.showMessageDialog(this,
                    "Please search for a flight first!",
                    "No Flight Selected",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            
            String dateStr = fDate.getText().trim();
            String timeStr = fHour.getText().trim();
            String durationHoursStr = fDurationHours.getText().trim();
            String durationMinsStr = fDurationMins.getText().trim();

            if (dateStr.isEmpty() || timeStr.isEmpty() || durationHoursStr.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please fill in all required fields!",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            LocalDate newDate = LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE);
            LocalTime newTime = LocalTime.parse(timeStr, DateTimeFormatter.ofPattern("HH:mm"));

            
            int hours = Integer.parseInt(durationHoursStr);
            int minutes = durationMinsStr.isEmpty() ? 0 : Integer.parseInt(durationMinsStr);
            Duration newDuration = Duration.ofHours(hours).plusMinutes(minutes);

            
            flightManager.updateFlight(currentFlight.getFlightNum(), newDate, newTime, newDuration);

            JOptionPane.showMessageDialog(this,
                    "Flight " + currentFlight.getFlightNum() + " updated successfully!\n" +
                            "New Date: " + newDate + "\n" +
                            "New Time: " + newTime + "\n" +
                            "New Duration: " + hours + "h " + minutes + "m",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            
            this.dispose();

        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                    "Invalid date or time format!\nDate: yyyy-MM-dd (e.g., 2026-01-15)\nTime: HH:mm (e.g., 14:30)",
                    "Format Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Duration must be numeric values!",
                    "Format Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error updating flight: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void setUpdateFieldsEnabled(boolean enabled) {
        fDate.setEnabled(enabled);
        fHour.setEnabled(enabled);
        fDurationHours.setEnabled(enabled);
        fDurationMins.setEnabled(enabled);
        updateBtn.setEnabled(enabled);
    }
}

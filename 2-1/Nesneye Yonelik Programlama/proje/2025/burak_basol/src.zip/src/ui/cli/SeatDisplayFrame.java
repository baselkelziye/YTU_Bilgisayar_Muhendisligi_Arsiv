package ui.cli;

import flightmanagement.Flight;
import flightmanagement.Seat;
import servicesandmanagers.CalculatePrice;
import servicesandmanagers.SeatManager;

import reservationandticketing.Passenger;
import reservationandticketing.Reservation;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.TicketManager;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class SeatDisplayFrame {

    private final Flight flight;
    private final SeatManager seatManager;
    private final ReservationManager reservationManager;
    private final TicketManager ticketManager;
    private final CalculatePrice priceCalculator;
    private final Passenger loggedInUser;

    public SeatDisplayFrame(final Flight flight, final SeatManager seatManager,
                            final ReservationManager reservationManager, final TicketManager ticketManager,
                            final Passenger loggedInUser) {
        this.flight = flight;
        this.seatManager = seatManager;
        this.reservationManager = reservationManager;
        this.ticketManager = ticketManager;
        this.loggedInUser = loggedInUser;
        priceCalculator = new CalculatePrice();
    }

    public void start(Scanner scanner) {
        display();

        System.out.println("\nOptions: [r] Reserve Seat, [Enter] Back");
        System.out.print("Select: ");
        String choice = scanner.nextLine().trim();

        if ("r".equalsIgnoreCase(choice)) {
            reserveSeat(scanner);
        }
    }

    private void display() {
        System.out.println("\n--- Seat Map: Flight " + this.flight.getFlightNum() + " ---");
        System.out.println("Route: " + this.flight.getDeparturePlace() + " -> " + this.flight.getArrivalPlace());
        System.out.println("Aircraft: " + this.flight.getPlane().getPlaneModel());
        
        final int availableSeats = this.seatManager.getAvailableSeats(this.flight);
        System.out.println("Available Seats: " + availableSeats + " / " + this.flight.getPlane().getCapacity());

        final ArrayList<ArrayList<Seat>> seatMatrix = this.flight.getPlane().getSeatMatrix();
        if (null == seatMatrix || seatMatrix.isEmpty()) {
            System.out.println("No seat information.");
            return;
        }

        this.printSeatMap(seatMatrix);
        System.out.println("\nLegend: [ ] Available Economy, { } Available Business, [X] Reserved");
    }

    private void reserveSeat(Scanner scanner) {
        System.out.print("Enter Seat Number (e.g. 1A): ");
        String seatNum = scanner.nextLine().trim().toUpperCase();
        
        Seat selectedSeat = null;
        for (ArrayList<Seat> row : flight.getPlane().getSeatMatrix()) {
            for (Seat s : row) {
                if (s.getSeatNum().equalsIgnoreCase(seatNum)) {
                    selectedSeat = s;
                    break;
                }
            }
        }

        if (selectedSeat == null) {
            System.out.println("Seat not found.");
            return;
        }

        if (selectedSeat.getReserveStatus()) {
            System.out.println("Seat is already reserved.");
            return;
        }

        double price = priceCalculator.calculatePrice(selectedSeat);
        System.out.printf("Seat %s (%s) Price: $%.2f%n", seatNum, selectedSeat.getSeatClass(), price);
        
        System.out.print("Enter Baggage Weight (kg): ");
        double weight = 0;
        try {
            weight = Double.parseDouble(scanner.nextLine().trim());
            if (weight < 0 || weight > 15) {
                System.out.println("Invalid weight (0-15kg).");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid number.");
            return;
        }

        Passenger passenger = loggedInUser;
        if (passenger == null) {
            System.out.println("\n--- Passenger Details ---");
            System.out.print("Name: ");
            String name = scanner.nextLine().trim();
            System.out.print("Passport Number: ");
            String passport = scanner.nextLine().trim();
            System.out.print("Contact Info: ");
            String contact = scanner.nextLine().trim();

            if (name.isEmpty() || passport.isEmpty() || contact.isEmpty()) {
                System.out.println("All fields are required.");
                return;
            }
            passenger = new Passenger(passport, name, "", contact);
        }

        System.out.print("Confirm Reservation? (yes/no): ");
        if ("yes".equalsIgnoreCase(scanner.nextLine().trim())) {
            String date = LocalDate.now().toString();
            try {
                reservationManager.creatReservation(flight, passenger, selectedSeat, date, weight);
                // Find created reservation
                ArrayList<Reservation> allRes = reservationManager.getAllReservations();
                if (!allRes.isEmpty()) {
                    Reservation newRes = allRes.get(allRes.size() - 1);
                    ticketManager.createTicket(newRes);
                    System.out.println("Reservation Successful! PNR: " + newRes.getReservationPNR());
                } else {
                    System.out.println("Reservation created (PNR unknown).");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void printSeatMap(final ArrayList<ArrayList<Seat>> seatMatrix) {
        System.out.println();
        
        
        
        final int rows = seatMatrix.size();
        final int cols = seatMatrix.get(0).size();
        final int gapIndex = cols / 2;

        
        System.out.print("      ");
        final char[] colLetters = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I' }; 
        for (int c = 0; c < cols; c++) {
            if (c == gapIndex) System.out.print("  ");
            System.out.printf(" %-5s", colLetters[c % colLetters.length]);
        }
        System.out.println();

        for (int r = 0; r < rows; r++) {
            System.out.printf("Row %-2d", (r + 1));
            final ArrayList<Seat> rowSeats = seatMatrix.get(r);
            for (int c = 0; c < rowSeats.size(); c++) {
                if (c == gapIndex) System.out.print("  ");
                
                final Seat seat = rowSeats.get(c);
                final String seatStr = seat.getSeatNum();
                
                if (seat.getReserveStatus()) {
                    System.out.print(" [  X  ]");
                } else {
                    if ("BUSINESS".equals(seat.getSeatClass().toString())) {
                        System.out.printf(" {%3s }", seatStr);
                    } else {
                        System.out.printf(" [%3s ]", seatStr);
                    }
                }
            }
            System.out.println();
        }
    }
}

package ui.gui;

import flightmanagement.Plane;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;

import javax.swing.*;
import java.util.List;

public class ReportGenerator extends Thread {
    
    private final MainDashboard parentFrame;
    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final List<Plane> availablePlanes;

    
    public ReportGenerator(MainDashboard parentFrame,
                           FlightManager flightManager,
                           ReservationManager reservationManager,
                           List<Plane> availablePlanes) {
        this.parentFrame = parentFrame;
        this.flightManager = flightManager;
        this.reservationManager = reservationManager;
        this.availablePlanes = availablePlanes;
    }

    @Override
    public void run() {
        
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(parentFrame,
                "Preparing report... (Async Task Started)"));

        try {
            Thread.sleep(3000); 

            int totalFlights = flightManager.getFlights().size();
            int totalReservations = reservationManager.getAllReservations().size();
            double occupancy = totalFlights > 0 ? (totalReservations * 100.0 / (totalFlights * 180)) : 0;

            String report = String.format(
                    "=== STATISTICS REPORT (Generated Asynchronously) ===\n\n" +
                            "Total Flights: %d\n" +
                            "Total Reservations: %d\n" +
                            "Average Occupancy: %.1f%%\n" +
                            "Available Planes: %d",
                    totalFlights, totalReservations, occupancy, availablePlanes.size());

            SwingUtilities.invokeLater(
                    () -> JOptionPane.showMessageDialog(parentFrame, report, "Statistics Report Ready",
                            JOptionPane.INFORMATION_MESSAGE));

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}
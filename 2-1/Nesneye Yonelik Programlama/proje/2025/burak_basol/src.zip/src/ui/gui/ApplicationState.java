package ui.gui;

import flightmanagement.Plane;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.TicketManager;

import java.util.ArrayList;

public class ApplicationState {
    private static ApplicationState instance;
    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final TicketManager ticketManager;
    private final ArrayList<Plane> availablePlanes;
    private boolean initialized = false;

    private ApplicationState() {
        this.flightManager = new FlightManager();
        this.reservationManager = new ReservationManager();
        this.ticketManager = new TicketManager(reservationManager);
        this.availablePlanes = new ArrayList<>();
    }

    public static synchronized ApplicationState getInstance() {
        if (instance == null) {
            instance = new ApplicationState();
        }
        return instance;
    }

    public void initialize() {
        if (!initialized) {
            availablePlanes.add(new Plane("A321", "Airbus", 150));
            availablePlanes.add(new Plane("B737", "Boeing", 150));

            System.out.println("Loading flights from file...");
            flightManager.loadFlightsFromFile(availablePlanes);

            System.out.println("Loading reservations from file...");
            reservationManager.loadReservationsFromFile(flightManager);

            System.out.println("Loading tickets from file...");
            ticketManager.loadTicketsFromFile();

            initialized = true;
            System.out.println("Application state initialized successfully.");
        }
    }

    public FlightManager getFlightManager() {
        return flightManager;
    }

    public ReservationManager getReservationManager() {
        return reservationManager;
    }

    public TicketManager getTicketManager() {
        return ticketManager;
    }

    public ArrayList<Plane> getAvailablePlanes() {
        return availablePlanes;
    }

    public boolean isInitialized() {
        return initialized;
    }
}

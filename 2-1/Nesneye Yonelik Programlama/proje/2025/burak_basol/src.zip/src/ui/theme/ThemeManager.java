package ui.theme;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ThemeManager {

    public enum Theme {
        DARK, LIGHT
    }

    private static ThemeManager instance;
    private Theme currentTheme;
    private final List<ThemeListener> listeners;

    private ThemeManager() {
        this.currentTheme = Theme.DARK; 
        this.listeners = new ArrayList<>();
    }

    public static ThemeManager getInstance() {
        if (instance == null) {
            instance = new ThemeManager();
        }
        return instance;
    }

    public void toggleTheme() {
        setTheme(currentTheme == Theme.DARK ? Theme.LIGHT : Theme.DARK);
    }

    public void setTheme(Theme theme) {
        this.currentTheme = theme;
        notifyListeners();
    }

    public Theme getCurrentTheme() {
        return currentTheme;
    }

    public boolean isDark() {
        return currentTheme == Theme.DARK;
    }

    
    public Color getBackgroundColor() {
        
        
        return isDark() ? StyleConstants.DARK_BG : new Color(235, 235, 230);
    }

    public Color getPanelColor() {
        
        
        return isDark() ? new Color(42, 45, 50) : new Color(245, 245, 245);
    }

    public Color getContentAreaColor() {
        
        
        return isDark() ? new Color(42, 45, 50) : new Color(200, 240, 250);
    }

    public Color getTextColor() {
        return isDark() ? StyleConstants.DARK_TEXT : StyleConstants.LIGHT_TEXT;
    }

    public Color getInverseTextColor() {
        return isDark() ? StyleConstants.LIGHT_TEXT : StyleConstants.DARK_TEXT;
    }

    public Color getAccentColor() {
        return isDark() ? StyleConstants.DARK_ACCENT : StyleConstants.LIGHT_ACCENT;
    }

    public Color getSecondaryTextColor() {
        return isDark() ? new Color(160, 160, 160) : new Color(100, 100, 100);
    }

    public Color getInputBackgroundColor() {
        return isDark() ? new Color(45, 48, 52) : new Color(255, 255, 255);
    }

    public Color getInputTextColor() {
        return isDark() ? new Color(220, 220, 220) : new Color(33, 33, 33);
    }

    public Color getBorderColor() {
        return isDark() ? new Color(80, 80, 80) : new Color(200, 200, 200);
    }

    
    public void addListener(ThemeListener listener) {
        listeners.add(listener);
    }

    public void removeListener(ThemeListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners() {
        for (ThemeListener listener : listeners) {
            listener.onThemeChanged(currentTheme);
        }
    }

    public interface ThemeListener {
        void onThemeChanged(Theme newTheme);
    }
}

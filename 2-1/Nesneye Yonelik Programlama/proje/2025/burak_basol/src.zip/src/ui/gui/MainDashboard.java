package ui.gui;

import flightmanagement.Flight;
import flightmanagement.Plane;
import flightmanagement.Seat;
import reservationandticketing.Passenger;
import reservationandticketing.Reservation;
import reservationandticketing.Staff;
import reservationandticketing.User;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.UserManager;
import servicesandmanagers.TicketManager;
import reservationandticketing.Ticket;
import ui.gui.components.ModernButton;
import ui.gui.components.ModernPanel;
import ui.theme.StyleConstants;
import ui.theme.ThemeManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;

public class MainDashboard extends JFrame implements ThemeManager.ThemeListener {

    private final String userRole;
    private final User loggedInUser;
    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final UserManager userManager;
    private final TicketManager ticketManager;
    private final ArrayList<Plane> availablePlanes;
    private final Runnable logoutCallback;

    private JPanel mainContent;
    private JPanel header;
    private JLabel titleLabel;
    private JLabel roleLabel;
    private JTextArea infoArea;

    public MainDashboard(String role, User loggedInUser, Runnable logoutCallback) {
        this.userRole = role;
        this.loggedInUser = loggedInUser;
        this.logoutCallback = logoutCallback;

        ApplicationState appState = ApplicationState.getInstance();
        appState.initialize();

        this.flightManager = appState.getFlightManager();
        this.reservationManager = appState.getReservationManager();
        this.ticketManager = appState.getTicketManager();
        this.availablePlanes = appState.getAvailablePlanes();
        this.userManager = new UserManager();

        ThemeManager.getInstance().addListener(this);

        setTitle("Airline Management - Dashboard (" + role + ")");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        initializeUI();
        updateTheme();
    }

    private void initializeUI() {
        add(createHeader(), BorderLayout.NORTH);

        mainContent = new JPanel(new GridLayout(1, 2, 20, 20));
        mainContent.setBorder(new EmptyBorder(30, 30, 30, 30));

        JScrollPane modulesScrollPane = new JScrollPane(createModulesPanel());
        modulesScrollPane.setBorder(null);
        modulesScrollPane.setOpaque(false);
        modulesScrollPane.getViewport().setOpaque(false);
        modulesScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        
        mainContent.add(modulesScrollPane);
        mainContent.add(createStatsPanel());

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createHeader() {
        header = new JPanel(new BorderLayout());
        header.setPreferredSize(new Dimension(getWidth(), 80));
        header.setBorder(new EmptyBorder(15, 25, 15, 25));

        titleLabel = new JLabel("AIRLINE SYSTEM DASHBOARD");
        titleLabel.setFont(StyleConstants.HEADER_FONT);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        rightPanel.setOpaque(false);

        roleLabel = new JLabel("Logged in as: " + userRole.toUpperCase());
        roleLabel.setFont(StyleConstants.BOLD_FONT);

        ModernButton themeBtn = new ModernButton("Switch Theme");
        themeBtn.setBackground(new Color(100, 100, 100));
        themeBtn.addActionListener(e -> ThemeManager.getInstance().toggleTheme());

        JButton logoutButton = new ModernButton("Logout");
        logoutButton.setBackground(new Color(178, 34, 34));
        logoutButton.addActionListener(e -> handleLogout());

        rightPanel.add(roleLabel);
        rightPanel.add(themeBtn);
        rightPanel.add(logoutButton);

        header.add(titleLabel, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JPanel createModulesPanel() {
        ModernPanel panel = new ModernPanel(true);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel label = new JLabel("Operations");
        label.setFont(StyleConstants.SUBHEADER_FONT);
        panel.add(label);
        panel.add(Box.createRigidArea(new Dimension(0, 25)));

        if (userRole.equalsIgnoreCase("STAFF") || userRole.equalsIgnoreCase("Staff / Admin")) {
            addStaffButtons(panel);
        } else if (userRole.equalsIgnoreCase("ADMIN")) {
            addAdminButtons(panel);
        } else {
            addPassengerButtons(panel);
        }

        return panel;
    }

    private void addStaffButtons(JPanel panel) {
        JButton addFlightBtn = new ModernButton("Add Flight");
        addFlightBtn.addActionListener(e -> {
            new FlightManagerFrame(flightManager, availablePlanes).setVisible(true);
        });
        panel.add(addFlightBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton editFlightBtn = new ModernButton("Edit Flight");
        editFlightBtn.addActionListener(e -> showUpdateFlightDialog());
        panel.add(editFlightBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton deleteFlightBtn = new ModernButton("Delete Flight", Color.RED);
        deleteFlightBtn.addActionListener(e -> showDeleteFlightDialog());
        panel.add(deleteFlightBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton editReservationBtn = new ModernButton("Edit Reservation");
        editReservationBtn.addActionListener(e -> showEditReservationDialog());
        panel.add(editReservationBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton deleteReservationBtn = new ModernButton("Delete Reservation", Color.RED);
        deleteReservationBtn.addActionListener(e -> showDeleteReservationDialog());
        panel.add(deleteReservationBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton viewReservationsBtn = new ModernButton("View All Reservations");
        viewReservationsBtn.setBackground(new Color(76, 175, 80));
        viewReservationsBtn.addActionListener(e -> showAllReservations());
        panel.add(viewReservationsBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel passengerLabel = new JLabel("PASSENGER MANAGEMENT");
        passengerLabel.setFont(StyleConstants.BOLD_FONT);
        passengerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        passengerLabel.setMaximumSize(new Dimension(400, 30));
        panel.add(passengerLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton viewPassengersBtn = new ModernButton("View All Passengers");
        viewPassengersBtn.setBackground(new Color(76, 175, 80));
        viewPassengersBtn.addActionListener(e -> showAllPassengers());
        panel.add(viewPassengersBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton editPassengerBtn = new ModernButton("Edit Passenger");
        editPassengerBtn.setBackground(new Color(255, 152, 0));
        editPassengerBtn.addActionListener(e -> showEditPassengerDialog());
        panel.add(editPassengerBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton deletePassengerBtn = new ModernButton("Delete Passenger", Color.RED);
        deletePassengerBtn.addActionListener(e -> showDeletePassengerDialog());
        panel.add(deletePassengerBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JLabel threadingLabel = new JLabel("MULTITHREADING");
        threadingLabel.setFont(StyleConstants.BOLD_FONT);
        threadingLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        threadingLabel.setMaximumSize(new Dimension(400, 30));
        panel.add(threadingLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton concurrencyBtn = new ModernButton("Concurrency Demo (Seats)");
        concurrencyBtn.setBackground(new Color(153, 50, 204));
        concurrencyBtn.addActionListener(e -> new ConcurrencyDemoFrame().setVisible(true));
        panel.add(concurrencyBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton reportBtn = new ModernButton("Generate Statistics Report");
        reportBtn.addActionListener(e -> generateReport());
        panel.add(reportBtn);
    }

    private void addAdminButtons(JPanel panel) {

        addStaffButtons(panel);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JLabel adminLabel = new JLabel("ADMIN FEATURES");
        adminLabel.setForeground(new Color(255, 215, 0));
        adminLabel.setFont(StyleConstants.BOLD_FONT);
        adminLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        adminLabel.setMaximumSize(new Dimension(400, 30));
        panel.add(adminLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton viewStaffBtn = new ModernButton("View All Staff");
        viewStaffBtn.setBackground(new Color(76, 175, 80));
        viewStaffBtn.addActionListener(e -> showAllStaff());
        panel.add(viewStaffBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton addStaffBtn = new ModernButton("Add Staff Member");
        addStaffBtn.setBackground(new Color(33, 150, 243));
        addStaffBtn.addActionListener(e -> showAddStaffDialog());
        panel.add(addStaffBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton editStaffBtn = new ModernButton("Edit Staff Member");
        editStaffBtn.setBackground(new Color(255, 152, 0));
        editStaffBtn.addActionListener(e -> showEditStaffDialog());
        panel.add(editStaffBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton deleteStaffBtn = new ModernButton("Delete Staff Member", Color.RED);
        deleteStaffBtn.addActionListener(e -> showDeleteStaffDialog());
        panel.add(deleteStaffBtn);
    }

    private void addPassengerButtons(JPanel panel) {

        JButton searchFlightsBtn = new ModernButton("Search Flights");
        searchFlightsBtn.addActionListener(e -> {
            Passenger p = (loggedInUser instanceof Passenger) ? (Passenger) loggedInUser : null;
            new FlightSearchFrame(flightManager, reservationManager, ticketManager, p).setVisible(true);
        });
        panel.add(searchFlightsBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton reservationBtn = new ModernButton("Make Reservation");
        reservationBtn.addActionListener(e -> {
            try {
                ReservationSimulation reservationWindow;
                if (loggedInUser instanceof Passenger) {
                    reservationWindow = new ReservationSimulation((Passenger) loggedInUser);
                } else {
                    reservationWindow = new ReservationSimulation();
                }
                reservationWindow.setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(MainDashboard.this,
                        "Error opening reservation system: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(reservationBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton editResBtn = new ModernButton("Edit Reservation");
        editResBtn.setBackground(new Color(255, 152, 0));
        editResBtn.addActionListener(e -> showPassengerEditReservationDialog());
        panel.add(editResBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton cancelResBtn = new ModernButton("Cancel Reservation", Color.RED);
        cancelResBtn.addActionListener(e -> showPassengerCancelReservationDialog());
        panel.add(cancelResBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton concurrencyBtn = new ModernButton("Concurrency Demo (Seats)");
        concurrencyBtn.setBackground(new Color(153, 50, 204));
        concurrencyBtn.addActionListener(e -> new ConcurrencyDemoFrame().setVisible(true));
        panel.add(concurrencyBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton reviewTicketBtn = new ModernButton("Review Ticket");
        reviewTicketBtn.setBackground(new Color(60, 179, 113)); 
        reviewTicketBtn.addActionListener(e -> showReviewTicketDialog());
        panel.add(reviewTicketBtn);
    }

    private JPanel createStatsPanel() {
        ModernPanel panel = new ModernPanel(true);
        panel.setLayout(new BorderLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        infoArea = new JTextArea(buildStatsText());
        infoArea.setEditable(false);
        infoArea.setFont(new Font("Consolas", Font.PLAIN, 14));

        JLabel title = new JLabel("System Overview");
        title.setFont(StyleConstants.SUBHEADER_FONT);

        panel.add(title, BorderLayout.NORTH);
        panel.add(new JScrollPane(infoArea), BorderLayout.CENTER);

        return panel;
    }

    private String buildStatsText() {
        String stats = "=== SYSTEM STATISTICS ===\n\n" +
                "Total Flights: " + flightManager.getFlights().size() + "\n" +
                "Total Reservations: " + reservationManager.getAllReservations().size() + "\n" +
                "Available Planes: " + availablePlanes.size() + "\n\n" +
                "=== RECENT ACTIVITY ===\n" +
                "System operational and ready.\n";
        return stats;
    }

    private void showUpdateFlightDialog() {
        UpdateFlightFrame updateFrame = new UpdateFlightFrame(flightManager);
        updateFrame.setVisible(true);
        updateFrame.setLocationRelativeTo(this);
    }

    private void showDeleteFlightDialog() {
        String flightNumber = JOptionPane.showInputDialog(this,
                "Enter Flight Number to Delete:",
                "Delete Flight",
                JOptionPane.WARNING_MESSAGE);

        if (flightNumber != null && !flightNumber.trim().isEmpty()) {
            Flight flight = flightManager.getFlight(flightNumber);

            if (flight == null) {
                JOptionPane.showMessageDialog(this,
                        "Flight '" + flightNumber + "' not found!",
                        "Flight Not Found",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            String flightDetails = String.format(
                    "Flight Number: %s\nRoute: %s → %s\nDate: %s\nTime: %s",
                    flight.getFlightNum(),
                    flight.getDeparturePlace(),
                    flight.getArrivalPlace(),
                    flight.getDate().toString(),
                    flight.getHour().toString());

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this flight?\n\n" + flightDetails,
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                flightManager.deleteFlight(flightNumber);
                JOptionPane.showMessageDialog(this,
                        "Flight '" + flightNumber + "' has been deleted successfully!",
                        "Deletion Successful",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void showEditReservationDialog() {
        String pnr = JOptionPane.showInputDialog(this,
                "Enter Reservation PNR to Change Seat:",
                "Change Seat",
                JOptionPane.QUESTION_MESSAGE);

        if (pnr != null && !pnr.trim().isEmpty()) {
            Reservation reservation = reservationManager.searchReservation(pnr);

            if (reservation == null) {
                JOptionPane.showMessageDialog(this,
                        "Reservation with PNR '" + pnr + "' not found!",
                        "Reservation Not Found",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            Seat currentSeat = reservation.getSeat();
            Flight flight = reservation.getFlight();

            String currentDetails = String.format(
                    "Current Reservation Details:\n" +
                            "PNR: %s\n" +
                            "Flight: %s\n" +
                            "Passenger: %s\n" +
                            "Current Seat: %s (%s)\n" +
                            "Date: %s",
                    reservation.getReservationPNR(),
                    flight.getFlightNum(),
                    reservation.getPassenger().getName(),
                    currentSeat.getSeatNum(),
                    currentSeat.getSeatClass(),
                    reservation.getDateOfReservation());

            int proceed = JOptionPane.showConfirmDialog(this,
                    currentDetails + "\n\nDo you want to change the seat for this reservation?",
                    "Confirm Edit",
                    JOptionPane.YES_NO_OPTION);

            if (proceed != JOptionPane.YES_OPTION)
                return;

            while (true) {

                SeatSelectionDialog dialog = new SeatSelectionDialog(this, flight, currentSeat);
                dialog.setVisible(true);

                Seat newSeat = dialog.getSelectedSeat();

                if (newSeat == null) {
                    return;
                }

                if (newSeat.getReserveStatus()) {
                    JOptionPane.showMessageDialog(this,
                            "Error: Selected seat " + newSeat.getSeatNum() + " is already reserved!",
                            "Seat Unavailable",
                            JOptionPane.ERROR_MESSAGE);
                    continue;
                }

                if (newSeat.getSeatClass() != currentSeat.getSeatClass()) {
                    servicesandmanagers.CalculatePrice pricer = new servicesandmanagers.CalculatePrice();
                    double oldPrice = pricer.calculatePrice(currentSeat);
                    double newPrice = pricer.calculatePrice(newSeat);
                    double diff = newPrice - oldPrice;

                    String msg;
                    if (diff > 0) {
                        msg = String.format(
                                "Class Upgrade: %s -> %s\n\n" +
                                        "The customer must pay an additional: $%.2f\n\n" +
                                        "Do you agree to continue?",
                                currentSeat.getSeatClass(), newSeat.getSeatClass(), diff);
                    } else {
                        msg = String.format(
                                "Class Downgrade: %s -> %s\n\n" +
                                        "Value to refund to customer: $%.2f\n\n" +
                                        "Do you agree to continue?",
                                currentSeat.getSeatClass(), newSeat.getSeatClass(), Math.abs(diff));
                    }

                    int agree = JOptionPane.showConfirmDialog(this, msg, "Price Difference Warning",
                            JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                    if (agree != JOptionPane.YES_OPTION) {
                        continue;
                    }
                }

                currentSeat.setReserveStatus(false);
                newSeat.setReserveStatus(true);
                reservationManager.updateReservation(
                        pnr,
                        flight,
                        reservation.getPassenger(),
                        newSeat, reservation.getDateOfReservation());

                JOptionPane.showMessageDialog(this,
                        "Seat changed successfully!\nOld Seat: " + currentSeat.getSeatNum() + "\nNew Seat: "
                                + newSeat.getSeatNum(),
                        "Update Successful",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
            }
        }
    }

    private void showDeleteReservationDialog() {
        String pnr = JOptionPane.showInputDialog(this,
                "Enter Reservation PNR to Delete:",
                "Delete Reservation",
                JOptionPane.WARNING_MESSAGE);

        if (pnr != null && !pnr.trim().isEmpty()) {
            Reservation reservation = reservationManager.searchReservation(pnr);

            if (reservation == null) {
                JOptionPane.showMessageDialog(this,
                        "Reservation with PNR '" + pnr + "' not found!",
                        "Reservation Not Found",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            String reservationDetails = String.format(
                    "PNR: %s\nFlight: %s\nPassenger: %s\nSeat: %s",
                    reservation.getReservationPNR(),
                    reservation.getFlight().getFlightNum(),
                    reservation.getPassenger().getName(),
                    reservation.getSeat().getSeatNum());

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this reservation?\n\n" + reservationDetails,
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                reservationManager.cancelReservation(reservation);
                JOptionPane.showMessageDialog(this,
                        "Reservation deleted successfully!",
                        "Deletion Successful",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void showAllReservations() {
        ArrayList<Reservation> reservations = reservationManager.getAllReservations();

        if (reservations.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No reservations found in the system.",
                    "No Reservations",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String[] columnNames = { "PNR", "Flight", "Passenger", "Seat", "Date" };
        Object[][] data = new Object[reservations.size()][5];

        for (int i = 0; i < reservations.size(); i++) {
            Reservation r = reservations.get(i);
            data[i][0] = r.getReservationPNR();
            data[i][1] = r.getFlight().getFlightNum();
            data[i][2] = r.getPassenger().getName();
            data[i][3] = r.getSeat().getSeatNum();
            data[i][4] = r.getDateOfReservation();
        }

        JTable table = new JTable(data, columnNames);
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(700, 400));

        JOptionPane.showMessageDialog(this,
                scrollPane,
                "All Reservations (" + reservations.size() + " total)",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void showPassengerCancelReservationDialog() {
        String pnr = JOptionPane.showInputDialog(this, "Enter PNR to Cancel:");
        if (pnr != null && !pnr.trim().isEmpty()) {
            Reservation res = reservationManager.searchReservation(pnr);
            if (res != null) {

                if (loggedInUser instanceof Passenger p) {
                    if (!res.getPassenger().getPassengerID().equals(p.getPassengerID())) {
                        JOptionPane.showMessageDialog(this, "You can only cancel your own reservations.",
                                "Access Denied", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                reservationManager.cancelReservation(res);
                JOptionPane.showMessageDialog(this, "Reservation cancelled successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Reservation not found.");
            }
        }
    }

    private void showPassengerEditReservationDialog() {
        String pnr = JOptionPane.showInputDialog(this, "Enter PNR to Edit:");
        if (pnr != null && !pnr.trim().isEmpty()) {
            Reservation res = reservationManager.searchReservation(pnr);
            if (res != null) {

                if (loggedInUser instanceof Passenger p) {
                    if (!res.getPassenger().getPassengerID().equals(p.getPassengerID())) {
                        JOptionPane.showMessageDialog(this, "You can only edit your own reservations.", "Access Denied",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                Seat currentSeat = res.getSeat();
                Flight flight = res.getFlight();

                SeatSelectionDialog dialog = new SeatSelectionDialog(this, flight, currentSeat);
                dialog.setVisible(true);
                Seat newSeat = dialog.getSelectedSeat();

                if (newSeat != null) {
                    if (newSeat.getReserveStatus()) {
                        JOptionPane.showMessageDialog(this, "Seat already reserved.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (newSeat.getSeatClass() != currentSeat.getSeatClass()) {
                        servicesandmanagers.CalculatePrice pricer = new servicesandmanagers.CalculatePrice();
                        double oldPrice = pricer.calculatePrice(currentSeat);
                        double newPrice = pricer.calculatePrice(newSeat);
                        double diff = newPrice - oldPrice;

                        String msg;
                        if (diff > 0) {
                            msg = String.format(
                                    "Class Upgrade: %s -> %s\n\n" +
                                            "You must pay an additional: $%.2f\n\n" +
                                            "Do you agree to continue?",
                                    currentSeat.getSeatClass(), newSeat.getSeatClass(), diff);
                        } else {
                            msg = String.format(
                                    "Class Downgrade: %s -> %s\n\n" +
                                            "Refund amount: $%.2f\n\n" +
                                            "Do you agree to continue?",
                                    currentSeat.getSeatClass(), newSeat.getSeatClass(), Math.abs(diff));
                        }

                        int agree = JOptionPane.showConfirmDialog(this, msg, "Price Difference Warning",
                                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                        if (agree != JOptionPane.YES_OPTION) {
                            return;
                        }
                    }

                    currentSeat.setReserveStatus(false);
                    newSeat.setReserveStatus(true);
                    reservationManager.updateReservation(pnr, flight, res.getPassenger(), newSeat,
                            res.getDateOfReservation());
                    JOptionPane.showMessageDialog(this, "Seat updated to " + newSeat.getSeatNum());
                }
            } else {
                JOptionPane.showMessageDialog(this, "Reservation not found.");
            }
        }
    }

    private void generateReport() {

        ReportGenerator reportTask = new ReportGenerator(
                this,
                this.flightManager,
                this.reservationManager,
                this.availablePlanes);
        reportTask.start();
    }

    private void showAllStaff() {
        Staff.showAllStaff(this, userManager.getAllUsers());
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Logout Confirmation",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            ThemeManager.getInstance().removeListener(this);
            if (logoutCallback != null) {
                logoutCallback.run();
            }
        }
    }

    private void showAddStaffDialog() {
        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JPasswordField confirmField = new JPasswordField(15);
        JTextField salaryField = new JTextField(15);

        Object[] message = {
                "Username:", usernameField,
                "Password:", passwordField,
                "Confirm Password:", confirmField,
                "Salary ($):", salaryField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add Staff Member",
                JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirm = new String(confirmField.getPassword());
            String salaryStr = salaryField.getText().trim();

            if (username.isEmpty() || password.isEmpty() || salaryStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!password.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double salary;
            try {
                salary = Double.parseDouble(salaryStr);
                if (salary < 0) {
                    JOptionPane.showMessageDialog(this, "Salary cannot be negative.",
                            "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid salary format. Please enter a valid number.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (userManager.userExists(username, "STAFF")) {
                JOptionPane.showMessageDialog(this, "Staff username already exists. Please choose another.",
                        "Username Exists", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = userManager.registerStaff(username, password, salary);

            if (success) {
                JOptionPane.showMessageDialog(this,
                        String.format("Staff member '%s' added successfully!\nSalary: $%.2f", username, salary),
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add staff member. Please try again.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showEditStaffDialog() {
        String username = JOptionPane.showInputDialog(this,
                "Enter Staff Username to Edit:",
                "Edit Staff Member",
                JOptionPane.QUESTION_MESSAGE);

        if (username != null && !username.trim().isEmpty()) {
            username = username.trim();

            if (!userManager.userExists(username, "STAFF")) {
                JOptionPane.showMessageDialog(this,
                        "Staff member '" + username + "' not found!",
                        "Not Found",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            JPasswordField newPasswordField = new JPasswordField(15);
            JPasswordField confirmField = new JPasswordField(15);
            JTextField salaryField = new JTextField(15);

            Object[] message = {
                    "Staff Username: " + username,
                    "New Password:", newPasswordField,
                    "Confirm Password:", confirmField,
                    "New Salary ($):", salaryField
            };

            int option = JOptionPane.showConfirmDialog(this, message,
                    "Edit Staff Member", JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                String newPassword = new String(newPasswordField.getPassword());
                String confirm = new String(confirmField.getPassword());
                String salaryStr = salaryField.getText().trim();

                if (newPassword.isEmpty() || salaryStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Password and salary cannot be empty.",
                            "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!newPassword.equals(confirm)) {
                    JOptionPane.showMessageDialog(this, "Passwords do not match.",
                            "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                double salary;
                try {
                    salary = Double.parseDouble(salaryStr);
                    if (salary < 0) {
                        JOptionPane.showMessageDialog(this, "Salary cannot be negative.",
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid salary format. Please enter a valid number.",
                            "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                userManager.removeUser(username, "STAFF");
                boolean success = userManager.registerStaff(username, newPassword, salary);

                if (success) {
                    JOptionPane.showMessageDialog(this,
                            String.format("Staff member '%s' updated successfully!\nNew Salary: $%.2f", username,
                                    salary),
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update staff member.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void showDeleteStaffDialog() {
        String username = JOptionPane.showInputDialog(this,
                "Enter Staff Username to Delete:",
                "Delete Staff Member",
                JOptionPane.WARNING_MESSAGE);

        if (username != null && !username.trim().isEmpty()) {
            username = username.trim();

            if (!userManager.userExists(username, "STAFF")) {
                JOptionPane.showMessageDialog(this,
                        "Staff member '" + username + "' not found!",
                        "Not Found",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete staff member '" + username + "'?\n" +
                            "This action cannot be undone.",
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {

                userManager.removeUser(username, "STAFF");
                userManager.saveAllUsers();

                JOptionPane.showMessageDialog(this,
                        "Staff member deleted successfully!",
                        "Deletion Successful",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void showAllPassengers() {
        Passenger.showAllPassengers(this, userManager.getAllUsers());
    }

    private void showEditPassengerDialog() {
        String username = JOptionPane.showInputDialog(this, "Enter Passenger Username to Edit:");

        if (username != null && !username.trim().isEmpty()) {

            if (!userManager.userExists(username, "PASSENGER")) {
                JOptionPane.showMessageDialog(this, "Passenger not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            java.util.Map<String, User> allUsers = userManager.getAllUsers();
            User user = allUsers.get(username + "_PASSENGER");

            if (user instanceof Passenger p) {
                JPasswordField newPasswordField = new JPasswordField(15);
                JPasswordField confirmField = new JPasswordField(15);
                JTextField idField = new JTextField(p.getPassengerID(), 15);
                JTextField nameField = new JTextField(p.getName(), 15);
                JTextField surnameField = new JTextField(p.getSurname(), 15);
                JTextField contactField = new JTextField(p.getContactInfo(), 15);

                Object[] message = {
                        "Passenger: " + username,
                        "New Password (leave empty to keep current):", newPasswordField,
                        "Confirm Password:", confirmField,
                        "Passenger ID:", idField,
                        "Name:", nameField,
                        "Surname:", surnameField,
                        "Contact Info:", contactField
                };

                int option = JOptionPane.showConfirmDialog(this, message, "Edit Passenger",
                        JOptionPane.OK_CANCEL_OPTION);

                if (option == JOptionPane.OK_OPTION) {
                    String newPass = new String(newPasswordField.getPassword());
                    String confirm = new String(confirmField.getPassword());
                    String newId = idField.getText().trim();
                    String newName = nameField.getText().trim();
                    String newSurname = surnameField.getText().trim();
                    String newContact = contactField.getText().trim();

                    if (!newPass.isEmpty() && !newPass.equals(confirm)) {
                        JOptionPane.showMessageDialog(this, "Passwords do not match.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    p.editPassenger(newPass, newId, newName, newSurname, newContact);
                    userManager.saveAllUsers(); 
                    JOptionPane.showMessageDialog(this, "Passenger updated successfully.");
                }
            }
        }
    }

    private void showDeletePassengerDialog() {
        String username = JOptionPane.showInputDialog(this, "Enter Passenger Username to Delete:");
        if (username != null && !username.trim().isEmpty()) {
            if (userManager.userExists(username, "PASSENGER")) {

                User user = userManager.authenticate(username, getPasswordForUser(username, "PASSENGER"), "PASSENGER");
                if (user instanceof Passenger p) {

                    reservationManager.cancelReservationsForPassenger(p.getPassengerID());
                }

                userManager.removeUser(username, "PASSENGER");
                userManager.saveAllUsers();
                JOptionPane.showMessageDialog(this, "Passenger and all associated reservations deleted.");
            } else {
                JOptionPane.showMessageDialog(this, "Passenger not found.");
            }
        }
    }

    private String getPasswordForUser(String username, String role) {

        if (userManager != null) {
            java.util.Map<String, User> allUsers = userManager.getAllUsers();
            String key = username + "_" + role.toUpperCase();
            User u = allUsers.get(key);
            if (u != null) {
                return u.getPassword();
            }
        }
        return "";
    }

    @Override
    public void onThemeChanged(ThemeManager.Theme newTheme) {
        updateTheme();
    }

    private void updateTheme() {
        ThemeManager tm = ThemeManager.getInstance();

        getContentPane().setBackground(tm.getBackgroundColor());
        if (header != null)
            header.setBackground(tm.getPanelColor());
        if (titleLabel != null)
            titleLabel.setForeground(tm.getTextColor());
        if (roleLabel != null)
            roleLabel.setForeground(tm.getAccentColor());

        if (mainContent != null) {
            mainContent.setBackground(tm.getBackgroundColor());
            processContainerLabels(mainContent);
        }

        if (infoArea != null) {
            infoArea.setBackground(tm.getInputBackgroundColor());
            infoArea.setForeground(tm.getTextColor());
        }

        SwingUtilities.updateComponentTreeUI(this);
    }

    private void showReviewTicketDialog() {
        if (!(loggedInUser instanceof Passenger)) {
            JOptionPane.showMessageDialog(this, "Only passengers can review tickets.", "Access Denied",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Passenger passenger = (Passenger) loggedInUser;
        String currentPassengerID = passenger.getPassengerID();
        System.out.println("[DEBUG] Current Passenger ID: " + currentPassengerID);

        ArrayList<Ticket> allTickets = ticketManager.getTickets();
        System.out.println("[DEBUG] Total tickets in memory: " + allTickets.size());

        ArrayList<Ticket> passengerTickets = new ArrayList<>();

        for (Ticket ticket : allTickets) {
            String ticketPassengerID = ticket.getReservation().getPassenger().getPassengerID();
            System.out.println(
                    "[DEBUG] Checking ticket " + ticket.getTicketID() + " with Passenger ID: " + ticketPassengerID);

            if (ticketPassengerID != null && ticketPassengerID.equals(currentPassengerID)) {
                passengerTickets.add(ticket);
            }
        }

        System.out.println("[DEBUG] Found " + passengerTickets.size() + " tickets for this passenger.");

        if (passengerTickets.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tickets found for your account.", "No Tickets",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        new TicketDisplayDialog(this, passengerTickets).setVisible(true);
    }

    private void processContainerLabels(Container container) {
        ThemeManager tm = ThemeManager.getInstance();
        for (Component c : container.getComponents()) {
            if (c instanceof JLabel) {
                c.setForeground(tm.getTextColor());
            } else if (c instanceof JTextArea) {
                c.setBackground(tm.getInputBackgroundColor());
                c.setForeground(tm.getTextColor());
            } else if (c instanceof JPanel) {
                if (c instanceof ModernPanel) {

                } else if (c.isOpaque()) {
                    c.setBackground(tm.getBackgroundColor());

                }
                processContainerLabels((Container) c);
            } else if (c instanceof JScrollPane) {
                processContainerLabels((Container) c);
            } else if (c instanceof JViewport) {
                processContainerLabels((Container) c);
            }
        }
    }
}
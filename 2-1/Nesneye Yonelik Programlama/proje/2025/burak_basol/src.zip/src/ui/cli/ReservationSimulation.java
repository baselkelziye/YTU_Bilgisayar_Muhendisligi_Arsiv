package ui.cli;

import flightmanagement.Flight;
import flightmanagement.Plane;
import flightmanagement.Seat;
import reservationandticketing.Passenger;
import reservationandticketing.Reservation;
import servicesandmanagers.CalculatePrice;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.SeatManager;
import servicesandmanagers.TicketManager;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class ReservationSimulation {

    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final SeatManager seatManager;
    private final TicketManager ticketManager;
    private final CalculatePrice priceCalculator;
    private final Passenger loggedInPassenger;
    private final Set<Seat> selectedSeats;

    public ReservationSimulation() {
        this(null);
    }

    public ReservationSimulation(final Passenger loggedInPassenger) {
        this.loggedInPassenger = loggedInPassenger;
        final ApplicationState appState = ApplicationState.getInstance();
        appState.initialize();

        flightManager = appState.getFlightManager();
        reservationManager = appState.getReservationManager();
        ticketManager = appState.getTicketManager();
        seatManager = new SeatManager();
        priceCalculator = new CalculatePrice();
        selectedSeats = new HashSet<>();
    }

    public void start(final Scanner scanner) {
        System.out.println("\n--- Reservation System ---");

        
        final ArrayList<Flight> flights = this.flightManager.getFlights();
        if (flights.isEmpty()) {
            System.out.println("No flights available.");
            return;
        }

        System.out.println("Available Flights:");
        for (int i = 0; i < flights.size(); i++) {
            final Flight f = flights.get(i);
            System.out.printf("%d. %s (%s -> %s) %s %s%n",
                    (i + 1), f.getFlightNum(), f.getDeparturePlace(), f.getArrivalPlace(), f.getDate(), f.getHour());
        }

        System.out.print("Select Flight Number (index): ");
        final String choiceStr = scanner.nextLine().trim();
        final int choice;
        try {
            choice = Integer.parseInt(choiceStr);
        } catch (final NumberFormatException e) {
            System.out.println("Invalid input.");
            return;
        }

        if (1 > choice || choice > flights.size()) {
            System.out.println("Invalid selection.");
            return;
        }

        final Flight selectedFlight = flights.get(choice - 1);
        this.handleSeatSelection(selectedFlight, scanner);
    }

    private void handleSeatSelection(final Flight flight, final Scanner scanner) {
        final Plane plane = flight.getPlane();
        
        
         final ArrayList<ArrayList<Seat>> seatMatrix = plane.getSeatMatrix();
        boolean needsInitialization = seatMatrix.isEmpty();
        if (!needsInitialization && !seatMatrix.isEmpty()) {
            if (seatMatrix.get(0).isEmpty()) needsInitialization = true;
        }
        if (needsInitialization) {
             final int rows = plane.getCapacity() / 6;
            plane.setSeatMatrix(this.seatManager.createSeatArrangement(rows, 6));
        }

        boolean selecting = true;
        while (selecting) {
            new SeatDisplayFrame(flight, this.seatManager, reservationManager, ticketManager, loggedInPassenger).start(scanner);
            System.out.println("Selected Seats: " + this.formatSelectedSeats());
            System.out.println("Options: [add <SeatNum>] (e.g., add 1A), [clear], [done], [cancel]");
            System.out.print("Action: ");
            final String input = scanner.nextLine().trim();

            if ("done".equalsIgnoreCase(input)) {
                if (!this.selectedSeats.isEmpty()) {
                    this.proceedToReservation(flight, scanner);
                    selecting = false;
                } else {
                    System.out.println("No seats selected.");
                }
            } else if ("cancel".equalsIgnoreCase(input)) {
                selecting = false;
            } else if ("clear".equalsIgnoreCase(input)) {
                this.selectedSeats.clear();
                System.out.println("Selection cleared.");
            } else if (input.toLowerCase().startsWith("add ")) {
                final String seatNum = input.substring(4).trim();
                final Seat seat = this.findSeat(plane, seatNum);
                if (null != seat) {
                    if (seat.getReserveStatus()) {
                        System.out.println("Seat " + seatNum + " is already reserved.");
                    } else if (this.selectedSeats.contains(seat)) {
                        System.out.println("Seat " + seatNum + " already selected.");
                    } else {
                        this.selectedSeats.add(seat);
                        System.out.println("Added " + seatNum);
                    }
                } else {
                    System.out.println("Seat not found.");
                }
            } else {
                System.out.println("Invalid command.");
            }
        }
    }

    private String formatSelectedSeats() {
        final StringBuilder sb = new StringBuilder();
        double total = 0;
        for (final Seat s : this.selectedSeats) {
            sb.append(s.getSeatNum()).append(" ");
            total += this.priceCalculator.calculatePrice(s);
        }
        sb.append("| Total: $").append(String.format("%.2f", total));
        return sb.toString();
    }

    private Seat findSeat(final Plane plane, final String seatNum) {
        for (final ArrayList<Seat> row : plane.getSeatMatrix()) {
            for (final Seat s : row) {
                if (s.getSeatNum().equalsIgnoreCase(seatNum)) return s;
            }
        }
        return null;
    }

    private void proceedToReservation(final Flight flight, final Scanner scanner) {
        System.out.println("\n--- Confirm Reservation ---");
        System.out.print("Enter baggage weight (kg): ");
        double weight = 0;
        try {
            weight = Double.parseDouble(scanner.nextLine().trim());
            if(0 > weight || 15 < weight) {
                 System.out.println("Invalid weight (0-15kg).");
                 return;
            }
        } catch(final Exception e) {
            System.out.println("Invalid number.");
            return;
        }

        Passenger passenger = this.loggedInPassenger;
        if (null == passenger) {
            System.out.println("Enter Passenger Details:");
            System.out.print("Name: ");
            final String name = scanner.nextLine().trim();
            System.out.print("Passport Number: ");
            final String passport = scanner.nextLine().trim();
            System.out.print("Contact: ");
            final String contact = scanner.nextLine().trim();
            
            if(name.isEmpty() || passport.isEmpty()) {
                System.out.println("Invalid details.");
                return;
            }
            passenger = new Passenger(passport, name, "", contact);
        }

        final String date = LocalDate.now().toString();
        for (final Seat seat : this.selectedSeats) {
            this.reservationManager.creatReservation(flight, passenger, seat, date, weight);
             final Reservation lastReservation = this.reservationManager.searchReservation(
                     this.reservationManager.getAllReservations()
                                .get(this.reservationManager.getAllReservations().size() - 1)
                                .getReservationPNR());
            this.ticketManager.createTicket(lastReservation);
             System.out.println("Reserved: " + seat.getSeatNum() + " PNR: " + lastReservation.getReservationPNR());
        }
        System.out.println("Reservation Complete.");
    }
}

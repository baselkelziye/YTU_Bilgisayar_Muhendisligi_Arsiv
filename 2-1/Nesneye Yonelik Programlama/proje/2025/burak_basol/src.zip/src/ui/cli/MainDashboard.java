package ui.cli;

import flightmanagement.Flight;
import flightmanagement.Plane;
import flightmanagement.Seat;
import reservationandticketing.Passenger;
import reservationandticketing.Reservation;
import reservationandticketing.Staff;
import reservationandticketing.User;
import servicesandmanagers.CalculatePrice;
import servicesandmanagers.FlightManager;
import servicesandmanagers.ReservationManager;
import servicesandmanagers.TicketManager;
import servicesandmanagers.UserManager;
import reservationandticketing.Ticket;

import java.util.ArrayList;
import java.util.Scanner;

public class MainDashboard {

    private final String userRole;
    private final User loggedInUser;
    private final FlightManager flightManager;
    private final ReservationManager reservationManager;
    private final UserManager userManager;
    private final TicketManager ticketManager;
    private final ArrayList<Plane> availablePlanes;
    private final Scanner scanner;

    public MainDashboard(final String role, final User loggedInUser, final Scanner scanner) {
        userRole = role;
        this.loggedInUser = loggedInUser;
        this.scanner = scanner;

        final ApplicationState appState = ApplicationState.getInstance();
        appState.initialize();

        flightManager = appState.getFlightManager();
        reservationManager = appState.getReservationManager();
        ticketManager = appState.getTicketManager();
        availablePlanes = appState.getAvailablePlanes();
        userManager = new UserManager();
    }

    public void start() {
        boolean running = true;
        while (running) {
            System.out.println("\n=== MAIN DASHBOARD (" + this.userRole + ") ===");
            System.out.println("Logged in as: " + this.loggedInUser.getUsername());

            if ("STAFF".equalsIgnoreCase(userRole) || "Staff / Admin".equalsIgnoreCase(userRole)) {
                running = this.showStaffMenu();
            } else if ("ADMIN".equalsIgnoreCase(userRole)) {
                running = this.showAdminMenu();
            } else {
                running = this.showPassengerMenu();
            }
        }
    }

    private boolean showStaffMenu() {
        System.out.println("\n--- Operations ---");
        System.out.println("1. Add Flight");
        System.out.println("2. Edit Flight");
        System.out.println("3. Delete Flight");
        System.out.println("4. View All Reservations");
        System.out.println("5. Edit Reservation");
        System.out.println("6. Delete Reservation");
        System.out.println("7. View All Passengers");
        System.out.println("8. Edit Passenger");
        System.out.println("9. Delete Passenger");
        System.out.println("10. Generate Statistics Report");
        System.out.println("11. Logout");
        System.out.print("Select an option: ");

        final String choice = this.scanner.nextLine();
        switch (choice) {
            case "1":
                new FlightManagerFrame(this.flightManager, this.availablePlanes).start(this.scanner);
                break;
            case "2":
                new UpdateFlightFrame(this.flightManager).start(this.scanner);
                break;
            case "3":
                this.deleteFlight();
                break;
            case "4":
                this.showAllReservations();
                break;
            case "5":
                this.editReservation();
                break;
            case "6":
                this.deleteReservation();
                break;
            case "7":
                this.showAllPassengers();
                break;
            case "8":
                this.adminEditPassenger();
                break;
            case "9":
                this.adminDeletePassenger();
                break;
            case "10":
                new ReportGenerator(this.flightManager, this.reservationManager, this.availablePlanes).generate();
                break;
            case "11":
                return false;
            default:
                System.out.println("Invalid option.");
        }
        return true;
    }

    private boolean showAdminMenu() {

        System.out.println("\n--- Admin Operations ---");
        System.out.println("1. Manage Flights & Reservations (Staff Menu)");
        System.out.println("2. View All Staff");
        System.out.println("3. Add Staff Member");
        System.out.println("4. Edit Staff Member");
        System.out.println("5. Delete Staff Member");
        System.out.println("6. Logout");
        System.out.print("Select an option: ");

        final String choice = this.scanner.nextLine();
        switch (choice) {
            case "1":

                boolean staffRunning = true;
                while (staffRunning) {
                    staffRunning = this.showStaffMenu();

                    if (!staffRunning)
                        return false;
                }
                break;
            case "2":
                this.showAllStaff();
                break;
            case "3":
                this.addStaff();
                break;
            case "4":
                this.editStaff();
                break;
            case "5":
                this.deleteStaff();
                break;
            case "6":
                return false;
            default:
                System.out.println("Invalid option.");
        }
        return true;
    }

    private boolean showPassengerMenu() {
        System.out.println("\n--- Passenger Operations ---");
        System.out.println("1. Search Flights");
        System.out.println("2. Make Reservation");
        System.out.println("3. Edit Reservation");
        System.out.println("4. Cancel Reservation");
        System.out.println("5. View My Tickets");
        System.out.println("6. Logout");
        System.out.print("Select an option: ");

        final String choice = this.scanner.nextLine();
        switch (choice) {
            case "1":
                new FlightSearchFrame(this.flightManager, reservationManager, ticketManager, (Passenger) loggedInUser).start(this.scanner);
                break;
            case "2":
                try {
                    final ReservationSimulation sim;
                    if (this.loggedInUser instanceof Passenger) {
                        sim = new ReservationSimulation((Passenger) this.loggedInUser);
                    } else {
                        sim = new ReservationSimulation();
                    }
                    sim.start(this.scanner);
                } catch (final Exception e) {
                    System.out.println("Error opening reservation system: " + e.getMessage());
                }
                break;
            case "3":
                this.passengerEditReservation();
                break;
            case "4":
                this.passengerCancelReservation();
                break;
            case "5":
                this.viewMyTickets();
                break;
            case "6":
                return false;
            default:
                System.out.println("Invalid option.");
        }
        return true;
    }

    private void deleteFlight() {
        System.out.print("Enter Flight Number to Delete: ");
        final String flightNum = this.scanner.nextLine().trim();
        if (flightNum.isEmpty())
            return;

        final Flight flight = this.flightManager.getFlight(flightNum);
        if (null == flight) {
            System.out.println("Flight not found!");
            return;
        }

        System.out.println(flight);
        System.out.print("Are you sure you want to delete this flight? (yes/no): ");
        if ("yes".equalsIgnoreCase(scanner.nextLine().trim())) {
            this.flightManager.deleteFlight(flightNum);
            System.out.println("Flight deleted.");
        }
    }

    private void showAllReservations() {
        final ArrayList<Reservation> reservations = this.reservationManager.getAllReservations();
        if (reservations.isEmpty()) {
            System.out.println("No reservations found.");
            return;
        }
        System.out.println("--- All Reservations ---");
        System.out.printf("%-10s %-10s %-20s %-10s %-20s%n", "PNR", "Flight", "Passenger", "Seat", "Date");
        for (final Reservation r : reservations) {
            System.out.printf("%-10s %-10s %-20s %-10s %-20s%n",
                    r.getReservationPNR(),
                    r.getFlight().getFlightNum(),
                    r.getPassenger().getName(),
                    r.getSeat().getSeatNum(),
                    r.getDateOfReservation());
        }
    }

    private void editReservation() {
        System.out.print("Enter Reservation PNR to Change Seat: ");
        final String pnr = this.scanner.nextLine().trim();
        if (pnr.isEmpty())
            return;

        final Reservation reservation = this.reservationManager.searchReservation(pnr);
        if (null == reservation) {
            System.out.println("Reservation not found!");
            return;
        }

        final Seat currentSeat = reservation.getSeat();
        final Flight flight = reservation.getFlight();
        System.out.println("Current Seat: " + currentSeat.getSeatNum() + " (" + currentSeat.getSeatClass() + ")");

        final SeatSelectionDialog seatDialog = new SeatSelectionDialog(flight, currentSeat);
        seatDialog.start(this.scanner);
        final Seat newSeat = seatDialog.getSelectedSeat();

        if (null == newSeat)
            return;

        if (newSeat.getReserveStatus()) {
            System.out.println("Error: Seat " + newSeat.getSeatNum() + " is already reserved!");
            return;
        }

        if (newSeat.getSeatClass() != currentSeat.getSeatClass()) {
            final CalculatePrice pricer = new CalculatePrice();
            final double diff = pricer.calculatePrice(newSeat) - pricer.calculatePrice(currentSeat);
            System.out.printf("Price difference: $%.2f. Continue? (yes/no): ", diff);
            if (!"yes".equalsIgnoreCase(scanner.nextLine().trim()))
                return;
        }

        currentSeat.setReserveStatus(false);
        newSeat.setReserveStatus(true);
        this.reservationManager.updateReservation(pnr, flight, reservation.getPassenger(), newSeat,
                reservation.getDateOfReservation());
        System.out.println("Seat updated successfully to " + newSeat.getSeatNum());
    }

    private void deleteReservation() {
        System.out.print("Enter Reservation PNR to Delete: ");
        final String pnr = this.scanner.nextLine().trim();
        final Reservation reservation = this.reservationManager.searchReservation(pnr);

        if (null != reservation) {
            System.out.print("Confirm deletion? (yes/no): ");
            if ("yes".equalsIgnoreCase(scanner.nextLine().trim())) {
                this.reservationManager.cancelReservation(reservation);
                System.out.println("Reservation deleted.");
            }
        } else {
            System.out.println("Reservation not found.");
        }
    }

    private void showAllPassengers() {

        System.out.println("--- All Passengers ---");

        for (final User u : this.userManager.getAllUsers().values()) {
            if (u instanceof Passenger) {
                System.out.println(u.getUsername() + " - " + ((Passenger) u).getName());
            }
        }
    }

    private void showAllStaff() {
        System.out.println("--- All Staff ---");
        for (final User u : this.userManager.getAllUsers().values()) {
            if (u instanceof Staff) {
                System.out.println(u.getUsername());
            }
        }
    }

    private void addStaff() {
        System.out.println("--- Add Staff ---");
        System.out.print("Username: ");
        final String u = this.scanner.nextLine().trim();
        System.out.print("Password: ");
        final String p = this.scanner.nextLine().trim();
        System.out.print("Salary: ");
        final String s = this.scanner.nextLine().trim();

        try {
            final double sal = Double.parseDouble(s);
            if (this.userManager.userExists(u, "STAFF")) {
                System.out.println("User exists.");
                return;
            }
            if (this.userManager.registerStaff(u, p, sal)) {
                System.out.println("Staff added.");
            } else {
                System.out.println("Failed.");
            }
        } catch (final Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private void editStaff() {
        System.out.print("Enter Username to Edit: ");
        final String u = this.scanner.nextLine().trim();
        if (!this.userManager.userExists(u, "STAFF")) {
            System.out.println("Not found.");
            return;
        }

        System.out.print("New Password: ");
        final String p = this.scanner.nextLine().trim();
        System.out.print("New Salary: ");
        final String s = this.scanner.nextLine().trim();
        try {
            final double sal = Double.parseDouble(s);
            this.userManager.removeUser(u, "STAFF");
            this.userManager.registerStaff(u, p, sal);
            System.out.println("Updated.");
        } catch (final Exception e) {
            System.out.println("Error.");
        }
    }

    private void deleteStaff() {
        System.out.print("Enter Username to Delete: ");
        final String u = this.scanner.nextLine().trim();
        if (this.userManager.userExists(u, "STAFF")) {
            this.userManager.removeUser(u, "STAFF");
            this.userManager.saveAllUsers();
            System.out.println("Deleted.");
        } else {
            System.out.println("Not found.");
        }
    }

    private void passengerEditReservation() {

        System.out.print("Enter Reservation PNR to Change Seat: ");
        final String pnr = this.scanner.nextLine().trim();
        if (pnr.isEmpty())
            return;

        final Reservation reservation = this.reservationManager.searchReservation(pnr);
        if (null == reservation) {
            System.out.println("Reservation not found!");
            return;
        }

        if (this.loggedInUser instanceof Passenger p) {
            if (!reservation.getPassenger().getPassengerID().equals(p.getPassengerID())) {
                System.out.println("Access Denied: You can only edit your own reservations.");
                return;
            }
        }

        final Seat currentSeat = reservation.getSeat();
        final Flight flight = reservation.getFlight();

        final SeatSelectionDialog seatDialog = new SeatSelectionDialog(flight, currentSeat);
        seatDialog.start(this.scanner);
        final Seat newSeat = seatDialog.getSelectedSeat();

        if (null != newSeat && !newSeat.getReserveStatus()) {

            
            
            CalculatePrice pricer = new CalculatePrice();
            double currentPrice = pricer.calculatePrice(currentSeat);
            double newPrice = pricer.calculatePrice(newSeat);

            if (newSeat.getSeatClass() != currentSeat.getSeatClass()) {
                double diff = newPrice - currentPrice;
                System.out.printf("Price difference: %.2f. Continue? (yes/no): ", diff);
                if (!"yes".equalsIgnoreCase(scanner.nextLine().trim()))
                    return;
            }

            currentSeat.setReserveStatus(false);
            newSeat.setReserveStatus(true);
            this.reservationManager.updateReservation(pnr, flight, reservation.getPassenger(), newSeat,
                    reservation.getDateOfReservation());
            System.out.println("Seat updated.");
        } else if (null != newSeat) {
            System.out.println("Seat occupied.");
        }
    }

    private void passengerCancelReservation() {
        System.out.print("Enter PNR to Cancel: ");
        final String pnr = this.scanner.nextLine().trim();
        final Reservation res = this.reservationManager.searchReservation(pnr);
        if (null != res) {
            if (this.loggedInUser instanceof Passenger p) {
                if (!res.getPassenger().getPassengerID().equals(p.getPassengerID())) {
                    System.out.println("Access Denied.");
                    return;
                }
            }
            this.reservationManager.cancelReservation(res);
            System.out.println("Cancelled.");
        } else {
            System.out.println("Not found.");
        }
    }

    private void adminEditPassenger() {
        System.out.print("Enter Passenger Username to Edit: ");
        final String username = this.scanner.nextLine().trim();
        if (username.isEmpty())
            return;

        

        Passenger passengerToEdit = null;
        for (User u : this.userManager.getAllUsers().values()) {
            if (u instanceof Passenger && u.getUsername().equals(username)) {
                passengerToEdit = (Passenger) u;
                break;
            }
        }

        if (passengerToEdit == null) {
            System.out.println("Passenger not found.");
            return;
        }

        System.out.println("Editing Passenger: " + passengerToEdit.getName() + " " + passengerToEdit.getSurname());
        System.out.println("Leave fields blank to keep current.");

        System.out.print("New Password (" + passengerToEdit.getPassword() + "): ");
        String pw = scanner.nextLine().trim();
        if (pw.isEmpty())
            pw = passengerToEdit.getPassword();

        System.out.print("New ID (" + passengerToEdit.getPassengerID() + "): ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty())
            id = passengerToEdit.getPassengerID();

        System.out.print("New Name (" + passengerToEdit.getName() + "): ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty())
            name = passengerToEdit.getName();

        System.out.print("New Surname (" + passengerToEdit.getSurname() + "): ");
        String surname = scanner.nextLine().trim();
        if (surname.isEmpty())
            surname = passengerToEdit.getSurname();

        System.out.print("New Contact (" + passengerToEdit.getContactInfo() + "): ");
        String contact = scanner.nextLine().trim();
        if (contact.isEmpty())
            contact = passengerToEdit.getContactInfo();

        passengerToEdit.editPassenger(pw, id, name, surname, contact);
        this.userManager.saveAllUsers();
        System.out.println("Passenger updated.");
    }

    private void adminDeletePassenger() {
        System.out.print("Enter Passenger Username to Delete: ");
        final String username = this.scanner.nextLine().trim();
        if (username.isEmpty())
            return;

        Passenger passengerToDelete = null;
        for (User u : this.userManager.getAllUsers().values()) {
            if (u instanceof Passenger && u.getUsername().equals(username)) {
                passengerToDelete = (Passenger) u;
                break;
            }
        }

        if (passengerToDelete == null) {
            System.out.println("Passenger not found.");
            return;
        }

        System.out.print("Are you sure you want to delete " + username + " and all their reservations? (yes/no): ");
        if (!"yes".equalsIgnoreCase(scanner.nextLine().trim()))
            return;

        this.reservationManager.cancelReservationsForPassenger(passengerToDelete.getPassengerID());
        this.userManager.removeUser(username, "PASSENGER");
        System.out.println("Passenger and associated data deleted.");
    }

    private void viewMyTickets() {
        if (!(this.loggedInUser instanceof Passenger)) {
            System.out.println("Only passengers can view tickets.");
            return;
        }
        Passenger p = (Passenger) this.loggedInUser;
        ArrayList<Ticket> allTickets = this.ticketManager.getTickets();
        ArrayList<Ticket> myTickets = new ArrayList<>();

        
        
        for (Ticket t : allTickets) {
            if (t.getReservation() != null
                    && t.getReservation().getPassenger() != null
                    && t.getReservation().getPassenger().getPassengerID().equals(p.getPassengerID())) {
                myTickets.add(t);
            }
        }

        new TicketDisplayDialog().display(myTickets);
        System.out.println("Press Enter to continue...");
        scanner.nextLine();
    }
}

package ui.gui;

import servicesandmanagers.ReservationManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ConcurrencyDemoFrame extends JFrame {

    private JPanel seatPanel;
    private JLabel[] seatLabels;
    private JLabel statusLabel;
    private JCheckBox syncCheckbox;
    private JButton startButton;
    private JTextArea logArea;

    private static final int TOTAL_SEATS = 180;
    private static final int PASSENGER_COUNT = 90;
    private final ReservationManager reservationManager;

    private static final Color OCCUPIED_COLOR = new Color(244, 67, 54); 
    private static final Color EMPTY_COLOR = new Color(76, 175, 80); 
    private static final Color BG_COLOR = new Color(32, 33, 36);
    private static final Color PANEL_COLOR = new Color(48, 50, 56);
    private static final Color TEXT_COLOR = new Color(232, 234, 237);

    public ConcurrencyDemoFrame() {
        this.reservationManager = new ReservationManager();
        this.reservationManager.initSimulationSeats(TOTAL_SEATS);

        setTitle("Scenario 1: Concurrent Seat Reservation");
        setSize(1000, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        setLayout(new BorderLayout(10, 10));

        initComponents();
    }

    private void initComponents() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PANEL_COLOR);
        header.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel title = new JLabel("Simultaneous Seat Reservation Simulation");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(TEXT_COLOR);
        header.add(title, BorderLayout.WEST);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        controls.setBackground(PANEL_COLOR);

        syncCheckbox = new JCheckBox("Enable Synchronization");
        syncCheckbox.setBackground(PANEL_COLOR);
        syncCheckbox.setForeground(TEXT_COLOR);
        syncCheckbox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        syncCheckbox.setToolTipText("If checked, threads will respect locks. If unchecked, race conditions may occur.");

        startButton = new JButton("Run Simulation");
        startButton.setBackground(new Color(33, 150, 243));
        startButton.setForeground(Color.WHITE);
        startButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        startButton.addActionListener(e -> startSimulation());

        controls.add(syncCheckbox);
        controls.add(startButton);
        header.add(controls, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        seatPanel = new JPanel(new GridLayout(15, 12, 5, 5)); 
        seatPanel.setBackground(BG_COLOR);
        seatPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        seatLabels = new JLabel[TOTAL_SEATS];
        for (int i = 0; i < TOTAL_SEATS; i++) {
            JLabel seat = new JLabel(String.valueOf(i + 1), SwingConstants.CENTER);
            seat.setOpaque(true);
            seat.setBackground(EMPTY_COLOR);
            seat.setForeground(Color.WHITE);
            seat.setFont(new Font("Segoe UI", Font.BOLD, 10));
            seatLabels[i] = seat;
            seatPanel.add(seat);
        }
        add(new JScrollPane(seatPanel), BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(PANEL_COLOR);
        footer.setBorder(new EmptyBorder(10, 20, 10, 20));

        statusLabel = new JLabel("Ready. Total Seats: 180 | Passengers: 90");
        statusLabel.setForeground(TEXT_COLOR);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        footer.add(statusLabel, BorderLayout.WEST);

        logArea = new JTextArea(5, 50);
        logArea.setEditable(false);
        logArea.setBackground(new Color(60, 64, 66));
        logArea.setForeground(Color.LIGHT_GRAY);
        footer.add(new JScrollPane(logArea), BorderLayout.SOUTH);

        add(footer, BorderLayout.SOUTH);
    }

    private void resetSimulation() {
        reservationManager.initSimulationSeats(TOTAL_SEATS);
        for (int i = 0; i < TOTAL_SEATS; i++) {
            seatLabels[i].setBackground(EMPTY_COLOR);
        }
        log("Simulation reset.");
        statusLabel.setText("Running...");
        startButton.setEnabled(false);
    }

    private void startSimulation() {
        resetSimulation();
        boolean useSync = syncCheckbox.isSelected();
        log("Starting simulation with Sync: " + useSync);

        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < PASSENGER_COUNT; i++) {
            Thread t = new Thread(new PassengerTask(i, useSync));
            threads.add(t);
        }

        long startTime = System.currentTimeMillis();
        for (Thread t : threads) {
            t.start();
        }

        new Thread(() -> {
            for (Thread t : threads) {
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            long endTime = System.currentTimeMillis();

            SwingUtilities.invokeLater(() -> {
                int actualOccupied = reservationManager.countOccupiedSimulationSeats();

                statusLabel.setText("Finished in " + (endTime - startTime) + "ms. Occupied Seats: " + actualOccupied
                        + " (Expected: 90)");
                log("Simulation finished. Total Occupied: " + actualOccupied);
                if (actualOccupied != PASSENGER_COUNT && !useSync) {
                    log("Race condition observed! Some passengers overwrote others' bookings.");
                }
                startButton.setEnabled(true);
            });
        }).start();
    }

    private void log(String msg) {
        SwingUtilities.invokeLater(() -> {
            logArea.append(msg + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    private class PassengerTask implements Runnable {
        private final int id;
        private final boolean useSync;
        private final Random random = new Random();

        public PassengerTask(int id, boolean useSync) {
            this.id = id;
            this.useSync = useSync;
        }

        @Override
        public void run() {
            try {
                Thread.sleep(random.nextInt(50));

                boolean booked = false;
                while (!booked) {
                    int seatIndex = random.nextInt(TOTAL_SEATS);
                    boolean success;

                    if (useSync) {
                        success = reservationManager.reserveSeatSynchronized(seatIndex);
                    } else {
                        success = reservationManager.reserveSeatUnsynchronized(seatIndex);
                    }

                    if (success) {
                        booked = true;
                        SwingUtilities.invokeLater(() -> {
                            seatLabels[seatIndex].setBackground(OCCUPIED_COLOR);
                        });
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

package ui.cli;

import flightmanagement.Plane;
import servicesandmanagers.FlightManager;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class FlightManagerFrame {

    private final FlightManager flightManager;
    private final ArrayList<Plane> availablePlanes;

    public FlightManagerFrame(final FlightManager flightManager, final ArrayList<Plane> availablePlanes) {
        this.flightManager = flightManager;
        this.availablePlanes = availablePlanes;
    }

    public void start(final Scanner scanner) {
        System.out.println("\n--- Add Flight ---");

        try {
            System.out.print("Flight Number: ");
            final String flightNum = scanner.nextLine().trim();
            System.out.print("Departure: ");
            final String departure = scanner.nextLine().trim();
            System.out.print("Arrival: ");
            final String arrival = scanner.nextLine().trim();
            System.out.print("Date (yyyy-MM-dd): ");
            final String dateStr = scanner.nextLine().trim();
            System.out.print("Time (HH:mm): ");
            final String timeStr = scanner.nextLine().trim();
            System.out.print("Duration Hours: ");
            final String durationHoursStr = scanner.nextLine().trim();
            System.out.print("Duration Minutes: ");
            final String durationMinsStr = scanner.nextLine().trim();

            if (flightNum.isEmpty() || departure.isEmpty() || arrival.isEmpty() ||
                    dateStr.isEmpty() || timeStr.isEmpty() || durationHoursStr.isEmpty()) {
                System.out.println("Error: Please fill in all required fields!");
                return;
            }

            final LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE);
            final LocalTime time = LocalTime.parse(timeStr, DateTimeFormatter.ofPattern("HH:mm"));

            final int hours = Integer.parseInt(durationHoursStr);
            final int minutes = durationMinsStr.isEmpty() ? 0 : Integer.parseInt(durationMinsStr);
            final Duration duration = Duration.ofHours(hours).plusMinutes(minutes);

            System.out.println("Select Plane:");
            for (int i = 0; i < this.availablePlanes.size(); i++) {
                final Plane p = this.availablePlanes.get(i);
                System.out.println((i + 1) + ". " + p.getPlaneModel() + " (" + p.getPlaneID() + ", Cap: " + p.getCapacity() + ")");
            }
            System.out.print("Enter choice: ");
            final int planeIndex = Integer.parseInt(scanner.nextLine().trim()) - 1;

            if (0 > planeIndex || planeIndex >= this.availablePlanes.size()) {
                System.out.println("Error: Invalid plane selection.");
                return;
            }

            final Plane selectedPlane = this.availablePlanes.get(planeIndex);

            this.flightManager.createFlight(flightNum, selectedPlane, departure, arrival, date, time, duration);

            System.out.println("Success: Flight " + flightNum + " added successfully!");
            System.out.println("From: " + departure + " To: " + arrival);

        } catch (final DateTimeParseException e) {
            System.out.println("Error: Invalid date or time format! Date: yyyy-MM-dd, Time: HH:mm");
        } catch (final NumberFormatException e) {
            System.out.println("Error: Duration/Selection must be numeric values!");
        } catch (final Exception e) {
            System.out.println("Error adding flight: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

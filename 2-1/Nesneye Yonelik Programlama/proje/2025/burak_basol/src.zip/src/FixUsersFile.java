import java.io.*;
import java.nio.file.*;


public class FixUsersFile {
    public static void main(String[] args) {
        String filename = "users.txt";

        try {
            
            String content = new String(Files.readAllBytes(Paths.get(filename)));

            
            System.out.println("ORIGINAL CONTENT:");
            System.out.println(content);
            System.out.println("\n" + repeatString("=", 50) + "\n");

            
            String[] lines = content.split("\n");
            StringBuilder fixed = new StringBuilder();

            for (String line : lines) {
                line = line.trim();
                if (line.startsWith("STAFF;")) {
                    
                    String[] parts = line.split(";");
                    if (parts.length >= 4) {
                        parts[3] = parts[3].replace(',', '.');
                        line = String.join(";", parts);
                    }
                }
                if (!line.isEmpty()) {
                    fixed.append(line).append("\n");
                }
            }

            
            System.out.println("FIXED CONTENT:");
            System.out.println(fixed.toString());
            System.out.println("\n" + repeatString("=", 50) + "\n");

            
            Files.write(Paths.get(filename), fixed.toString().getBytes());
            System.out.println("✓ File fixed successfully!");

        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }


    private static String repeatString(String str, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(str);
        }
        return sb.toString();
    }
}

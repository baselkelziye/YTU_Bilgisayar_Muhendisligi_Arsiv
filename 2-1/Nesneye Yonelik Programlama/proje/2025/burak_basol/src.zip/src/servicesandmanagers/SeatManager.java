package servicesandmanagers;

import flightmanagement.Flight;
import flightmanagement.Seat;
import flightmanagement.SeatEnum;

import java.util.ArrayList;

public class SeatManager {
    public ArrayList<ArrayList<Seat>> createSeatArrangement(int rows, int cols) {
        ArrayList<ArrayList<Seat>> seatMatrix = new ArrayList<>();
        char[] colLetters = { 'A', 'B', 'C', 'D', 'E', 'F' };

        for (int r = 0; r < rows; r++) {
            ArrayList<Seat> rowList = new ArrayList<>();
            for (int c = 0; c < cols; c++) {
                String seatNum = (r + 1) + "" + colLetters[c];

                SeatEnum seatEnum;
                if (r < 5) {
                    seatEnum = SeatEnum.BUSINESS;
                } else {
                    seatEnum = SeatEnum.ECONOMY;
                }

                rowList.add(new Seat(seatNum, seatEnum));
            }
            seatMatrix.add(rowList);
        }
        return seatMatrix;
    }

    public int getAvailableSeats(Flight flight) {
        ArrayList<ArrayList<Seat>> seatMatrix = flight.getPlane().getSeatMatrix();
        int count = 0;

        for (ArrayList<Seat> rowList : seatMatrix) {
            for (Seat seat : rowList) {
                if (!seat.getReserveStatus()) {
                    count++;
                }
            }
        }
        return count;
    }

    public void reserveSeat(Flight flight, String seatNum) throws Exception {
        boolean found = false;
        for (ArrayList<Seat> rowList : flight.getPlane().getSeatMatrix()) {
            for (Seat seat : rowList) {
                if (seat.getSeatNum().equalsIgnoreCase(seatNum)) {
                    seat.setReserveStatus(true);
                    found = true;
                    return;
                }
            }
        }

        if (!found) {
            throw new SeatNotFoundException("Seat not found");
        }
    }
}

package servicesandmanagers;

import flightmanagement.Seat;

public class CalculatePrice {
    public double calculatePrice(Seat seat) {
        double totalPrice = seat.getPrice();

        totalPrice *= 1.18;

        return totalPrice;
    }
}

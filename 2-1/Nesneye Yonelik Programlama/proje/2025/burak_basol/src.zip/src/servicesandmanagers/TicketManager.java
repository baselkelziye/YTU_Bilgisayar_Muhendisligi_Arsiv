package servicesandmanagers;

import reservationandticketing.Reservation;
import reservationandticketing.Ticket;

import java.io.*;
import java.util.ArrayList;
import java.util.UUID;

public class TicketManager {
    private ArrayList<Ticket> tickets;
    private static final String TICKETS_FILE = "tickets.txt";
    private final ReservationManager reservationManager;

    public TicketManager(ReservationManager reservationManager) {
        this.tickets = new ArrayList<>();
        this.reservationManager = reservationManager;
    }

    public void createTicket(Reservation reservation) {
        String ticketID = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        double price = new CalculatePrice().calculatePrice(reservation.getSeat());
        double baggageAllowance = reservation.getBaggage().getWeight();

        Ticket ticket = new Ticket(ticketID, price, reservation, baggageAllowance);
        tickets.add(ticket);
        saveTicketsToFile();
        System.out.println("Ticket created: " + ticketID);
    }

    public ArrayList<Ticket> getTickets() {
        return tickets;
    }

    public void saveTicketsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TICKETS_FILE))) {
            for (Ticket ticket : tickets) {
                
                String line = String.format("%s;%s;%.2f;%.2f",
                        ticket.getTicketID(),
                        ticket.getReservation().getReservationPNR(),
                        ticket.getPrice(),
                        ticket.getBaggageAllowance());
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Tickets saved to " + TICKETS_FILE);
        } catch (IOException e) {
            System.err.println("Error saving tickets: " + e.getMessage());
        }
    }

    public void loadTicketsFromFile() {
        File file = new File(TICKETS_FILE);
        System.out.println("[DEBUG] Attempting to load tickets from: " + file.getAbsolutePath());
        if (!file.exists()) {
            System.out.println("[DEBUG] tickets.txt not found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("[DEBUG] Reading line: " + line);
                String[] parts = line.split(";");
                if (parts.length == 4) {
                    String ticketID = parts[0].trim();
                    String pnr = parts[1].trim();
                    double price = Double.parseDouble(parts[2].replace(",", "."));
                    double baggage = Double.parseDouble(parts[3].replace(",", "."));

                    Reservation reservation = reservationManager.searchReservation(pnr);
                    if (reservation != null) {
                        Ticket ticket = new Ticket(ticketID, price, reservation, baggage);
                        tickets.add(ticket);
                        System.out.println("[DEBUG] Ticket loaded: " + ticketID + " for PNR: " + pnr);
                    } else {
                        System.err.println("[DEBUG] Warning: Reservation " + pnr + " not found for ticket " + ticketID);
                    }
                } else {
                    System.out.println("[DEBUG] Malformed line: " + line);
                }
            }
            System.out.println("Loaded " + tickets.size() + " tickets.");
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error loading tickets: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

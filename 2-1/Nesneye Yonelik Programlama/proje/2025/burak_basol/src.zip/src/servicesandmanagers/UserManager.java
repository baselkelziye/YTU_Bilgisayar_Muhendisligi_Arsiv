package servicesandmanagers;

import reservationandticketing.Admin;
import reservationandticketing.Passenger;
import reservationandticketing.Staff;
import reservationandticketing.User;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private static final String USERS_FILE = "users.txt";
    private final Map<String, User> users;

    public UserManager() {
        users = new HashMap<>();
        loadAllUsers();
    }

    public void loadAllUsers() {
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            System.out.println("No users file found. Starting with empty user database.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int loadedCount = 0;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length < 3) {
                    System.err.println("Warning: Skipping malformed user line: " + line);
                    continue;
                }

                String userType = parts[0];
                String username = parts[1];
                String password = parts[2];

                User user = null;

                switch (userType.toUpperCase()) {
                    case "PASSENGER":
                        if (parts.length >= 7) {
                            String passengerId = parts[3];
                            String name = parts[4];
                            String surname = parts[5];
                            String contactInfo = parts[6];
                            user = new Passenger(username, password, passengerId, name, surname, contactInfo);
                        } else {
                            System.err.println("Warning: Incomplete passenger data for: " + username);
                        }
                        break;

                    case "STAFF":
                        if (parts.length >= 4) {
                            String salaryStr = parts[3].replace(',', '.');
                            double salary = Double.parseDouble(salaryStr);
                            user = new Staff(username, password, salary);
                        } else {
                            user = new Staff(username, password, 0.0);
                        }
                        break;

                    case "ADMIN":
                        user = new Admin(username, password);
                        break;

                    default:
                        System.err.println("Warning: Unknown user type: " + userType);
                        break;
                }

                if (user != null) {
                    users.put(username + "_" + userType, user);
                    loadedCount++;
                }
            }

            System.out.println("Loaded " + loadedCount + " users from " + USERS_FILE);

        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void saveAllUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users.values()) {
                String line = userToFileLine(user);
                if (line != null) {
                    writer.write(line);
                    writer.newLine();
                }
            }
            System.out.println("Saved " + users.size() + " users to " + USERS_FILE);
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String userToFileLine(User user) {
        if (user instanceof Passenger p) {
            return String.format("PASSENGER;%s;%s;%s;%s;%s;%s",
                    p.getUsername(),
                    p.getPassword(),
                    p.getPassengerID(),
                    p.getName(),
                    p.getSurname(),
                    p.getContactInfo());
        } else if (user instanceof Staff s) {
            return String.format(java.util.Locale.US, "STAFF;%s;%s;%.2f",
                    user.getUsername(),
                    user.getPassword(),
                    s.getSalary());
        } else if (user instanceof Admin) {
            return String.format("ADMIN;%s;%s",
                    user.getUsername(),
                    user.getPassword());
        }
        return null;
    }

    public User authenticate(String username, String password, String userType) {
        String key = username + "_" + userType.toUpperCase();
        User user = users.get(key);

        if (user != null && user.authenticate(password)) {
            return user;
        }

        return null;
    }

    public boolean registerPassenger(String username, String password, String passengerId,
            String name, String surname, String contactInfo) {
        String key = username + "_PASSENGER";

        if (users.containsKey(key)) {
            return false;
        }

        Passenger passenger = new Passenger(username, password, passengerId, name, surname, contactInfo);
        users.put(key, passenger);
        saveAllUsers();
        return true;
    }

    public boolean registerStaff(String username, String password, double salary) {
        String key = username + "_STAFF";

        if (users.containsKey(key)) {
            return false;
        }

        Staff staff = new Staff(username, password, salary);
        users.put(key, staff);
        saveAllUsers();
        return true;
    }

    public boolean registerAdmin(String username, String password) {
        String key = username + "_ADMIN";

        if (users.containsKey(key)) {
            return false;
        }

        Admin admin = new Admin(username, password);
        users.put(key, admin);
        saveAllUsers();
        return true;
    }

    public boolean userExists(String username, String userType) {
        String key = username + "_" + userType.toUpperCase();
        return users.containsKey(key);
    }

    public void removeUser(String username, String userType) {
        String key = username + "_" + userType.toUpperCase();
        if (users.containsKey(key)) {
            users.remove(key);
            saveAllUsers();
        }
    }

    public Map<String, User> getAllUsers() {
        return new HashMap<>(users);
    }
}

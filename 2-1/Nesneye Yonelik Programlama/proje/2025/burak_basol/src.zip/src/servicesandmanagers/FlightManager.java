package servicesandmanagers;

import flightmanagement.Flight;
import flightmanagement.Plane;

import java.io.*;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class FlightManager {
    private final ArrayList<Flight> flights;
    private static final String FLIGHTS_FILE = "flights.txt";

    public FlightManager() {
        flights = new ArrayList<>();
    }

    public ArrayList<Flight> getFlights() {
        return flights;
    }

    public void createFlight(String flightNum, Plane plane, String departurePlace, String arrivalPlace, LocalDate date,
            LocalTime hour, Duration duration) {
        Plane planeCopy = new Plane(plane.getPlaneID(), plane.getPlaneModel(), plane.getCapacity());

        if (planeCopy.getSeatMatrix().isEmpty()) {
            SeatManager seatManager = new SeatManager();
            int rows = planeCopy.getCapacity() / 6;
            planeCopy.setSeatMatrix(seatManager.createSeatArrangement(rows, 6));
        }

        Flight flight = new Flight(flightNum, planeCopy, departurePlace, arrivalPlace, date, hour, duration);
        flights.add(flight);
        saveFlightsToFile();
    }

    public Flight getFlight(String flightId) {
        for (Flight flight : flights) {
            if (flightId.equalsIgnoreCase(flight.getFlightNum())) {
                return flight;
            }
        }
        return null;
    }

    public Flight getFlightByDeparture(String departurePlace) {
        for (Flight flight : flights) {
            if (departurePlace.equalsIgnoreCase(flight.getDeparturePlace())) {
                return flight;
            }
        }
        return null;
    }

    public void deletePassedFlights() {
        for (Flight flight : flights) {
            if (flight.getDate().isBefore(LocalDate.now())) {
                flights.remove(flight);
            }
        }
    }

    public void updateFlight(String flightNum, LocalDate date, LocalTime hour, Duration duration) {
        Flight flight = getFlight(flightNum);
        flight.setDate(date);
        flight.setHour(hour);
        flight.setDuration(duration);
        saveFlightsToFile();
    }

    public void deleteFlight(String flightId) {
        flights.removeIf(flight -> flight.getFlightNum().equalsIgnoreCase(flightId));
        saveFlightsToFile();
    }

    public void addFlight(Flight flight) {
        flights.add(flight);
        saveFlightsToFile();
    }

    public void saveFlightsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FLIGHTS_FILE))) {
            for (Flight flight : flights) {
                Plane plane = flight.getPlane();
                String line = String.format("%s;%s;%s;%d;%s;%s;%s;%s;%d",
                        flight.getFlightNum(),
                        plane.getPlaneID(),
                        plane.getPlaneModel(),
                        plane.getCapacity(),
                        flight.getDeparturePlace(),
                        flight.getArrivalPlace(),
                        flight.getDate().toString(),
                        flight.getHour().toString(),
                        flight.getDuration().toMinutes());
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Flights saved to " + FLIGHTS_FILE);
        } catch (IOException e) {
            System.err.println("Error saving flights: " + e.getMessage());
        }
    }

    public void loadFlightsFromFile(ArrayList<Plane> availablePlanes) {
        File file = new File(FLIGHTS_FILE);
        if (!file.exists()) {
            System.out.println("No flights file found. Starting with empty flight list.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            SeatManager seatManager = new SeatManager();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 9) {
                    String flightNum = parts[0];
                    String planeID = parts[1];
                    String planeModel = parts[2];
                    int capacity = Integer.parseInt(parts[3]);
                    String departure = parts[4];
                    String arrival = parts[5];
                    LocalDate date = LocalDate.parse(parts[6]);
                    LocalTime time = LocalTime.parse(parts[7]);
                    long durationMinutes = Long.parseLong(parts[8]);
                    Duration duration = Duration.ofMinutes(durationMinutes);

                    Plane plane = new Plane(planeID, planeModel, capacity);

                    boolean needsInit = plane.getSeatMatrix().isEmpty();
                    if (!needsInit && !plane.getSeatMatrix().isEmpty()) {
                        needsInit = plane.getSeatMatrix().get(0).isEmpty();
                    }

                    if (needsInit) {
                        int rows = capacity / 6;
                        plane.setSeatMatrix(seatManager.createSeatArrangement(rows, 6));
                        System.out.println("Initialized seat matrix for plane " + planeID + " (" + rows + " rows)");
                    }

                    Flight flight = new Flight(flightNum, plane, departure, arrival, date, time, duration);
                    flights.add(flight);
                }
            }
            System.out.println("Loaded " + flights.size() + " flights from " + FLIGHTS_FILE);
        } catch (IOException e) {
            System.err.println("Error loading flights: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error processing flights: " + e.getMessage());
            e.printStackTrace();
        }
    }

}

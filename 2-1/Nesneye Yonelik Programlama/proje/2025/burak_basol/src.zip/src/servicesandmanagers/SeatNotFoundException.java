package servicesandmanagers;

public class SeatNotFoundException extends Exception {
    public SeatNotFoundException(String message) {
        System.out.println(message);
    }
}

package servicesandmanagers;

import flightmanagement.Flight;
import flightmanagement.Seat;
import reservationandticketing.Passenger;
import reservationandticketing.Reservation;

import java.io.*;
import java.util.ArrayList;

public class ReservationManager extends Thread {
    private final ArrayList<Reservation> reservations;
    private static final String RESERVATIONS_FILE = "reservations.txt";

    public ReservationManager() {
        reservations = new ArrayList<>();
    }

    public void creatReservation(Flight flight, Passenger passenger, Seat seat, String date, double baggageWeight) {
        Reservation reservation = new Reservation(flight, passenger, seat, date, baggageWeight);
        reservations.add(reservation);
        seat.setReserveStatus(true);
        saveReservationsToFile();
    }

    public void cancelReservation(Reservation reservation) {
        reservations.remove(reservation);
        reservation.getSeat().setReserveStatus(false);
        saveReservationsToFile();
    }

    public void updateReservation(String reservationPNR, Flight flight, Passenger passenger, Seat seat, String date) {
        Reservation reservation = searchReservation(reservationPNR);
        if (reservation != null) {
            reservation.setFlight(flight);
            reservation.setPassenger(passenger);
            reservation.setSeat(seat);
            reservation.setDateOfReservation(date);
            saveReservationsToFile();
        }
    }

    public Reservation searchReservation(String reservationPNR) {
        if (reservationPNR == null)
            return null;
        for (Reservation reservation : reservations) {
            if (reservation.getReservationPNR().trim().equalsIgnoreCase(reservationPNR.trim())) {
                return reservation;
            }
        }
        
        System.out.println("[DEBUG] Failed to find reservation: '" + reservationPNR + "'");
        System.out.println("[DEBUG] Available PNRs: ");
        for (Reservation r : reservations) {
            System.out.println(" - '" + r.getReservationPNR() + "'");
        }
        return null;
    }

    public ArrayList<Reservation> getAllReservations() {
        return reservations;
    }

    public ArrayList<Reservation> searchReservationsByFlight(String flightNumber) {
        ArrayList<Reservation> matchingReservations = new ArrayList<>();
        if (flightNumber == null || flightNumber.trim().isEmpty()) {
            return matchingReservations;
        }

        String searchFlightNum = flightNumber.trim();
        for (Reservation reservation : reservations) {
            if (reservation != null && reservation.getFlight() != null) {
                String resFlightNum = reservation.getFlight().getFlightNum();
                if (resFlightNum != null && resFlightNum.trim().equalsIgnoreCase(searchFlightNum)) {
                    matchingReservations.add(reservation);
                }
            }
        }
        return matchingReservations;
    }

    public void cancelReservationsForPassenger(String passengerID) {
        if (passengerID == null || passengerID.trim().isEmpty()) {
            return;
        }

        ArrayList<Reservation> toRemove = new ArrayList<>();

        for (Reservation reservation : reservations) {
            if (reservation.getPassenger() != null &&
                    passengerID.equals(reservation.getPassenger().getPassengerID())) {
                toRemove.add(reservation);
            }
        }

        for (Reservation reservation : toRemove) {
            reservations.remove(reservation);
            if (reservation.getSeat() != null) {
                reservation.getSeat().setReserveStatus(false);
            }
        }

        if (!toRemove.isEmpty()) {
            System.out.println("Removed " + toRemove.size() + " reservations for passenger " + passengerID);
            saveReservationsToFile();
        }
    }

    public void saveReservationsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RESERVATIONS_FILE))) {
            for (Reservation reservation : reservations) {
                String line = String.format("%s;%s;%s;%s;%s;%s;%s",
                        reservation.getReservationPNR(),
                        reservation.getFlight().getFlightNum(),
                        reservation.getPassenger().getPassportNumber(),
                        reservation.getPassenger().getName(),
                        reservation.getSeat().getSeatNum(),
                        reservation.getDateOfReservation(),
                        reservation.getBaggage().getWeight());
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Reservations saved to " + RESERVATIONS_FILE);
        } catch (IOException e) {
            System.err.println("Error saving reservations: " + e.getMessage());
        }
    }

    public void loadReservationsFromFile(FlightManager flightManager) {
        File file = new File(RESERVATIONS_FILE);
        if (!file.exists()) {
            System.out.println("No reservations file found. Starting with empty reservation list.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int loadedCount = 0;
            int skippedCount = 0;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 6) {
                    String pnr = parts[0].trim().replace("\uFEFF", ""); 
                    String flightNum = parts[1];
                    String passportNum = parts[2];
                    String passengerName = parts[3];
                    String seatNum = parts[4];
                    String reservationDate = parts[5];
                    double baggageWeight = 0.0;

                    if (parts.length >= 7) {
                        try {
                            baggageWeight = Double.parseDouble(parts[6]);
                        } catch (NumberFormatException e) {
                            System.err.println(
                                    "Warning: Invalid baggage weight in reservation " + pnr + ". Defaulting to 0.");
                        }
                    }

                    Flight flight = flightManager.getFlight(flightNum);
                    if (flight != null) {
                        Seat seat = findSeat(flight, seatNum);
                        if (seat != null) {
                            Passenger passenger = new Passenger(passportNum, passengerName, "", "");

                            Reservation reservation = new Reservation(flight, passenger, seat, reservationDate,
                                    baggageWeight);
                            
                            reservation.setReservationPNR(pnr);

                            reservations.add(reservation);

                            seat.setReserveStatus(true);
                            loadedCount++;
                            System.out.println(
                                    "Loaded reservation: " + pnr + " - Flight " + flightNum + " - Seat " + seatNum);
                        } else {
                            System.err.println("Warning: Seat " + seatNum + " not found for flight " + flightNum
                                    + " (reservation " + pnr + ")");
                            skippedCount++;
                        }
                    } else {
                        System.err.println("Warning: Flight " + flightNum + " not found for reservation " + pnr);
                        skippedCount++;
                    }
                } else {
                    System.err.println("Warning: Skipping malformed reservation line: " + line);
                    skippedCount++;
                }
            }
            System.out.println("Loaded " + loadedCount + " reservations from " + RESERVATIONS_FILE);
            if (skippedCount > 0) {
                System.out.println(
                        "Skipped " + skippedCount + " reservations (flight or seat not found or malformed lines)");
            }
        } catch (IOException e) {
            System.err.println("Error loading reservations: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error processing reservations: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private Seat findSeat(Flight flight, String seatNum) {
        if (flight.getPlane() == null || flight.getPlane().getSeatMatrix() == null) {
            return null;
        }

        for (ArrayList<Seat> row : flight.getPlane().getSeatMatrix()) {
            for (Seat seat : row) {
                if (seat.getSeatNum().equals(seatNum)) {
                    return seat;
                }
            }
        }
        return null;
    }

    @Override
    public void run() {
        System.out.println("Reservation Manager task is running " +
                Thread.currentThread().getName());
    }

    private boolean[] simulationSeats;

    public void initSimulationSeats(int totalSeats) {
        this.simulationSeats = new boolean[totalSeats];
    }

    public int countOccupiedSimulationSeats() {
        int count = 0;
        if (simulationSeats != null) {
            for (boolean b : simulationSeats) {
                if (b)
                    count++;
            }
        }
        return count;
    }

    public synchronized boolean reserveSeatSynchronized(int seatIndex) {
        if (seatIndex >= 0 && seatIndex < simulationSeats.length) {
            if (!simulationSeats[seatIndex]) {
                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {
                }

                simulationSeats[seatIndex] = true;
                return true;
            }
        }
        return false;
    }

    public boolean reserveSeatUnsynchronized(int seatIndex) {
        if (seatIndex >= 0 && seatIndex < simulationSeats.length) {
            if (!simulationSeats[seatIndex]) {
                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {
                }

                simulationSeats[seatIndex] = true;
                return true;
            }
        }
        return false;
    }
}

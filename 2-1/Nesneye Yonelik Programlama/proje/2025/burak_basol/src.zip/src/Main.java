public class Main {
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("cli")) {
            ui.cli.LoginScreen.main(args);
        }
        else {
            ui.gui.LoginScreen.main(args);
        }
    }
}


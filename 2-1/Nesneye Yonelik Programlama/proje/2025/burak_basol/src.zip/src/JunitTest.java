import flightmanagement.Flight;
import flightmanagement.Plane;
import flightmanagement.Seat;
import flightmanagement.SeatEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import servicesandmanagers.CalculatePrice;
import servicesandmanagers.FlightManager;
import servicesandmanagers.SeatManager;
import servicesandmanagers.SeatNotFoundException;
import servicesandmanagers.ReservationManager;
import reservationandticketing.Passenger;
import reservationandticketing.Reservation;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

public class JunitTest {

    private CalculatePrice priceCalculator;
    private FlightManager flightManager;
    private SeatManager seatManager;
    private Plane testPlane;

    @BeforeEach
    void setUp() {
        priceCalculator = new CalculatePrice();
        flightManager = new FlightManager();
        seatManager = new SeatManager();

        testPlane = new Plane("PL001", "Test Model", 12);

        testPlane.setSeatMatrix(seatManager.createSeatArrangement(2, 6));
    }

    @Test
    @DisplayName("1. Price Calculation Test")
    void testPriceCalculation() {
        System.out.println("Running: Price Calculation Test...");

        Seat economySeat = new Seat("1A", SeatEnum.ECONOMY);
        Seat businessSeat = new Seat("2A", SeatEnum.BUSINESS);

        double expectedEco = 118.0;
        double expectedBus = 236.0;

        assertEquals(expectedEco, priceCalculator.calculatePrice(economySeat), 0.01, "Economy fiyati hatali.");
        assertEquals(expectedBus, priceCalculator.calculatePrice(businessSeat), 0.01, "Business fiyati hatali.");

        System.out.println("Result: Price Calculation Passed (Eco: " + expectedEco + ", Bus: " + expectedBus + ")");
    }

    @Test
    @DisplayName("2. Flight Search Engine (Filtering) Test")
    void testFlightSearchByDeparture() {
        System.out.println("Running: Flight Search Filtering Test...");

        flightManager.createFlight("TK101", testPlane, "Istanbul", "Ankara",
                LocalDate.now().plusDays(1), LocalTime.of(10, 0), Duration.ofHours(1));

        Flight found = flightManager.getFlightByDeparture("Istanbul");

        assertNotNull(found, "Ucus bulunamadi.");
        assertEquals("TK101", found.getFlightNum(), "Dogru ucus getirilmedi.");
        assertNull(flightManager.getFlightByDeparture("Izmir"), "Olmayan sehir icin ucus donmemeli.");

        System.out.println("Result: Flight Search Filtering Passed.");
    }

    @Test
    @DisplayName("3. Flight Search Engine (Past Flights) Test")
    void testEliminatePassedFlights() {
        System.out.println("Running: Eliminate Passed Flights Test...");

        Flight oldFlight = new Flight("OLD01", testPlane, "A", "B",
                LocalDate.now().minusDays(1), LocalTime.now(), Duration.ofHours(1));
        flightManager.addFlight(oldFlight);

        Flight futureFlight = new Flight("NEW01", testPlane, "C", "D",
                LocalDate.now().plusDays(1), LocalTime.now(), Duration.ofHours(1));
        flightManager.addFlight(futureFlight);

        flightManager.deletePassedFlights();

        assertEquals(1, flightManager.getFlights().size(), "Gecmis ucus silinmedi.");
        assertEquals("NEW01", flightManager.getFlights().getFirst().getFlightNum());

        System.out.println("Result: Past Flights Elimination Passed.");
    }

    @Test
    @DisplayName("4. Seat Manager (Availability) Test")
    void testAvailableSeatsCountDecreases() throws Exception {
        System.out.println("Running: Seat Availability Count Test...");

        Flight flight = new Flight("TK102", testPlane, "Istanbul", "London",
                LocalDate.now().plusDays(1), LocalTime.of(12, 0), Duration.ofHours(4));

        int initialCount = seatManager.getAvailableSeats(flight);
        assertEquals(12, initialCount);

        seatManager.reserveSeat(flight, "1A");

        int newCount = seatManager.getAvailableSeats(flight);
        assertEquals(11, newCount, "Koltuk rezerve edildikten sonra sayi azalmadi.");

        System.out.println("Result: Seat Availability Count Decreased Successfully (12 -> 11).");
    }

    @Test
    @DisplayName("5. Seat Manager (Exception) Test")
    void testReserveNonExistentSeatThrowsException() {
        System.out.println("Running: Non-existent Seat Exception Test...");

        Flight flight = new Flight("TK103", testPlane, "Paris", "Berlin",
                LocalDate.now().plusDays(1), LocalTime.of(15, 0), Duration.ofHours(2));

        assertThrows(SeatNotFoundException.class, () -> {
            seatManager.reserveSeat(flight, "99Z");
        }, "Olmayan koltuk icin hata firlatilmaliydi.");

        System.out.println("Result: Exception Successfully Thrown for Seat 99Z.");
    }

    @Test
    @DisplayName("6. Reservation Manager (Baggage Weight) Test")
    void testBaggageWeightPersistence() {
        System.out.println("Running: Baggage Weight Persistence Test...");

        ReservationManager resManager = new ReservationManager();
        Flight flight = new Flight("TK104", testPlane, "Istanbul", "Paris",
                LocalDate.now().plusDays(1), LocalTime.of(14, 0), Duration.ofHours(3));
        Passenger passenger = new Passenger("P123", "Test", "Passenger", "Contact");
        Seat seat = new Seat("3A", SeatEnum.ECONOMY);

        double baggageWeight = 12.5;
        resManager.creatReservation(flight, passenger, seat, LocalDate.now().toString(), baggageWeight);

        Reservation savedRes = resManager.getAllReservations().get(resManager.getAllReservations().size() - 1);
        assertEquals(baggageWeight, savedRes.getBaggage().getWeight(), 0.01, "Baggage weight was not saved correctly.");

        System.out.println("Result: Baggage Weight Saved and Retrieved Successfully.");
    }
}

public class Sports {
	
	private String name;
	private int session;
	private double price;
	
	public Sports(String name, int session, double price) {
		this.name = name;
		this.session = session;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSession() {
		return session;
	}

	public void setSession(int session) {
		this.session = session;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	

	

}

#ifndef CALCULATIONS_H_
#define CALCULATIONS_H_

#define SUM(x, y) (x)+(y)
#define DIFFERENCE(x, y) (x)-(y)
#define PRODUCT(x, y) (x)*(y)
#define QUOTIENT(x, y) (x)/(y)

#endif 

#ifndef MENU_H_  
#define MENU_H_
#define maliyet(x) x*x
#define iterasyon 5
#define POPULATION 10
#endif

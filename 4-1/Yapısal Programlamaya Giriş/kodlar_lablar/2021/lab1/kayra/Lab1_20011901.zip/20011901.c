#include <stdio.h>
int main(void){
	int i,n,a[100],k;
	printf("Lutfen dizi boyutunu giriniz");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		printf("Lutfen %d. sayiyi giriniz",i);
		scanf("%d",&a[i]);
	}
	i=1;
	while(i<=n-1 && a[i]+1==a[i+1] ){
		i++;
	}
	if(i==n){
		printf("Diziyi bozan sayi yoktur");
	}
	else{
		k=a[i]+1;
		printf("%d",k);
	}
	return 0;
}
